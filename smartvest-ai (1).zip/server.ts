import express from 'express';
import dotenv from 'dotenv';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import { GoogleGenAI } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const port = 3000;

app.use(express.json());

// Endpoint to download the full project zip
app.get('/api/download-zip', (_req, res) => {
  const possiblePaths = [
    path.resolve(__dirname, 'smartvest-ai.zip'),
    path.resolve(__dirname, 'public', 'smartvest-ai.zip')
  ];

  for (const p of possiblePaths) {
    if (fs.existsSync(p)) {
      res.setHeader('Content-Type', 'application/zip');
      res.setHeader('Content-Disposition', 'attachment; filename="smartvest-ai.zip"');
      return res.sendFile(p);
    }
  }

  return res.status(404).json({ error: 'Zip file not found' });
});

// Fallback intelligent answers for common queries when offline or without API key
function getLocalSmartResponse(question: string, userContext: any): string {
  const q = question.toLowerCase();
  const beginner = userContext?.beginnerMode ?? true;
  const income = userContext?.monthlyIncome ? `₹${Number(userContext.monthlyIncome).toLocaleString('en-IN')}` : 'your income';
  const investable = userContext?.investableCapacity ? `₹${Number(userContext.investableCapacity).toLocaleString('en-IN')}` : '₹5,000 - ₹10,000';
  const risk = userContext?.riskCategory || 'Moderate';
  const emergencyCoverage = userContext?.emergencyFundMonths ?? 0;

  if (q.includes('sip') || q.includes('systematic investment')) {
    return `**SIP (Systematic Investment Plan)** is a disciplined way to invest a fixed amount regularly (for example, monthly) instead of putting in a lump sum all at once.\n\n` +
      `💡 **Simple Example**: Just like putting ${investable} aside every month after payday. Over time, you buy units at different market levels (rupee-cost averaging), reducing the risk of bad market timing.\n\n` +
      `⚠️ *Note: Returns in SIPs depend on the underlying asset (equity/debt) and are not guaranteed, but historical long-term data shows strong compounding potential.*`;
  }

  if (q.includes('mutual fund') || q.includes('mf')) {
    return `**Mutual Funds** are pools of money collected from many investors to invest in a diversified mix of stocks, bonds, or other securities, managed by professional fund managers.\n\n` +
      `💡 **Simple Analogy**: Think of a potluck dinner where everyone brings a small dish, and everyone gets to taste a full feast. You get instant diversification even with small amounts like ₹500.\n\n` +
      `⚠️ *Risk: Mutual funds are subject to market risks. Past performance does not guarantee future results.*`;
  }

  if (q.includes('etf') || q.includes('exchange traded')) {
    return `An **ETF (Exchange Traded Fund)** is similar to a mutual fund because it holds a basket of investments (like the Nifty 50 or S&P 500 index), but it trades on the stock exchange throughout the day just like an individual stock.\n\n` +
      `💡 **Key Advantages**: Very low management fees (often < 0.2%), transparent holdings, and instant liquidity during market hours.\n\n` +
      `⚠️ *Best for: Long-term index investors who want low costs and simple broad-market exposure.*`;
  }

  if (q.includes('how much can i invest') || q.includes('how much should i invest') || q.includes('investable')) {
    if (userContext?.monthlyIncome) {
      return `Based on your profile:\n` +
        `• **Monthly Income**: ${income}\n` +
        `• **Calculated Investable Capacity**: ~${investable} per month.\n` +
        `• **Emergency Reserve**: Currently covers approximately ${emergencyCoverage.toFixed(1)} months of expenses.\n\n` +
        `${emergencyCoverage < 3 ? '⚠️ **Priority Action**: Since your emergency fund is below 3-6 months of expenses, consider allocating at least 50% of your savings into high-liquidity emergency reserves first before increasing market investments.\n\n' : '✅ **Great job**: Your emergency buffer provides safety to invest towards your mid- and long-term goals without panic selling.\n\n'}` +
        `*Remember to never invest money you might need within the next 6-12 months for essential living costs.*`;
    }
    return `A common rule of thumb is the **50-30-20 rule**:\n• 50% for Needs (rent, food, utilities, EMIs)\n• 30% for Wants (lifestyle, dining, entertainment)\n• 20% for Savings & Investments.\n\nComplete your SmartVest profile so I can calculate your exact surplus capacity!`;
  }

  if (q.includes('emergency fund') || q.includes('emergency savings')) {
    return `An **Emergency Fund** is money kept safe and easily accessible (in a savings account or liquid fund) strictly for unexpected life surprises, such as medical issues, sudden job loss, or essential repairs.\n\n` +
      `💡 **How much do you need?** Generally 3 to 6 months of mandatory living expenses.\n` +
      `Why it matters: It prevents you from taking expensive loans or selling your investments at a loss during a market downturn.`;
  }

  if (q.includes('risk') || q.includes('my profile') || q.includes('moderate') || q.includes('conservative') || q.includes('aggressive')) {
    return `Your risk profile is currently evaluated as **${risk}**.\n\n` +
      `• **What this means**: You have a balance between seeking capital growth and avoiding severe volatility.\n` +
      `• **Suggested approach**: A balanced allocation between growth assets (diversified equity/index funds) and stability assets (debt funds/fixed income) with an adequate emergency cushion.\n\n` +
      `*You can retake the Risk Assessment questionnaire anytime in your Profile to update this.*`;
  }

  if (q.includes('stock') || q.includes('equity') || q.includes('share')) {
    return `**Stocks (or Equity)** represent partial ownership in a real company. When the company grows, profits, or expands, the value of your shares can increase, and some companies pay dividends.\n\n` +
      `💡 **Beginner tip**: Buying individual stocks carries company-specific risk. For beginners, broad index funds or equity mutual funds spread your money across 50 to 500 companies at once.`;
  }

  if (q.includes('compound') || q.includes('compounding')) {
    return `**Compound Growth** is earning returns on your returns over time.\n\n` +
      `💡 **Example**: If you invest ₹10,000 and earn 10% in Year 1, you have ₹11,000. In Year 2, you earn 10% on ₹11,000 (which is ₹1,100), not just on ₹10,000.\n\n` +
      `Over 10, 20, or 30 years, this snowball effect generates the vast majority of long-term wealth!`;
  }

  if (q.includes('diversif') || q.includes('diversification')) {
    return `**Diversification** is the golden rule of investing: *"Don't put all your eggs in one basket."*\n\n` +
      `By spreading your investments across different asset classes (equities, debt, gold, liquid cash) and multiple industries, a drop in one area can be cushioned by stability or gains in another.`;
  }

  if (q.includes('inflation')) {
    return `**Inflation** is the gradual increase in the cost of goods and services over time. If a basket of groceries costs ₹1,000 today and inflation is 6%, that same basket will cost ₹1,060 next year.\n\n` +
      `💡 **Why invest?** If your money sits idle in cash earning 0%, its purchasing power declines every year. Investing helps your money outpace inflation.`;
  }

  // General fallback
  return `Thank you for asking! As your SmartVest AI educational advisor:\n\n` +
    `Investing is a journey of matching your time horizon, financial goals, and risk comfort with the right assets.\n\n` +
    `• **For short-term goals (< 3 years)**: Prioritize capital safety (Fixed deposits, liquid/debt funds).\n` +
    `• **For long-term goals (> 5 years)**: Consider equity funds or diversified index funds for wealth creation.\n` +
    `• **First step**: Always ensure you have 3 to 6 months of emergency reserves before committing to volatile investments.\n\n` +
    `Feel free to ask specific questions like *"What is SIP?"*, *"How does compound interest work?"*, or *"Explain my asset allocation!"*`;
}

app.post('/api/chat', async (req, res) => {
  try {
    const { message, profileContext, history } = req.body;
    if (!message || typeof message !== 'string') {
      return res.status(400).json({ error: 'Message is required' });
    }

    const apiKey = process.env.GEMINI_API_KEY;
    const isValidKeyFormat = apiKey && apiKey.startsWith('AIza') && apiKey.length > 20;

    if (!isValidKeyFormat) {
      // Local intelligent response (instantaneous)
      const fallbackText = getLocalSmartResponse(message, profileContext);
      return res.json({ text: fallbackText, source: 'smart-local' });
    }

    try {
      const ai = new GoogleGenAI({ apiKey });
      
      const systemInstruction = `You are SmartVest AI, an empathetic, encouraging, and highly knowledgeable personal financial education assistant.
Your goal is to guide beginners, students, salaried professionals, and young investors on financial literacy, budgeting, emergency planning, and asset allocation.

USER CONTEXT:
- Beginner Mode: ${profileContext?.beginnerMode ? 'ON (use simple everyday analogies, clear definitions, avoid jargon)' : 'OFF'}
- Age: ${profileContext?.age || 'Not specified'}
- Employment: ${profileContext?.employmentStatus || 'Not specified'}
- Monthly Income: ₹${profileContext?.monthlyIncome || 'Not specified'}
- Monthly Expenses: ₹${profileContext?.monthlyExpenses || 'Not specified'}
- Calculated Savings: ₹${profileContext?.monthlySavings || 'Not specified'}
- Investable Capacity: ₹${profileContext?.investableCapacity || 'Not specified'}
- Emergency Fund Coverage: ${profileContext?.emergencyFundMonths?.toFixed(1) || '0'} months of expenses
- Risk Profile: ${profileContext?.riskCategory || 'Moderate'} (Score: ${profileContext?.riskScore || 'N/A'}/16)
- Financial Goals: ${JSON.stringify(profileContext?.goals || [])}

MANDATORY RULES:
1. NEVER guarantee returns or state that an investment is 100% risk-free.
2. NEVER give direct regulated stock tips or specific buy/sell tickers. Explain categories (e.g. broad market index funds, debt funds, liquid funds).
3. If the user's emergency fund is below 3 months, prioritize building emergency savings before taking aggressive equity risks.
4. Keep explanations conversational, crisp, and easy to read with bullet points or emojis where appropriate.
5. If the user asks about their specific finances (like "How much can I invest?"), reference their actual profile numbers provided above. If data is missing, gently ask them to update their profile.
6. Clearly state that SmartVest AI provides educational guidance, not formal fiduciary or tax advice, and recommend consulting certified financial planners for major financial decisions.`;

      // Build conversation contents
      const formattedHistory = Array.isArray(history)
        ? history.slice(-6).map((h: { role: string; content: string }) => ({
            role: h.role === 'user' ? 'user' : 'model',
            parts: [{ text: h.content }],
          }))
        : [];

      formattedHistory.push({
        role: 'user',
        parts: [{ text: message }],
      });

      // Timeout wrapper so request never hangs
      const timeoutPromise = new Promise<never>((_, reject) =>
        setTimeout(() => reject(new Error('AI generation timed out')), 5000)
      );

      const generatePromise = ai.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: formattedHistory,
        config: {
          systemInstruction,
          temperature: 0.6,
        },
      });

      const response = await Promise.race([generatePromise, timeoutPromise]);
      const responseText = response.text || getLocalSmartResponse(message, profileContext);
      return res.json({ text: responseText, source: 'gemini' });
    } catch (genAiError: any) {
      console.warn('Gemini API call warning, using smart fallback:', genAiError?.message);
      const fallbackText = getLocalSmartResponse(message, profileContext);
      return res.json({ text: fallbackText, source: 'smart-local-fallback' });
    }
  } catch (error: any) {
    console.error('Server error handling chat:', error);
    return res.status(500).json({ error: 'Internal server error processing chat' });
  }
});

// Setup Vite middleware in dev or static files in production
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(port, '0.0.0.0', () => {
    console.log(`SmartVest AI server listening on http://0.0.0.0:${port}`);
  });
}

startServer();
