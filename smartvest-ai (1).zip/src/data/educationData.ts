import { EducationArticle } from '../types';

export interface GlossaryTerm {
  term: string;
  simpleDefinition: string;
  analogy: string;
  example: string;
  category: 'core' | 'products' | 'concepts';
}

export const GLOSSARY_TERMS: Record<string, GlossaryTerm> = {
  'equity': {
    term: 'Equity (Stocks)',
    simpleDefinition: 'Buying a tiny slice of ownership in a real company.',
    analogy: 'Imagine your friend opens a successful bakery. If you put in money to own 5% of the shop, you get 5% of the future profits when it expands.',
    example: 'If you invest ₹5,000 in an Indian index fund, you own small fractional pieces of the top 50 companies in the country.',
    category: 'products'
  },
  'debt': {
    term: 'Debt / Fixed Income',
    simpleDefinition: 'Lending your money to a government, bank, or company in return for regular, guaranteed interest payments.',
    analogy: 'Just like lending money to a trustworthy relative who promises to pay you back with 7% interest every year.',
    example: 'Government bonds or Fixed Deposits (FDs) where your principal is safeguarded and returns are predictable.',
    category: 'products'
  },
  'mutual_fund': {
    term: 'Mutual Fund',
    simpleDefinition: 'A collective pool of money gathered from thousands of investors, managed by a licensed professional fund manager.',
    analogy: 'A potluck dinner where everyone brings ₹500, allowing the chef to buy 100 different delicious dishes so everyone gets a balanced meal.',
    example: 'Instead of picking 30 stocks yourself, a mutual fund automatically spreads your ₹1,000 across 50 top companies.',
    category: 'products'
  },
  'sip': {
    term: 'SIP (Systematic Investment Plan)',
    simpleDefinition: 'A method where you invest a fixed sum automatically at regular intervals (like every month on payday).',
    analogy: 'Like paying an automated gym membership or Netflix subscription, but instead of spending money, you are accumulating assets.',
    example: 'Investing ₹2,000 every month on the 5th without having to guess whether the market is high or low.',
    category: 'concepts'
  },
  'etf': {
    term: 'ETF (Exchange Traded Fund)',
    simpleDefinition: 'A basket of investments that tracks an index and trades on the stock exchange during the day just like a regular share.',
    analogy: 'A pre-packaged fruit basket at the supermarket. You buy the whole basket in one quick barcode scan.',
    example: 'Buying 1 unit of Nifty 50 ETF for ₹250 instantly gives you exposure to India’s top 50 corporations.',
    category: 'products'
  },
  'cagr': {
    term: 'CAGR (Compound Annual Growth Rate)',
    simpleDefinition: 'The smoothed annual rate at which your investment grew over multiple years, accounting for compounding.',
    analogy: 'If you drove 300 km in 5 hours, your average speed was 60 km/h, even though you sped up on highways and stopped at red lights.',
    example: 'A ₹1,00,000 investment growing to ₹2,00,000 over 7 years has a CAGR of approximately 10.4% per year.',
    category: 'concepts'
  },
  'inflation': {
    term: 'Inflation',
    simpleDefinition: 'The steady increase in the prices of goods and services over time, which reduces what your money can buy.',
    analogy: 'A movie ticket cost ₹50 fifteen years ago and costs ₹250 today. The movie isn’t 5x better—the currency’s purchasing power decreased.',
    example: 'If inflation is 6%, an item that costs ₹100 today will cost ₹106 next year. Cash under your mattress loses value.',
    category: 'concepts'
  },
  'risk_tolerance': {
    term: 'Risk Tolerance',
    simpleDefinition: 'How much financial fluctuation and temporary paper loss you can comfortably handle without losing sleep or panicking.',
    analogy: 'Riding a roller coaster. Some people love the loops and thrills for the excitement; others prefer a calm scenic train ride.',
    example: 'If your portfolio drops 15% during a recession, someone with high risk tolerance buys more; low risk tolerance may want to sell.',
    category: 'core'
  },
  'asset_allocation': {
    term: 'Asset Allocation',
    simpleDefinition: 'How you divide your total money across different buckets: Stocks, Bonds, Gold, and Cash.',
    analogy: 'A balanced diet: you don’t eat 100% carbs or 100% sugar. You mix proteins, greens, and grains for optimal long-term health.',
    example: 'A 50% Equity / 35% Debt / 15% Cash split ensures you have growth while keeping stability during market downturns.',
    category: 'core'
  },
  'liquidity': {
    term: 'Liquidity',
    simpleDefinition: 'How quickly and easily you can convert an investment into spendable cash without losing its value.',
    analogy: 'Cash in your wallet or bank is liquid water. A house is a solid iceberg: it takes months to sell and convert into cash.',
    example: 'Savings accounts and liquid funds can be accessed in minutes; real estate and lock-in pension plans have low liquidity.',
    category: 'concepts'
  },
  'net_worth': {
    term: 'Net Worth',
    simpleDefinition: 'Everything you own of value (Assets) minus everything you owe to others (Liabilities).',
    analogy: 'The true financial scorecard of what would remain in your pocket if you sold all your assets and paid off every debt today.',
    example: 'If you have ₹4,00,000 in savings/investments and owe ₹1,00,000 on a personal loan, your Net Worth is ₹3,00,000.',
    category: 'core'
  },
  'emergency_fund': {
    term: 'Emergency Fund',
    simpleDefinition: 'A dedicated safety cash reserve covering 3 to 6 months of living expenses, kept strictly for unforeseen surprises.',
    analogy: 'The spare tyre in your car. You hope you never need it, but you would never drive on a highway without one.',
    example: 'If your monthly rent and food cost ₹30,000, an ideal emergency fund is ₹90,000 to ₹1,80,000 kept in an instant-access account.',
    category: 'core'
  },
  'emi': {
    term: 'EMI (Equated Monthly Installment)',
    simpleDefinition: 'A fixed monthly payment made by a borrower to a lender to pay off a loan and interest over a specific period.',
    analogy: 'Paying off a big furniture purchase in 12 equal monthly instalments instead of paying everything on day one.',
    example: 'Paying ₹12,000 every month toward a car loan for 3 years until the total balance is cleared.',
    category: 'concepts'
  }
};

export const EDUCATION_ARTICLES: EducationArticle[] = [
  {
    id: 'saving-vs-investing',
    title: 'Saving vs. Investing: What is the Real Difference?',
    category: 'Foundations',
    readTime: '3 min',
    icon: 'PiggyBank',
    simpleDefinition: 'Saving is setting money aside for short-term safety; investing is putting money to work to generate long-term growth.',
    realLifeExample: 'Keeping cash in a jar protects it from disappearing, but planting an apple seed and watering it grows an apple tree that produces fruit year after year.',
    benefits: [
      'Savings give you instant peace of mind and emergency protection',
      'Investing helps your money grow faster than inflation',
      'Together they provide both short-term security and long-term freedom'
    ],
    risks: [
      'Saving only: Inflation slowly erodes the purchasing power of idle cash',
      'Investing only without savings: You might be forced to sell investments at a loss when emergencies hit'
    ],
    whenUseful: 'Save for bills and emergencies due in under 2 years; invest for goals 3 to 20+ years away.',
    keyTakeaway: 'Save first for safety, then invest your surplus for compounding growth.'
  },
  {
    id: 'stocks-equities',
    title: 'Stocks (Equities): Owning a Piece of Real Business',
    category: 'Asset Classes',
    readTime: '4 min',
    icon: 'TrendingUp',
    simpleDefinition: 'A stock represents fractional ownership in a corporation. If the company profits and expands, your share value can rise.',
    realLifeExample: 'If you and three friends chip in together to buy a delivery van, you each own 25% of the van and earn 25% of the delivery fees.',
    benefits: [
      'Highest long-term historical returns among major mainstream assets',
      'Potential for regular dividend income from corporate earnings',
      'Easy to buy and sell through licensed digital brokers'
    ],
    risks: [
      'Market volatility: Prices fluctuate daily based on market sentiment and economy',
      'Company risk: An individual business can face tough competition or bankruptcy'
    ],
    whenUseful: 'Ideal for wealth creation goals that are at least 5 years away, such as retirement or long-term financial independence.',
    keyTakeaway: 'Stocks are the growth engine of a portfolio, but demand patience through short-term market dips.'
  },
  {
    id: 'mutual-funds',
    title: 'Mutual Funds: Professional Management Made Accessible',
    category: 'Investment Vehicles',
    readTime: '4 min',
    icon: 'Layers',
    simpleDefinition: 'A managed pool of money where thousands of people combine their savings to buy hundreds of stocks or bonds managed by professionals.',
    realLifeExample: 'Hiring an expert tour guide who takes a group on a curated, safe city tour rather than wandering into unfamiliar streets alone.',
    benefits: [
      'Instant diversification even with small monthly sums (e.g. ₹500/month)',
      'Managed by experienced financial analysts and fund managers',
      'Heavily regulated by financial watchdogs (like SEBI or SEC) for safety'
    ],
    risks: [
      'Management fees (Expense Ratio) are charged regardless of performance',
      'Still subject to market ups and downs'
    ],
    whenUseful: 'The perfect starting vehicle for beginners who want broad market exposure without researching individual balance sheets.',
    keyTakeaway: 'Mutual funds turn complex stock markets into a simple, automated one-click monthly habit.'
  },
  {
    id: 'sip',
    title: 'SIP (Systematic Investment Plan): The Power of Habit',
    category: 'Strategy',
    readTime: '3 min',
    icon: 'Calendar',
    simpleDefinition: 'Investing a fixed amount of money at consistent dates (e.g., monthly) into a chosen mutual fund or index fund.',
    realLifeExample: 'Going to the gym for 30 minutes every Tuesday and Thursday consistently beats trying to work out for 10 hours once a year.',
    benefits: [
      'Takes human emotion and panic out of the equation',
      'Rupee-Cost Averaging: You automatically buy more units when prices are cheap and fewer when prices are expensive',
      'Instills disciplined financial budgeting right after payday'
    ],
    risks: [
      'Stopping early in a market crash locks in temporary losses instead of reaping the rebound benefits'
    ],
    whenUseful: 'Every month from your salary or business earnings for ongoing wealth creation.',
    keyTakeaway: 'Time in the market and consistency beat trying to time the market every single time.'
  },
  {
    id: 'etfs',
    title: 'ETFs (Exchange Traded Funds): Low-Cost Market Access',
    category: 'Investment Vehicles',
    readTime: '3 min',
    icon: 'Activity',
    simpleDefinition: 'A fund that tracks a public index (like the top 50 companies) and trades on the stock exchange throughout market hours.',
    realLifeExample: 'Ordering a combo meal at a restaurant instead of buying the burger, fries, and drink separately—cheaper, faster, and predictable.',
    benefits: [
      'Ultra-low expense fees (often as low as 0.05% - 0.2%)',
      '100% transparent holdings published daily',
      'Can be bought or sold instantly during stock exchange trading hours'
    ],
    risks: [
      'Requires a brokerage/demat account to trade',
      'Subject to general market downturns along with the underlying index'
    ],
    whenUseful: 'Cost-conscious investors building a simple passive index portfolio.',
    keyTakeaway: 'ETFs allow you to own the entire country’s economic growth for minimal cost.'
  },
  {
    id: 'bonds-debt',
    title: 'Bonds & Fixed Income: The Portfolio Stabilizer',
    category: 'Asset Classes',
    readTime: '4 min',
    icon: 'ShieldCheck',
    simpleDefinition: 'Loans made by you to governments or corporations that pay you regular interest and return your original principal at maturity.',
    realLifeExample: 'A rental property lease where the tenant agrees to pay you a fixed rent every month on the 1st without surprises.',
    benefits: [
      'Predictable cashflow and interest income',
      'Significantly lower volatility than stocks during market panics',
      'Protects accumulated wealth as you approach goal deadlines'
    ],
    risks: [
      'Inflation risk: If inflation is 7% and your bond pays 6%, you are losing purchasing power',
      'Interest rate fluctuations affect bond fund valuations'
    ],
    whenUseful: 'Short-to-medium term goals (1-4 years), emergency reserves, or portfolio balancing.',
    keyTakeaway: 'Bonds are not for getting rich quick—they exist so you can sleep peacefully at night.'
  },
  {
    id: 'diversification',
    title: 'Diversification: The Only Free Lunch in Finance',
    category: 'Strategy',
    readTime: '3 min',
    icon: 'PieChart',
    simpleDefinition: 'Spreading your money across different companies, industries, and asset classes so no single failure can ruin you.',
    realLifeExample: 'If a farmer only plants tomatoes and a storm destroys tomato crops, they go bankrupt. If they plant wheat, corn, and fruit, they survive.',
    benefits: [
      'Reduces the total risk of your overall portfolio without sacrificing long-term returns',
      'Smooths out bumpy market rides and prevents catastrophic losses'
    ],
    risks: [
      'Over-diversifying into hundreds of identical funds adds unnecessary complexity'
    ],
    whenUseful: 'All the time, across every stage of your investing journey.',
    keyTakeaway: 'Never bet everything on a single stock, single company, or single asset class.'
  },
  {
    id: 'investment-risk',
    title: 'Understanding Risk: Volatility vs. Real Loss',
    category: 'Mindset',
    readTime: '4 min',
    icon: 'AlertTriangle',
    simpleDefinition: 'Risk is the chance that an investment’s actual return will be different from expected, or that you lose purchasing power.',
    realLifeExample: 'Driving on a highway is risky, but wearing a seatbelt, driving at safe speeds, and driving a tested car minimizes that danger.',
    benefits: [
      'Taking calculated risk is the only way to earn returns above inflation',
      'Understanding your tolerance prevents emotional panic selling'
    ],
    risks: [
      'Confusing normal market ups and downs with permanent loss of capital'
    ],
    whenUseful: 'Before choosing any investment product or allocating your monthly paycheck.',
    keyTakeaway: 'The biggest risk is taking no risk at all, because inflation silently guarantees you lose value.'
  },
  {
    id: 'inflation',
    title: 'Inflation: The Silent Wealth Destroyer',
    category: 'Foundations',
    readTime: '3 min',
    icon: 'Flame',
    simpleDefinition: 'The steady upward climb of prices that makes money worth less over time.',
    realLifeExample: 'If a cup of tea was ₹5 in 2005 and is ₹20 today, keeping a ₹100 note in a cupboard lost 75% of its tea-buying capability.',
    benefits: [
      'Recognizing inflation motivates smart investing rather than hoarding cash'
    ],
    risks: [
      'Ignoring inflation makes safe-looking cash accounts lose real value every year'
    ],
    whenUseful: 'When setting future goal targets (e.g. accounting for future education or retirement costs).',
    keyTakeaway: 'Your investments must earn more than inflation just to preserve your current standard of living.'
  },
  {
    id: 'compound-growth',
    title: 'Compound Growth: Why Starting Early Matters Most',
    category: 'Foundations',
    readTime: '4 min',
    icon: 'Zap',
    simpleDefinition: 'Earning returns not only on your original invested money, but also on all the accumulated returns from previous years.',
    realLifeExample: 'A small snowball rolled down a snowy hill starts small, but picks up more snow with every revolution until it becomes a giant boulder.',
    benefits: [
      'Exponential wealth accumulation in the later years of an investment journey',
      'Someone starting at age 22 can invest less total money than someone starting at 35 and end up with more!'
    ],
    risks: [
      'Compounding takes time: The first 3-5 years feel slow, requiring patience'
    ],
    whenUseful: 'Every long-term investment horizon (10, 20, 30 years).',
    keyTakeaway: 'Time in the market is vastly more powerful than timing the market. Start with whatever you have today.'
  },
  {
    id: 'emergency-fund',
    title: 'Emergency Fund: Your Financial Airbag',
    category: 'Safety',
    readTime: '3 min',
    icon: 'LifeBuoy',
    simpleDefinition: 'A liquid stash of money equal to 3–6 months of basic living costs, reserved strictly for genuine emergencies.',
    realLifeExample: 'An umbrella you carry when dark clouds appear. You do not buy an umbrella after the downpour has already soaked you.',
    benefits: [
      'Eliminates the fear of sudden medical bills, appliance breakdowns, or job transitions',
      'Protects your long-term investment portfolio from being cashed out prematurely during downturns'
    ],
    risks: [
      'Using the emergency fund for vacations or shopping impulses destroys your financial safety net'
    ],
    whenUseful: 'Step 1 before putting a single rupee or dollar into volatile equity markets.',
    keyTakeaway: 'Build your safety cushion first; then invest with unshakeable confidence.'
  },
  {
    id: 'asset-allocation',
    title: 'Asset Allocation: Aligning Money with Life Milestones',
    category: 'Strategy',
    readTime: '4 min',
    icon: 'Compass',
    simpleDefinition: 'Assigning specific portions of your money into Equity, Debt, and Cash depending on your timeline and risk comfort.',
    realLifeExample: 'Packing clothes for a trip: you bring a warm jacket for cold mornings, lightweight clothes for hot afternoons, and rain gear just in case.',
    benefits: [
      'Accounts for over 90% of the variation in portfolio returns over time',
      'Automatically matches your investments with when you will actually need the cash'
    ],
    risks: [
      'Failing to rebalance once or twice a year when one asset grows disproportionately'
    ],
    whenUseful: 'Designing your overall financial plan and reviewing it annually.',
    keyTakeaway: 'Asset allocation is personal: your ideal mix depends on your life stage, not what your colleague is doing.'
  }
];

export const DEMO_USER_PROFILE = {
  age: 25,
  employmentStatus: 'salaried' as const,
  monthlyIncome: 50000,
  monthlyExpenses: 30000,
  existingSavings: 200000,
  emergencyFund: 90000,
  currentInvestments: 50000,
  existingDebt: 120000,
  monthlyEmi: 5000,
  currency: 'INR' as const,
  onboardingComplete: true,
  beginnerMode: true,
};

export const DEMO_GOALS = [
  {
    id: 'goal-emergency',
    name: 'Full 6-Month Emergency Cushion',
    category: 'emergency' as const,
    targetAmount: 180000,
    currentAmount: 90000,
    targetYear: 2027,
    priority: 'high' as const,
  },
  {
    id: 'goal-car',
    name: 'First Electric Car Downpayment',
    category: 'vehicle' as const,
    targetAmount: 400000,
    currentAmount: 80000,
    targetYear: 2029,
    priority: 'medium' as const,
  },
  {
    id: 'goal-wealth',
    name: 'Long-term Wealth & Financial Freedom',
    category: 'wealth' as const,
    targetAmount: 2500000,
    currentAmount: 70000,
    targetYear: 2036,
    priority: 'high' as const,
  }
];

export const DEMO_RISK_ANSWERS = {
  1: 3, // Market drop 20%: Continue investing
  2: 3, // Horizon: 3-7 years
  3: 3, // Objective: Balanced growth
  4: 3  // Comfort with swings: Comfortable
};
