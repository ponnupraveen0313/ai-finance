import React, { useState, useEffect } from 'react';
import { 
  UserProfile, 
  FinancialGoal, 
  RiskProfile 
} from './types';
import { 
  calculateFinancialAnalysis, 
  evaluateRiskAnswers, 
  generateDynamicAssetAllocation, 
  generateSmartRecommendations 
} from './utils/financialCalculations';
import { 
  DEMO_USER_PROFILE, 
  DEMO_GOALS, 
  DEMO_RISK_ANSWERS 
} from './data/educationData';
import { Navbar } from './components/Navbar';
import { MobileBottomNav } from './components/MobileBottomNav';
import { LandingPage } from './components/LandingPage';
import { OnboardingFlow } from './components/OnboardingFlow';
import { DashboardView } from './components/DashboardView';
import { PlanAllocationView } from './components/PlanAllocationView';
import { GoalsView } from './components/GoalsView';
import { HealthCheckView } from './components/HealthCheckView';
import { CalculatorsView } from './components/CalculatorsView';
import { EducationView } from './components/EducationView';
import { AiChatView } from './components/AiChatView';
import { ProfileView } from './components/ProfileView';
import { ExplainModal } from './components/ExplainModal';

const DEFAULT_FRESH_PROFILE: UserProfile = {
  age: 26,
  employmentStatus: 'salaried',
  monthlyIncome: 45000,
  monthlyExpenses: 25000,
  existingSavings: 80000,
  emergencyFund: 40000,
  currentInvestments: 20000,
  existingDebt: 50000,
  monthlyEmi: 4000,
  currency: 'INR',
  onboardingComplete: false,
  beginnerMode: true,
};

export default function App() {
  // Local storage profile state
  const [profile, setProfile] = useState<UserProfile>(() => {
    const saved = localStorage.getItem('smartvest_user_profile');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        console.error('Error parsing profile', e);
      }
    }
    return DEFAULT_FRESH_PROFILE;
  });

  const [goals, setGoals] = useState<FinancialGoal[]>(() => {
    const saved = localStorage.getItem('smartvest_goals');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        console.error('Error parsing goals', e);
      }
    }
    return DEMO_GOALS;
  });

  const [riskAnswers, setRiskAnswers] = useState<Record<number, number>>(() => {
    const saved = localStorage.getItem('smartvest_risk_answers');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        console.error('Error parsing risk answers', e);
      }
    }
    return DEMO_RISK_ANSWERS;
  });

  const [activeTab, setActiveTab] = useState<string>('dashboard');
  const [isOnboardingOpen, setIsOnboardingOpen] = useState<boolean>(false);
  const [explainTerm, setExplainTerm] = useState<string | null>(null);

  // Sync state to LocalStorage
  useEffect(() => {
    localStorage.setItem('smartvest_user_profile', JSON.stringify(profile));
  }, [profile]);

  useEffect(() => {
    localStorage.setItem('smartvest_goals', JSON.stringify(goals));
  }, [goals]);

  useEffect(() => {
    localStorage.setItem('smartvest_risk_answers', JSON.stringify(riskAnswers));
  }, [riskAnswers]);

  // Financial Analysis & Calculations
  const riskProfile = evaluateRiskAnswers(riskAnswers);
  const analysis = calculateFinancialAnalysis(profile, goals, riskProfile);
  const allocationItems = generateDynamicAssetAllocation(profile, riskProfile.category, analysis);
  const recommendations = generateSmartRecommendations(profile, analysis, riskProfile, goals);

  const handleStartOnboarding = () => {
    setIsOnboardingOpen(true);
  };

  const handleExploreDemo = () => {
    const demoProfile = { ...DEMO_USER_PROFILE, onboardingComplete: true };
    setProfile(demoProfile);
    setGoals(DEMO_GOALS);
    setRiskAnswers(DEMO_RISK_ANSWERS);
    setIsOnboardingOpen(false);
    setActiveTab('dashboard');
  };

  const handleCompleteOnboarding = (
    newProfile: UserProfile,
    newGoals: FinancialGoal[],
    newRiskAnswers: Record<number, number>
  ) => {
    setProfile(newProfile);
    setGoals(newGoals);
    setRiskAnswers(newRiskAnswers);
    setIsOnboardingOpen(false);
    setActiveTab('dashboard');
  };

  const handleResetData = () => {
    if (window.confirm('Reset all financial data back to defaults?')) {
      localStorage.removeItem('smartvest_user_profile');
      localStorage.removeItem('smartvest_goals');
      localStorage.removeItem('smartvest_risk_answers');
      localStorage.removeItem('smartvest_chat_history');
      setProfile(DEFAULT_FRESH_PROFILE);
      setGoals(DEMO_GOALS);
      setRiskAnswers(DEMO_RISK_ANSWERS);
      setActiveTab('dashboard');
      setIsOnboardingOpen(false);
    }
  };

  const handleExplain = (term: string) => {
    setExplainTerm(term);
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 flex flex-col font-sans antialiased selection:bg-emerald-100 selection:text-emerald-900">
      {/* Top Navbar */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        profile={profile}
        setProfile={setProfile}
        onLoadDemo={handleExploreDemo}
        onReset={handleResetData}
        onExplain={handleExplain}
      />

      {/* Main Body */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 pb-24 lg:pb-12">
        {/* If user hasn't onboarded and isn't currently onboarding, show Landing Page */}
        {!profile.onboardingComplete && !isOnboardingOpen ? (
          <LandingPage
            onStartOnboarding={handleStartOnboarding}
            onExploreDemo={handleExploreDemo}
            onExplain={handleExplain}
            beginnerMode={profile.beginnerMode}
          />
        ) : isOnboardingOpen ? (
          /* Onboarding Questionnaire Wizard */
          <OnboardingFlow
            initialProfile={profile}
            initialGoals={goals}
            initialRiskAnswers={riskAnswers}
            onComplete={handleCompleteOnboarding}
            onCancel={() => setIsOnboardingOpen(false)}
            onExplain={handleExplain}
          />
        ) : (
          /* Active Tabs */
          <>
            {activeTab === 'dashboard' && (
              <DashboardView
                profile={profile}
                analysis={analysis}
                riskProfile={riskProfile}
                goals={goals}
                allocationItems={allocationItems}
                recommendations={recommendations}
                onNavigate={(t) => setActiveTab(t)}
                onExplain={handleExplain}
              />
            )}

            {activeTab === 'plan' && (
              <PlanAllocationView
                profile={profile}
                riskProfile={riskProfile}
                analysis={analysis}
                allocationItems={allocationItems}
                recommendations={recommendations}
                onExplain={handleExplain}
                onOpenChat={() => setActiveTab('chat')}
              />
            )}

            {activeTab === 'goals' && (
              <GoalsView
                goals={goals}
                setGoals={setGoals}
                profile={profile}
                analysis={analysis}
                onExplain={handleExplain}
              />
            )}

            {activeTab === 'health' && (
              <HealthCheckView
                profile={profile}
                analysis={analysis}
                riskProfile={riskProfile}
                goals={goals}
                onExplain={handleExplain}
                onNavigate={(t) => setActiveTab(t)}
              />
            )}

            {activeTab === 'calculators' && (
              <CalculatorsView
                profile={profile}
                onExplain={handleExplain}
              />
            )}

            {activeTab === 'learn' && (
              <EducationView
                onExplain={handleExplain}
                beginnerMode={profile.beginnerMode}
              />
            )}

            {activeTab === 'chat' && (
              <AiChatView
                profile={profile}
                analysis={analysis}
                riskProfile={riskProfile}
                goals={goals}
                onExplain={handleExplain}
              />
            )}

            {activeTab === 'profile' && (
              <ProfileView
                profile={profile}
                setProfile={setProfile}
                onRetakeRisk={() => setIsOnboardingOpen(true)}
                onResetData={handleResetData}
                onLoadDemo={handleExploreDemo}
                onExplain={handleExplain}
              />
            )}
          </>
        )}
      </main>

      {/* Mobile Fixed Bottom Navigation */}
      {profile.onboardingComplete && !isOnboardingOpen && (
        <MobileBottomNav activeTab={activeTab} setActiveTab={setActiveTab} />
      )}

      {/* Smart Term Explainer Modal */}
      <ExplainModal
        termKey={explainTerm}
        onClose={() => setExplainTerm(null)}
        beginnerMode={profile.beginnerMode}
      />
    </div>
  );
}
