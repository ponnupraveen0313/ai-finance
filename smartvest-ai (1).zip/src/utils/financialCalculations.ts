import { 
  UserProfile, 
  FinancialGoal, 
  RiskProfile, 
  RiskCategory, 
  FinancialAnalysis, 
  AssetAllocationItem, 
  Recommendation 
} from '../types';

export function formatCurrency(amount: number, currency: 'INR' | 'USD' = 'INR', compact = false): string {
  const symbol = currency === 'INR' ? '₹' : '$';
  if (isNaN(amount) || amount === null || amount === undefined) {
    return `${symbol}0`;
  }

  const absAmount = Math.abs(amount);
  const sign = amount < 0 ? '-' : '';

  if (compact) {
    if (currency === 'INR') {
      if (absAmount >= 10000000) {
        return `${sign}${symbol}${(absAmount / 10000000).toFixed(2)} Cr`;
      }
      if (absAmount >= 100000) {
        return `${sign}${symbol}${(absAmount / 100000).toFixed(2)} Lakh`;
      }
      if (absAmount >= 1000) {
        return `${sign}${symbol}${(absAmount / 1000).toFixed(1)}k`;
      }
      return `${sign}${symbol}${Math.round(absAmount)}`;
    } else {
      if (absAmount >= 1000000) {
        return `${sign}${symbol}${(absAmount / 1000000).toFixed(2)}M`;
      }
      if (absAmount >= 1000) {
        return `${sign}${symbol}${(absAmount / 1000).toFixed(1)}k`;
      }
      return `${sign}${symbol}${Math.round(absAmount)}`;
    }
  }

  // Full locale formatting
  const formatted = Math.round(absAmount).toLocaleString(currency === 'INR' ? 'en-IN' : 'en-US');
  return `${sign}${symbol}${formatted}`;
}

export function calculateFinancialAnalysis(
  profile: UserProfile,
  goals: FinancialGoal[] = [],
  riskProfile?: RiskProfile
): FinancialAnalysis {
  const monthlySavings = profile.monthlyIncome - profile.monthlyExpenses - profile.monthlyEmi;
  const savingsRate = profile.monthlyIncome > 0 ? (monthlySavings / profile.monthlyIncome) * 100 : 0;
  
  const emergencyFundMonths = profile.monthlyExpenses > 0 
    ? profile.emergencyFund / profile.monthlyExpenses 
    : 0;

  const debtToIncomeRatio = profile.monthlyIncome > 0 
    ? (profile.monthlyEmi / profile.monthlyIncome) * 100 
    : 0;

  const totalAssets = profile.existingSavings + profile.emergencyFund + profile.currentInvestments;
  const totalLiabilities = profile.existingDebt;
  const netWorth = totalAssets - totalLiabilities;

  // Safe investable capacity
  let investableCapacity = 0;
  if (monthlySavings > 0) {
    if (emergencyFundMonths < 2) {
      // Allocate 70% to emergency reserve, 30% to low-risk investment
      investableCapacity = Math.max(0, monthlySavings * 0.35);
    } else if (emergencyFundMonths < 4) {
      // Allocate 50% to emergency reserve, 50% to investing
      investableCapacity = Math.max(0, monthlySavings * 0.55);
    } else if (emergencyFundMonths < 6) {
      // Allocate 25% to emergency reserve, 75% to investing
      investableCapacity = Math.max(0, monthlySavings * 0.75);
    } else {
      // 85-90% to investing, leaving small operational buffer
      investableCapacity = Math.max(0, monthlySavings * 0.85);
    }
  }

  // Sub-scores (0-100)
  // Savings Score: Target is >= 20%
  let savingsScore = 0;
  if (savingsRate >= 30) savingsScore = 95;
  else if (savingsRate >= 20) savingsScore = 85;
  else if (savingsRate >= 15) savingsScore = 72;
  else if (savingsRate >= 10) savingsScore = 58;
  else if (savingsRate > 0) savingsScore = 40;
  else savingsScore = 15;

  // Emergency Fund Score: Target 3 to 6 months
  let emergencyScore = 0;
  if (emergencyFundMonths >= 6) emergencyScore = 95;
  else if (emergencyFundMonths >= 4) emergencyScore = 85;
  else if (emergencyFundMonths >= 3) emergencyScore = 75;
  else if (emergencyFundMonths >= 1.5) emergencyScore = 55;
  else if (emergencyFundMonths > 0) emergencyScore = 35;
  else emergencyScore = 10;

  // Debt Score: Lower EMI ratio is better
  let debtScore = 0;
  if (debtToIncomeRatio === 0 && profile.existingDebt === 0) debtScore = 98;
  else if (debtToIncomeRatio < 15) debtScore = 88;
  else if (debtToIncomeRatio < 30) debtScore = 75;
  else if (debtToIncomeRatio < 45) debtScore = 50;
  else debtScore = 25;

  // Goal Readiness Score: Can the user afford their required goal contributions?
  let totalGoalMonthlyRequired = 0;
  const currentYear = new Date().getFullYear();
  goals.forEach(goal => {
    const remaining = Math.max(0, goal.targetAmount - goal.currentAmount);
    const months = Math.max(6, (goal.targetYear - currentYear) * 12);
    totalGoalMonthlyRequired += remaining / months;
  });

  let goalsScore = 70;
  if (goals.length > 0) {
    if (monthlySavings <= 0) {
      goalsScore = 25;
    } else {
      const coverageRatio = monthlySavings / totalGoalMonthlyRequired;
      if (coverageRatio >= 1.2) goalsScore = 90;
      else if (coverageRatio >= 0.8) goalsScore = 78;
      else if (coverageRatio >= 0.5) goalsScore = 60;
      else goalsScore = 40;
    }
  }

  // Investment Readiness Score
  let readinessScore = 50;
  if (emergencyFundMonths >= 3 && monthlySavings > 0 && debtToIncomeRatio < 35) {
    readinessScore = 88;
  } else if (emergencyFundMonths >= 2 && monthlySavings > 0) {
    readinessScore = 72;
  } else if (monthlySavings > 0) {
    readinessScore = 55;
  } else {
    readinessScore = 20;
  }

  // Overall Weighted Financial Health Score
  const healthScore = Math.round(
    savingsScore * 0.25 +
    emergencyScore * 0.25 +
    debtScore * 0.20 +
    goalsScore * 0.15 +
    readinessScore * 0.15
  );

  const emergencyStatus = emergencyFundMonths >= 4 ? 'good' : emergencyFundMonths >= 2 ? 'attention' : 'critical';
  const debtStatus = debtToIncomeRatio <= 25 ? 'good' : debtToIncomeRatio <= 40 ? 'attention' : 'critical';
  const savingsStatus = savingsRate >= 20 ? 'good' : savingsRate >= 10 ? 'attention' : 'critical';
  const goalReadinessStatus = goalsScore >= 75 ? 'good' : goalsScore >= 50 ? 'attention' : 'critical';

  return {
    monthlySavings: Math.round(monthlySavings),
    savingsRate: Math.round(savingsRate * 10) / 10,
    emergencyFundMonths: Math.round(emergencyFundMonths * 10) / 10,
    debtToIncomeRatio: Math.round(debtToIncomeRatio * 10) / 10,
    netWorth: Math.round(netWorth),
    investableCapacity: Math.round(investableCapacity),
    healthScore,
    healthBreakdown: {
      savings: savingsScore,
      emergency: emergencyScore,
      debt: debtScore,
      goals: goalsScore,
      readiness: readinessScore,
    },
    emergencyStatus,
    debtStatus,
    savingsStatus,
    goalReadinessStatus,
  };
}

export function evaluateRiskAnswers(answers: Record<number, number>): RiskProfile {
  // Score sums from 4 questions, each scored 1 to 4
  const questionWeights: Record<number, number> = { 1: 1, 2: 1, 3: 1, 4: 1 };
  let totalScore = 0;
  let count = 0;

  for (const qId of [1, 2, 3, 4]) {
    const val = answers[qId] || 2; // default moderate
    totalScore += val;
    count++;
  }

  const maxScore = count * 4; // 16
  let category: RiskCategory = 'Moderate';
  let tagline = '';
  let description = '';
  let suggestedHorizon = '3-5 years';
  const influencingFactors: string[] = [];

  if (totalScore <= 6) {
    category = 'Conservative';
    tagline = 'Capital Protection First';
    description = 'You strongly prioritize preserving your hard-earned money over high returns. You feel stressed by market drops and prefer stable, predictable growth.';
    suggestedHorizon = '1-3 years';
    influencingFactors.push('Preference to protect money and avoid paper losses');
    influencingFactors.push('Shorter time horizon or lower comfort with fluctuations');
    influencingFactors.push('Reaction to 20% market dip: Sell or seek immediate safety');
  } else if (totalScore <= 9) {
    category = 'Moderately Conservative';
    tagline = 'Safety with Gentle Growth';
    description = 'You want your money to stay safe, but you also recognize that inflation slowly eats cash. You are willing to accept modest fluctuations for a bit of extra growth.';
    suggestedHorizon = '2-4 years';
    influencingFactors.push('Desire to beat inflation without riding heavy stock market swings');
    influencingFactors.push('Preference for steady fixed-income with a small equity slice');
    influencingFactors.push('Cautious stance during market turbulence');
  } else if (totalScore <= 12) {
    category = 'Moderate';
    tagline = 'Balanced Long-Term Growth';
    description = 'Based on your answers, you are comfortable with regular ups and downs in exchange for potential long-term wealth compounding over 4+ years.';
    suggestedHorizon = '4-7 years';
    influencingFactors.push('Comfortable holding through temporary market downturns');
    influencingFactors.push('Medium to long-term horizon allowing time to ride market cycles');
    influencingFactors.push('Desire for a healthy mix of growth (equities) and stability (debt/FD)');
  } else if (totalScore <= 14) {
    category = 'Moderately Aggressive';
    tagline = 'Growth-Oriented Compounding';
    description = 'You have a healthy appetite for market growth and understand that short-term volatility is the entry price for higher potential long-term returns.';
    suggestedHorizon = '5-10 years';
    influencingFactors.push('Willingness to buy more or hold steadily when prices dip');
    influencingFactors.push('Substantial time horizon before needing the funds');
    influencingFactors.push('Confidence in equity markets as primary wealth vehicle');
  } else {
    category = 'Aggressive';
    tagline = 'Maximum Long-Term Wealth Potential';
    description = 'You view market dips as buying opportunities. With a long investment runway, you seek maximum compounding power through heavy equity exposure.';
    suggestedHorizon = '7+ years';
    influencingFactors.push('Highest risk tolerance and emotional comfort with large volatility');
    influencingFactors.push('Action during 20% drop: Invest more at cheaper valuations');
    influencingFactors.push('Long investment horizon (>7 years) to smooth out cyclical bear markets');
  }

  return {
    score: totalScore,
    maxScore,
    category,
    tagline,
    description,
    influencingFactors,
    suggestedHorizon,
    answers,
  };
}

export function generateDynamicAssetAllocation(
  profile: UserProfile,
  riskCategory: RiskCategory,
  analysis: FinancialAnalysis
): AssetAllocationItem[] {
  const investable = Math.max(1000, analysis.investableCapacity);
  const emergencyNeeded = analysis.emergencyFundMonths < 3;

  let equityPct = 50;
  let debtPct = 30;
  let emergencyPct = 12;
  let goldPct = 8;

  switch (riskCategory) {
    case 'Conservative':
      equityPct = 15;
      debtPct = 55;
      emergencyPct = 20;
      goldPct = 10;
      break;
    case 'Moderately Conservative':
      equityPct = 30;
      debtPct = 45;
      emergencyPct = 15;
      goldPct = 10;
      break;
    case 'Moderate':
      equityPct = 50;
      debtPct = 30;
      emergencyPct = 12;
      goldPct = 8;
      break;
    case 'Moderately Aggressive':
      equityPct = 65;
      debtPct = 20;
      emergencyPct = 10;
      goldPct = 5;
      break;
    case 'Aggressive':
      equityPct = 75;
      debtPct = 12;
      emergencyPct = 8;
      goldPct = 5;
      break;
  }

  // If user emergency fund is critically low, dynamically shift more toward liquid/emergency savings
  if (emergencyNeeded) {
    const shift = 10;
    equityPct = Math.max(10, equityPct - shift);
    emergencyPct += shift;
  }

  // Ensure sum equals 100
  const total = equityPct + debtPct + emergencyPct + goldPct;
  if (total !== 100) {
    debtPct += (100 - total);
  }

  const items: AssetAllocationItem[] = [
    {
      id: 'equity',
      name: 'Diversified Equity',
      categoryName: 'Stocks & Company Ownership',
      percentage: equityPct,
      amount: Math.round((investable * equityPct) / 100),
      color: '#10B981', // Emerald
      simpleDescription: 'Investing in shares of well-established companies. It can grow faster over many years, but its value can go up and down in the short term.',
      technicalDescription: 'Capital invested in public equities, index mutual funds, and large/flexi-cap funds designed for long-term capital appreciation.',
      benefits: [
        'Historically outpaces inflation significantly over 5+ year periods',
        'Generates wealth through corporate revenue and dividend growth',
        'High liquidity with broad market index funds'
      ],
      risks: [
        'Market volatility: values can drop 10-25% during periodic economic pullbacks',
        'Not suitable for money needed within the next 2-3 years'
      ],
      timeHorizon: '5 years or more',
      whyForYou: `Tailored to your ${riskCategory} risk profile to provide compounding growth while matching your tolerance for market movements.`,
      examples: ['Nifty 50 / S&P 500 Index Funds', 'Diversified Flexi-cap Mutual Funds', 'Large-cap Bluechip Funds']
    },
    {
      id: 'debt',
      name: 'Debt & Fixed Income',
      categoryName: 'Bonds & Fixed Deposits',
      percentage: debtPct,
      amount: Math.round((investable * debtPct) / 100),
      color: '#3B82F6', // Blue
      simpleDescription: 'Lending money to governments or stable banks in exchange for regular, steady interest payments. Very safe and predictable.',
      technicalDescription: 'Fixed income instruments including sovereign bonds, corporate debt funds, target-maturity funds, and high-quality fixed deposits.',
      benefits: [
        'Predictable, steady interest returns with minimal volatility',
        'Acts as a stabilizing anchor when equity markets experience a downturn',
        'Helps preserve capital for medium-term obligations'
      ],
      risks: [
        'Lower return potential compared to equities',
        'Vulnerable to high inflation over very long horizons'
      ],
      timeHorizon: '1 to 4 years',
      whyForYou: `Protects your principal, generates reliable interest, and dampens overall portfolio swings.`,
      examples: ['Corporate Bond Funds', 'Government Securities (G-Sec)', 'Banking & PSU Debt Funds', 'Fixed Deposits']
    },
    {
      id: 'emergency',
      name: 'Liquid & Emergency Cash',
      categoryName: 'Safety Buffer',
      percentage: emergencyPct,
      amount: Math.round((investable * emergencyPct) / 100),
      color: '#F59E0B', // Amber
      simpleDescription: 'Cash kept in a safe place that you can withdraw at any minute if an unexpected bill or emergency arrives.',
      technicalDescription: 'Ultra-short duration overnight or liquid mutual funds and high-interest savings accounts designed for capital preservation and instant liquidity.',
      benefits: [
        'Zero waiting time — access your money whenever life surprises happen',
        'Prevents you from taking high-interest credit card debt or distress loans',
        'Zero volatility risk'
      ],
      risks: [
        'Returns are modest (typically equal to or below inflation)',
        'Not meant for long-term wealth creation'
      ],
      timeHorizon: 'Immediate / Anytime',
      whyForYou: analysis.emergencyFundMonths < 3 
        ? 'High priority: Your current emergency cushion is below the recommended 3-6 months of expenses.'
        : 'Maintains your peace of mind and covers unexpected healthcare, repairs, or temporary job gaps.',
      examples: ['High-yield Savings Accounts', 'Liquid Mutual Funds', 'Overnight Funds', 'Instant-access Sweep FDs']
    },
    {
      id: 'gold',
      name: 'Gold & Inflation Hedges',
      categoryName: 'Precious Metals & Real Assets',
      percentage: goldPct,
      amount: Math.round((investable * goldPct) / 100),
      color: '#8B5CF6', // Purple
      simpleDescription: 'Investing in gold or commodities that historically hold their purchasing power when currencies weaken or during global uncertainty.',
      technicalDescription: 'Sovereign Gold Bonds (SGB), Gold ETFs, or multi-asset commodity funds that provide negative or low correlation to equities.',
      benefits: [
        'Historically serves as a store of value during geopolitical turbulence',
        'Low correlation with standard stock and bond cycles for added diversification',
        'Preserves purchasing power against long-term currency depreciation'
      ],
      risks: [
        'Does not generate organic business dividends or interest payments',
        'Can trade sideways for extended periods'
      ],
      timeHorizon: '3 to 5+ years',
      whyForYou: `Provides an all-weather safety hedge so all your eggs are not in paper assets.`,
      examples: ['Gold ETFs', 'Sovereign Gold Bonds (SGB)', 'Digital Gold / Gold Mutual Funds']
    }
  ];

  return items;
}

export function generateSmartRecommendations(
  profile: UserProfile,
  analysis: FinancialAnalysis,
  riskProfile: RiskProfile,
  goals: FinancialGoal[]
): Recommendation[] {
  const recommendations: Recommendation[] = [];

  // Recommendation 1: Emergency Fund
  if (analysis.emergencyFundMonths < 3) {
    recommendations.push({
      id: 'rec-emergency-low',
      title: 'Build your Emergency Cushion before taking higher market risks',
      why: `Your current emergency fund of ${formatCurrency(profile.emergencyFund, profile.currency)} covers only ~${analysis.emergencyFundMonths.toFixed(1)} months of living expenses. A safe minimum is 3 to 6 months (${formatCurrency(profile.monthlyExpenses * 3, profile.currency)}).`,
      priority: 'high',
      suggestedAction: `Direct at least 50% of your monthly savings (${formatCurrency(analysis.monthlySavings * 0.5, profile.currency)}) into a high-interest savings account or liquid fund until you reach 3 months of expenses.`,
      category: 'emergency',
      dataInfluences: [
        `Monthly expenses: ${formatCurrency(profile.monthlyExpenses, profile.currency)}`,
        `Current emergency savings: ${formatCurrency(profile.emergencyFund, profile.currency)}`,
        `Coverage ratio: ${analysis.emergencyFundMonths.toFixed(1)} months (target: 3-6 months)`
      ]
    });
  } else if (analysis.emergencyFundMonths >= 6) {
    recommendations.push({
      id: 'rec-emergency-solid',
      title: 'Strong emergency buffer: Ready for dedicated goal investing',
      why: `You have successfully built a robust ${analysis.emergencyFundMonths.toFixed(1)}-month emergency reserve. This provides full insulation against unexpected expenses so you will not need to sell your investments early.`,
      priority: 'low',
      suggestedAction: 'Keep your emergency fund liquid and focus your new monthly surpluses directly toward your long-term wealth goals.',
      category: 'emergency',
      dataInfluences: [
        `Emergency buffer: ${analysis.emergencyFundMonths.toFixed(1)} months of expenses`,
        `Total liquid reserve: ${formatCurrency(profile.emergencyFund, profile.currency)}`
      ]
    });
  }

  // Recommendation 2: Debt burden
  if (analysis.debtToIncomeRatio > 35) {
    recommendations.push({
      id: 'rec-debt-heavy',
      title: 'Prioritize paying down high-cost debt to boost investment capacity',
      why: `Your monthly EMIs (${formatCurrency(profile.monthlyEmi, profile.currency)}) consume ${analysis.debtToIncomeRatio.toFixed(1)}% of your income. Financial planners recommend keeping total debt service under 30%.`,
      priority: 'high',
      suggestedAction: 'Consider the debt-avalanche strategy (paying highest interest debt first) to free up recurring monthly cashflow.',
      category: 'debt',
      dataInfluences: [
        `Monthly EMI: ${formatCurrency(profile.monthlyEmi, profile.currency)}`,
        `Income spent on debt: ${analysis.debtToIncomeRatio.toFixed(1)}% (ideal: < 30%)`,
        `Outstanding debt: ${formatCurrency(profile.existingDebt, profile.currency)}`
      ]
    });
  }

  // Recommendation 3: Disciplined SIP Investing
  if (analysis.investableCapacity > 0) {
    recommendations.push({
      id: 'rec-sip-start',
      title: `Start an automated monthly SIP of ~${formatCurrency(analysis.investableCapacity, profile.currency)}`,
      why: `Systematic Investment Plans eliminate emotional market timing and take advantage of rupee-cost averaging across market cycles.`,
      priority: 'medium',
      suggestedAction: `Set up an auto-debit on the 5th of each month (right after payday) split across broad index funds and debt funds as suggested in your plan.`,
      category: 'investing',
      dataInfluences: [
        `Monthly savings: ${formatCurrency(analysis.monthlySavings, profile.currency)}`,
        `Calculated investable capacity: ${formatCurrency(analysis.investableCapacity, profile.currency)}`,
        `Risk profile: ${riskProfile.category}`
      ]
    });
  }

  // Recommendation 4: Goals feasibility
  if (goals.length > 0) {
    const currentYear = new Date().getFullYear();
    const shortTermGoals = goals.filter(g => (g.targetYear - currentYear) <= 3);
    if (shortTermGoals.length > 0) {
      recommendations.push({
        id: 'rec-short-goals',
        title: 'Keep short-term goal funds away from volatile equities',
        why: `You have ${shortTermGoals.length} goal(s) due within 3 years (${shortTermGoals.map(g => g.name).join(', ')}). The stock market can experience cyclical dips that require years to recover.`,
        priority: 'medium',
        suggestedAction: 'Park money for these short-term targets in capital-safe debt mutual funds, recurring deposits, or fixed deposits rather than pure equity.',
        category: 'goals',
        dataInfluences: [
          `Short-term targets: ${shortTermGoals.map(g => `${g.name} (${g.targetYear})`).join(', ')}`,
          `Time horizon: under 36 months`
        ]
      });
    }
  } else {
    recommendations.push({
      id: 'rec-add-goals',
      title: 'Define specific financial goals to give your money direction',
      why: 'Investing without concrete targets makes it hard to choose the right time horizon and asset allocation.',
      priority: 'low',
      suggestedAction: 'Go to the Goal Planner to add milestones like Emergency Fund, Buying a Vehicle, House Downpayment, or Retirement.',
      category: 'goals',
      dataInfluences: ['Zero custom goals configured currently']
    });
  }

  // Recommendation 5: Risk Alignment
  if (riskProfile.category === 'Conservative' && analysis.savingsRate > 25) {
    recommendations.push({
      id: 'rec-risk-conservative',
      title: 'Consider a modest equity allocation to protect against long-term inflation',
      why: 'While preserving capital is key, keeping 100% of money in low-interest accounts causes purchasing power loss over decades due to inflation.',
      priority: 'medium',
      suggestedAction: 'A gentle 15-20% exposure to broad-market index funds can help maintain real purchasing power without causing intense volatility.',
      category: 'investing',
      dataInfluences: [
        `Risk profile: ${riskProfile.category}`,
        `Current savings rate: ${analysis.savingsRate}%`
      ]
    });
  }

  return recommendations;
}

// Calculators math
export function calculateSipMath(monthlyInvestment: number, annualReturnRate: number, durationYears: number) {
  const i = (annualReturnRate / 100) / 12; // monthly rate
  const n = durationYears * 12; // total months
  const totalInvested = monthlyInvestment * n;

  let estimatedFinalValue = 0;
  if (i > 0) {
    estimatedFinalValue = monthlyInvestment * ((Math.pow(1 + i, n) - 1) / i) * (1 + i);
  } else {
    estimatedFinalValue = totalInvested;
  }

  const estimatedGrowth = Math.max(0, estimatedFinalValue - totalInvested);

  // Year by year progression
  const yearlyBreakdown = [];
  for (let yr = 1; yr <= durationYears; yr++) {
    const yrMonths = yr * 12;
    const yrInvested = monthlyInvestment * yrMonths;
    const yrValue = i > 0 
      ? monthlyInvestment * ((Math.pow(1 + i, yrMonths) - 1) / i) * (1 + i)
      : yrInvested;
    yearlyBreakdown.push({
      year: yr,
      invested: Math.round(yrInvested),
      growth: Math.round(Math.max(0, yrValue - yrInvested)),
      totalValue: Math.round(yrValue)
    });
  }

  return {
    totalInvested: Math.round(totalInvested),
    estimatedGrowth: Math.round(estimatedGrowth),
    estimatedFinalValue: Math.round(estimatedFinalValue),
    yearlyBreakdown
  };
}

export function calculateGoalMonthlyRequirement(
  targetAmount: number,
  currentSavings: number,
  years: number,
  annualReturnRate = 8
) {
  const remaining = Math.max(0, targetAmount - currentSavings);
  const months = Math.max(1, Math.round(years * 12));
  
  if (remaining <= 0) return 0;
  if (annualReturnRate <= 0) return Math.round(remaining / months);

  const i = (annualReturnRate / 100) / 12;
  // Future value of existing savings:
  const fvOfCurrent = currentSavings * Math.pow(1 + i, months);
  const shortfallAtEnd = Math.max(0, targetAmount - fvOfCurrent);

  if (shortfallAtEnd <= 0) return 0;

  // Monthly SIP needed to reach shortfallAtEnd
  const monthlySip = (shortfallAtEnd * i) / ((Math.pow(1 + i, months) - 1) * (1 + i));
  return Math.round(monthlySip);
}
