import React from 'react';
import { 
  HeartPulse, 
  ShieldCheck, 
  AlertTriangle, 
  CheckCircle2, 
  AlertCircle, 
  ArrowRight, 
  Sparkles,
  TrendingUp,
  Info,
  DollarSign
} from 'lucide-react';
import { UserProfile, FinancialAnalysis, RiskProfile, FinancialGoal } from '../types';
import { formatCurrency } from '../utils/financialCalculations';
import { ExplainBadge } from './ExplainModal';

interface HealthCheckViewProps {
  profile: UserProfile;
  analysis: FinancialAnalysis;
  riskProfile: RiskProfile;
  goals: FinancialGoal[];
  onExplain: (term: string) => void;
  onNavigate: (tab: string) => void;
}

export const HealthCheckView: React.FC<HealthCheckViewProps> = ({
  profile,
  analysis,
  riskProfile,
  goals,
  onExplain,
  onNavigate
}) => {
  const getBadgeClass = (status: 'good' | 'attention' | 'critical') => {
    switch (status) {
      case 'good':
        return 'bg-emerald-100 text-emerald-800 border-emerald-200';
      case 'attention':
        return 'bg-amber-100 text-amber-800 border-amber-200';
      case 'critical':
        return 'bg-rose-100 text-rose-800 border-rose-200';
    }
  };

  const getStatusLabel = (status: 'good' | 'attention' | 'critical') => {
    switch (status) {
      case 'good':
        return 'Good Standing';
      case 'attention':
        return 'Needs Attention';
      case 'critical':
        return 'High Priority';
    }
  };

  return (
    <div className="space-y-8 pb-12">
      {/* Top Health Header */}
      <div className="bg-white rounded-2xl p-6 sm:p-8 shadow-sm border border-slate-200">
        <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold uppercase tracking-wider text-emerald-600">Diagnostic Review</span>
              <span className="text-xs font-bold px-2 py-0.5 rounded-full bg-slate-100 text-slate-700">
                Educational Assessment
              </span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 mt-1">
              Your Financial Health Check
            </h1>
            <p className="text-sm text-slate-600 mt-1 max-w-2xl leading-relaxed">
              Before investing aggressively, it's vital to ensure your financial foundations are rock-solid. Here is where you stand today across the 5 essential financial health pillars.
            </p>
          </div>

          {/* Overall Health Score Card */}
          <div className="bg-gradient-to-tr from-slate-900 to-slate-800 text-white p-5 rounded-2xl shadow-md w-full lg:w-auto min-w-[240px] text-center lg:text-left">
            <span className="text-xs font-bold uppercase tracking-wider text-emerald-400 block">
              Overall Health Score
            </span>
            <div className="flex items-baseline justify-center lg:justify-start gap-1 mt-1">
              <span className="text-4xl font-black">{analysis.healthScore}</span>
              <span className="text-slate-400 text-sm font-bold">/ 100</span>
            </div>
            <div className="mt-2 text-xs text-slate-300 font-medium">
              {analysis.healthScore >= 75 ? 'Strong foundation to compound wealth' :
               analysis.healthScore >= 50 ? 'Stable foundation with room for improvement' :
               'Focus on safety buffer and debt reduction first'}
            </div>
          </div>
        </div>

        {/* Disclaimer bar */}
        <div className="mt-6 p-3 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-500 flex items-center gap-2">
          <Info className="w-4 h-4 text-slate-400 shrink-0" />
          <span>
            This score is an educational health indicator calculated from your entered numbers, not an official credit or legal rating.
          </span>
        </div>
      </div>

      {/* 5 Health Pillars */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Pillar 1: Savings Health */}
        <div className="bg-white rounded-2xl p-6 shadow-sm border border-slate-200 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-emerald-100 text-emerald-700 flex items-center justify-center font-bold">
                  %
                </div>
                <h3 className="font-bold text-slate-900 text-lg">Savings Health</h3>
              </div>
              <span className={`text-xs font-bold px-2.5 py-1 rounded-full border ${getBadgeClass(analysis.savingsStatus)}`}>
                {getStatusLabel(analysis.savingsStatus)}
              </span>
            </div>

            <div className="space-y-2 mt-4 text-xs">
              <div className="flex justify-between py-1 border-b border-slate-100">
                <span className="text-slate-500 font-medium">Your Savings Rate:</span>
                <span className="font-extrabold text-slate-900">{analysis.savingsRate}% of income</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-100">
                <span className="text-slate-500 font-medium">Monthly Savings Surplus:</span>
                <span className="font-extrabold text-emerald-700">{formatCurrency(analysis.monthlySavings, profile.currency)}</span>
              </div>
              <div className="flex justify-between py-1">
                <span className="text-slate-500 font-medium">Recommended Benchmark:</span>
                <span className="font-bold text-slate-700">&gt; 20% of monthly income</span>
              </div>
            </div>

            <p className="mt-4 text-xs text-slate-600 leading-relaxed bg-slate-50 p-3 rounded-xl border border-slate-100">
              {analysis.savingsRate >= 20 ? (
                'You are currently saving a healthy portion of your income, giving you ample room to feed your emergency reserves and long-term investment goals.'
              ) : (
                'Your savings rate is below the ideal 20% mark. Review discretionary expenses (dining out, unused subscriptions) to boost your monthly investing surplus.'
              )}
            </p>
          </div>

          <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
            <span className="text-slate-400 font-medium">Pillar Score: {analysis.healthBreakdown.savings}/100</span>
            <button
              onClick={() => onExplain('sip')}
              className="text-emerald-700 hover:text-emerald-800 font-bold"
            >
              How automated SIP helps →
            </button>
          </div>
        </div>

        {/* Pillar 2: Emergency Fund Health */}
        <div className="bg-white rounded-2xl p-6 shadow-sm border border-slate-200 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-amber-100 text-amber-700 flex items-center justify-center font-bold">
                  🛡️
                </div>
                <div className="flex items-center">
                  <h3 className="font-bold text-slate-900 text-lg">Emergency Cushion</h3>
                  <ExplainBadge term="emergency_fund" onExplain={onExplain} />
                </div>
              </div>
              <span className={`text-xs font-bold px-2.5 py-1 rounded-full border ${getBadgeClass(analysis.emergencyStatus)}`}>
                {getStatusLabel(analysis.emergencyStatus)}
              </span>
            </div>

            <div className="space-y-2 mt-4 text-xs">
              <div className="flex justify-between py-1 border-b border-slate-100">
                <span className="text-slate-500 font-medium">Current Coverage:</span>
                <span className="font-extrabold text-slate-900">{analysis.emergencyFundMonths} Months</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-100">
                <span className="text-slate-500 font-medium">Total Emergency Savings:</span>
                <span className="font-extrabold text-amber-700">{formatCurrency(profile.emergencyFund, profile.currency)}</span>
              </div>
              <div className="flex justify-between py-1">
                <span className="text-slate-500 font-medium">Recommended 6-Mo Target:</span>
                <span className="font-bold text-slate-700">{formatCurrency(profile.monthlyExpenses * 6, profile.currency)}</span>
              </div>
            </div>

            <p className="mt-4 text-xs text-slate-600 leading-relaxed bg-slate-50 p-3 rounded-xl border border-slate-100">
              {analysis.emergencyFundMonths >= 4 ? (
                'You have built a dependable safety airbag! This ensures you won’t be forced to sell down equity investments at a loss if an unexpected bill arrives.'
              ) : (
                'Your emergency reserve is below the safe 3–6 month threshold. We recommend funneling part of your monthly surplus to a liquid account first.'
              )}
            </p>
          </div>

          <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
            <span className="text-slate-400 font-medium">Pillar Score: {analysis.healthBreakdown.emergency}/100</span>
            <button
              onClick={() => onNavigate('plan')}
              className="text-emerald-700 hover:text-emerald-800 font-bold"
            >
              View liquid allocation →
            </button>
          </div>
        </div>

        {/* Pillar 3: Debt Health */}
        <div className="bg-white rounded-2xl p-6 shadow-sm border border-slate-200 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-blue-100 text-blue-700 flex items-center justify-center font-bold">
                  💳
                </div>
                <div className="flex items-center">
                  <h3 className="font-bold text-slate-900 text-lg">Debt & EMI Load</h3>
                  <ExplainBadge term="emi" onExplain={onExplain} />
                </div>
              </div>
              <span className={`text-xs font-bold px-2.5 py-1 rounded-full border ${getBadgeClass(analysis.debtStatus)}`}>
                {getStatusLabel(analysis.debtStatus)}
              </span>
            </div>

            <div className="space-y-2 mt-4 text-xs">
              <div className="flex justify-between py-1 border-b border-slate-100">
                <span className="text-slate-500 font-medium">Debt-to-Income (EMI Ratio):</span>
                <span className="font-extrabold text-slate-900">{analysis.debtToIncomeRatio}% of income</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-100">
                <span className="text-slate-500 font-medium">Monthly Debt Payments:</span>
                <span className="font-extrabold text-slate-700">{formatCurrency(profile.monthlyEmi, profile.currency)}</span>
              </div>
              <div className="flex justify-between py-1">
                <span className="text-slate-500 font-medium">Safe Benchmark:</span>
                <span className="font-bold text-slate-700">Under 30% of income</span>
              </div>
            </div>

            <p className="mt-4 text-xs text-slate-600 leading-relaxed bg-slate-50 p-3 rounded-xl border border-slate-100">
              {analysis.debtToIncomeRatio <= 25 ? (
                'Your debt service obligations are low and manageable, leaving healthy room to invest without interest dragging down your net worth.'
              ) : (
                'High debt payments act like a flat tyre on your financial vehicle. Consider paying down expensive credit card or personal loans before investing heavily.'
              )}
            </p>
          </div>

          <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
            <span className="text-slate-400 font-medium">Pillar Score: {analysis.healthBreakdown.debt}/100</span>
            <button
              onClick={() => onExplain('net_worth')}
              className="text-emerald-700 hover:text-emerald-800 font-bold"
            >
              Understand Net Worth →
            </button>
          </div>
        </div>

        {/* Pillar 4: Goal Readiness */}
        <div className="bg-white rounded-2xl p-6 shadow-sm border border-slate-200 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-indigo-100 text-indigo-700 flex items-center justify-center font-bold">
                  🎯
                </div>
                <h3 className="font-bold text-slate-900 text-lg">Goal Feasibility</h3>
              </div>
              <span className={`text-xs font-bold px-2.5 py-1 rounded-full border ${getBadgeClass(analysis.goalReadinessStatus)}`}>
                {getStatusLabel(analysis.goalReadinessStatus)}
              </span>
            </div>

            <div className="space-y-2 mt-4 text-xs">
              <div className="flex justify-between py-1 border-b border-slate-100">
                <span className="text-slate-500 font-medium">Active Targets Configured:</span>
                <span className="font-extrabold text-slate-900">{goals.length} Goals</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-100">
                <span className="text-slate-500 font-medium">Investable Capacity:</span>
                <span className="font-extrabold text-indigo-700">{formatCurrency(analysis.investableCapacity, profile.currency)}/mo</span>
              </div>
              <div className="flex justify-between py-1">
                <span className="text-slate-500 font-medium">Alignment:</span>
                <span className="font-bold text-slate-700">Balanced for your time horizon</span>
              </div>
            </div>

            <p className="mt-4 text-xs text-slate-600 leading-relaxed bg-slate-50 p-3 rounded-xl border border-slate-100">
              Your goals are linked to realistic time horizons. Remember: short-term goals (&lt; 3 years) should be placed in debt or recurring deposits, while 5+ year goals can leverage equity compounding.
            </p>
          </div>

          <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
            <span className="text-slate-400 font-medium">Pillar Score: {analysis.healthBreakdown.goals}/100</span>
            <button
              onClick={() => onNavigate('goals')}
              className="text-emerald-700 hover:text-emerald-800 font-bold"
            >
              Open Goal Planner →
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
