import React from 'react';
import { X, HelpCircle, Lightbulb, Sparkles, BookOpen } from 'lucide-react';
import { GLOSSARY_TERMS, GlossaryTerm } from '../data/educationData';

interface ExplainModalProps {
  termKey: string | null;
  onClose: () => void;
  beginnerMode?: boolean;
}

export const ExplainModal: React.FC<ExplainModalProps> = ({ termKey, onClose, beginnerMode = true }) => {
  if (!termKey) return null;

  // Find term or construct generic explanation
  const termData: GlossaryTerm | undefined = GLOSSARY_TERMS[termKey.toLowerCase()] || 
    Object.values(GLOSSARY_TERMS).find(t => t.term.toLowerCase().includes(termKey.toLowerCase()));

  const title = termData?.term || termKey;
  const definition = termData?.simpleDefinition || 'A standard financial term used to evaluate your investment strategy and monetary readiness.';
  const analogy = termData?.analogy || 'Think of it as a tool in your financial toolbox designed to give you clarity and security.';
  const example = termData?.example || 'Using this concept appropriately helps balance your risk and future growth.';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-200">
      <div 
        className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl border border-slate-100 relative text-slate-800"
        role="dialog"
        aria-modal="true"
      >
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 text-slate-400 hover:text-slate-600 rounded-full hover:bg-slate-100 transition-colors"
          aria-label="Close explanation"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-3 mb-4">
          <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center font-bold">
            <BookOpen className="w-5 h-5" />
          </div>
          <div>
            <span className="text-xs uppercase tracking-wider font-bold text-emerald-600">Smart Explanation</span>
            <h3 className="text-xl font-bold text-slate-900">{title}</h3>
          </div>
        </div>

        <div className="space-y-4">
          <div className="p-3.5 bg-emerald-50/60 rounded-xl border border-emerald-100/80">
            <div className="flex items-start gap-2.5">
              <Sparkles className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
              <div>
                <span className="text-xs font-bold text-emerald-800 uppercase tracking-wide">Simple Definition</span>
                <p className="text-slate-700 text-sm mt-0.5 leading-relaxed font-medium">
                  {definition}
                </p>
              </div>
            </div>
          </div>

          <div className="p-3.5 bg-amber-50/60 rounded-xl border border-amber-100/80">
            <div className="flex items-start gap-2.5">
              <Lightbulb className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
              <div>
                <span className="text-xs font-bold text-amber-800 uppercase tracking-wide">Everyday Analogy</span>
                <p className="text-slate-700 text-sm mt-0.5 leading-relaxed">
                  {analogy}
                </p>
              </div>
            </div>
          </div>

          <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200">
            <div className="flex items-start gap-2.5">
              <HelpCircle className="w-4 h-4 text-indigo-600 shrink-0 mt-0.5" />
              <div>
                <span className="text-xs font-bold text-indigo-700 uppercase tracking-wide">Real-World Example</span>
                <p className="text-slate-600 text-sm mt-0.5 leading-relaxed">
                  {example}
                </p>
              </div>
            </div>
          </div>
        </div>

        <div className="mt-6 flex justify-end">
          <button
            onClick={onClose}
            className="w-full sm:w-auto px-5 py-2.5 bg-slate-900 text-white rounded-xl font-semibold text-sm hover:bg-slate-800 transition-colors shadow-sm"
          >
            Got it, thanks!
          </button>
        </div>
      </div>
    </div>
  );
};

export const ExplainBadge: React.FC<{ term: string; label?: string; onExplain: (t: string) => void }> = ({
  term,
  label,
  onExplain
}) => {
  return (
    <button
      type="button"
      onClick={(e) => {
        e.stopPropagation();
        onExplain(term);
      }}
      className="inline-flex items-center gap-1 text-xs text-emerald-700 hover:text-emerald-800 font-medium px-1.5 py-0.5 bg-emerald-50 hover:bg-emerald-100 rounded border border-emerald-200/60 transition-colors ml-1 cursor-pointer"
      title={`Explain ${label || term}`}
    >
      <HelpCircle className="w-3 h-3 text-emerald-600" />
      <span>What does this mean?</span>
    </button>
  );
};
