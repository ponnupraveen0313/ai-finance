import React from 'react';
import { 
  TrendingUp, 
  ShieldCheck, 
  Target, 
  PieChart, 
  HelpCircle, 
  ArrowRight, 
  Sparkles, 
  AlertTriangle, 
  ArrowUpRight, 
  MessageSquareCode, 
  HeartPulse, 
  CheckCircle2,
  Calendar,
  Layers
} from 'lucide-react';
import { 
  UserProfile, 
  FinancialAnalysis, 
  RiskProfile, 
  FinancialGoal, 
  AssetAllocationItem, 
  Recommendation 
} from '../types';
import { formatCurrency } from '../utils/financialCalculations';
import { ExplainBadge } from './ExplainModal';

interface DashboardViewProps {
  profile: UserProfile;
  analysis: FinancialAnalysis;
  riskProfile: RiskProfile;
  goals: FinancialGoal[];
  allocationItems: AssetAllocationItem[];
  recommendations: Recommendation[];
  onNavigate: (tab: string) => void;
  onExplain: (term: string) => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  profile,
  analysis,
  riskProfile,
  goals,
  allocationItems,
  recommendations,
  onNavigate,
  onExplain
}) => {
  const currentYear = new Date().getFullYear();

  return (
    <div className="space-y-8 pb-12">
      {/* Welcome Banner & Health Score Snapshot */}
      <div className="bg-white rounded-2xl p-6 sm:p-8 shadow-sm border border-slate-200">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-center">
          <div className="lg:col-span-8">
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold uppercase tracking-wider text-emerald-600">
                Personalized Dashboard
              </span>
              <span className="text-xs font-bold px-2 py-0.5 rounded-full bg-indigo-100 text-indigo-800">
                {riskProfile.category} Investor
              </span>
            </div>
            <h1 className="text-2xl sm:text-4xl font-extrabold text-slate-900 mt-1">
              Your Financial Overview
            </h1>
            <p className="text-sm text-slate-600 mt-2 max-w-xl leading-relaxed">
              {profile.beginnerMode ? (
                <span>
                  Here is the simple breakdown of your money. Your monthly surplus is <strong>{formatCurrency(analysis.investableCapacity, profile.currency)}</strong>, and you have enough emergency cash to cover <strong>{analysis.emergencyFundMonths.toFixed(1)} months</strong> of essential living bills.
                </span>
              ) : (
                <span>
                  Diagnostic overview based on your monthly cashflows, {analysis.savingsRate}% savings rate, and {riskProfile.category} risk score.
                </span>
              )}
            </p>
          </div>

          {/* Health Score Pill */}
          <div className="lg:col-span-4 bg-gradient-to-tr from-slate-900 to-slate-800 rounded-2xl p-5 text-white shadow-md text-center sm:text-left">
            <div className="flex items-center justify-between mb-1">
              <span className="text-xs font-bold uppercase tracking-wider text-emerald-400">
                Financial Health
              </span>
              <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-white/10 text-slate-300">
                Score
              </span>
            </div>

            <div className="flex items-baseline justify-center sm:justify-start gap-1">
              <span className="text-4xl font-black">{analysis.healthScore}</span>
              <span className="text-slate-400 text-sm font-bold">/ 100</span>
            </div>

            {/* Sub-scores mini bar */}
            <div className="grid grid-cols-5 gap-1.5 mt-3 pt-3 border-t border-slate-700/80 text-[10px] text-center">
              <div>
                <span className="text-slate-400 block font-medium">Save</span>
                <span className="font-extrabold text-emerald-400">{analysis.healthBreakdown.savings}</span>
              </div>
              <div>
                <span className="text-slate-400 block font-medium">Emerg</span>
                <span className="font-extrabold text-emerald-400">{analysis.healthBreakdown.emergency}</span>
              </div>
              <div>
                <span className="text-slate-400 block font-medium">Debt</span>
                <span className="font-extrabold text-emerald-400">{analysis.healthBreakdown.debt}</span>
              </div>
              <div>
                <span className="text-slate-400 block font-medium">Goals</span>
                <span className="font-extrabold text-emerald-400">{analysis.healthBreakdown.goals}</span>
              </div>
              <div>
                <span className="text-slate-400 block font-medium">Ready</span>
                <span className="font-extrabold text-emerald-400">{analysis.healthBreakdown.readiness}</span>
              </div>
            </div>

            <div className="mt-3 text-right">
              <button
                onClick={() => onNavigate('health')}
                className="text-[11px] font-bold text-emerald-400 hover:text-emerald-300 flex items-center justify-end gap-1 ml-auto cursor-pointer"
              >
                <span>Full diagnostic check</span>
                <ArrowRight className="w-3 h-3" />
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* 4 Core Financial Pillar Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Net Worth */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between text-slate-500 mb-2">
              <span className="text-xs font-bold uppercase tracking-wider">Estimated Net Worth</span>
              <ExplainBadge term="net_worth" onExplain={onExplain} />
            </div>
            <div className="text-2xl font-extrabold text-slate-900">
              {formatCurrency(analysis.netWorth, profile.currency)}
            </div>
            <span className="text-xs text-slate-500 font-medium block mt-1">
              Assets minus debt liabilities
            </span>
          </div>
          <div className="mt-4 pt-3 border-t border-slate-100 text-[11px] text-slate-400">
            Total Assets: {formatCurrency(profile.existingSavings + profile.emergencyFund + profile.currentInvestments, profile.currency)}
          </div>
        </div>

        {/* Monthly Investable Capacity */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between text-slate-500 mb-2">
              <span className="text-xs font-bold uppercase tracking-wider">Investable Surplus</span>
              <ExplainBadge term="liquidity" onExplain={onExplain} />
            </div>
            <div className="text-2xl font-extrabold text-emerald-600">
              {formatCurrency(analysis.investableCapacity, profile.currency)}
              <span className="text-xs font-normal text-slate-500">/mo</span>
            </div>
            <span className="text-xs text-slate-500 font-medium block mt-1">
              Safe amount after bills and loans
            </span>
          </div>
          <div className="mt-4 pt-3 border-t border-slate-100 text-[11px] text-slate-400">
            Savings Rate: <strong className="text-emerald-700">{analysis.savingsRate}%</strong> of income
          </div>
        </div>

        {/* Emergency Fund Coverage */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between text-slate-500 mb-2">
              <span className="text-xs font-bold uppercase tracking-wider">Emergency Buffer</span>
              <ExplainBadge term="emergency_fund" onExplain={onExplain} />
            </div>
            <div className="text-2xl font-extrabold text-slate-900">
              {analysis.emergencyFundMonths} Months
            </div>
            <span className="text-xs text-slate-500 font-medium block mt-1">
              {formatCurrency(profile.emergencyFund, profile.currency)} reserved
            </span>
          </div>
          <div className="mt-4 pt-3 border-t border-slate-100 text-[11px]">
            {analysis.emergencyFundMonths < 3 ? (
              <span className="text-amber-700 font-bold">⚠️ Target: 3 to 6 months</span>
            ) : (
              <span className="text-emerald-700 font-bold">✅ Adequate safety net</span>
            )}
          </div>
        </div>

        {/* Debt-to-Income / EMI */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between text-slate-500 mb-2">
              <span className="text-xs font-bold uppercase tracking-wider">Debt / EMI Ratio</span>
              <ExplainBadge term="emi" onExplain={onExplain} />
            </div>
            <div className="text-2xl font-extrabold text-slate-900">
              {analysis.debtToIncomeRatio}%
            </div>
            <span className="text-xs text-slate-500 font-medium block mt-1">
              {formatCurrency(profile.monthlyEmi, profile.currency)}/mo loan payments
            </span>
          </div>
          <div className="mt-4 pt-3 border-t border-slate-100 text-[11px]">
            {analysis.debtToIncomeRatio <= 25 ? (
              <span className="text-emerald-700 font-bold">✅ Healthy debt burden</span>
            ) : (
              <span className="text-amber-700 font-bold">⚠️ High: Prioritize paydown</span>
            )}
          </div>
        </div>
      </div>

      {/* Dynamic Asset Allocation Snapshot */}
      <div className="bg-white rounded-2xl p-6 sm:p-8 shadow-sm border border-slate-200">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-4 border-b border-slate-100">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold uppercase tracking-wider text-emerald-600">Personalized Mix</span>
              <ExplainBadge term="asset_allocation" onExplain={onExplain} />
            </div>
            <h2 className="text-xl sm:text-2xl font-bold text-slate-900 mt-1">
              Suggested Portfolio Allocation
            </h2>
            <p className="text-xs sm:text-sm text-slate-600 mt-0.5">
              Dynamically calculated to balance wealth growth and principal security.
            </p>
          </div>

          <button
            onClick={() => onNavigate('plan')}
            className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-emerald-50 hover:bg-emerald-100 text-emerald-700 font-bold text-xs transition-colors cursor-pointer"
          >
            <span>Explore Full Plan & Details</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>

        {/* Visual Allocation Segmented Bar */}
        <div className="mt-6">
          <div className="h-6 w-full rounded-xl overflow-hidden flex shadow-inner mb-4">
            {allocationItems.map((item) => (
              <div
                key={item.id}
                style={{ width: `${item.percentage}%`, backgroundColor: item.color }}
                className="h-full transition-all hover:opacity-90 cursor-pointer"
                onClick={() => onNavigate('plan')}
                title={`${item.name}: ${item.percentage}%`}
              />
            ))}
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            {allocationItems.map((item) => (
              <div key={item.id} className="p-3 rounded-xl bg-slate-50 border border-slate-200/80">
                <div className="flex items-center gap-2 mb-1">
                  <div className="w-3 h-3 rounded-full" style={{ backgroundColor: item.color }} />
                  <span className="text-xs font-bold text-slate-900 truncate">{item.name}</span>
                </div>
                <div className="flex items-baseline justify-between mt-1">
                  <span className="text-lg font-extrabold text-slate-900">{item.percentage}%</span>
                  <span className="text-xs font-semibold text-slate-500">
                    {formatCurrency(item.amount, profile.currency)}/mo
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Priority Recommendations Engine Preview */}
      <div className="bg-white rounded-2xl p-6 sm:p-8 shadow-sm border border-slate-200">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-4 border-b border-slate-100">
          <div>
            <span className="text-xs font-bold uppercase tracking-wider text-emerald-600">Action Plan</span>
            <h2 className="text-xl sm:text-2xl font-bold text-slate-900 mt-1">
              Top Actionable Next Steps
            </h2>
            <p className="text-xs sm:text-sm text-slate-600 mt-0.5">
              Clear suggestions tailored to your emergency reserves, debts, and timeline.
            </p>
          </div>

          <button
            onClick={() => onNavigate('plan')}
            className="text-xs font-bold text-emerald-700 hover:text-emerald-800"
          >
            View all {recommendations.length} recommendations →
          </button>
        </div>

        <div className="mt-6 space-y-4">
          {recommendations.slice(0, 3).map((rec) => (
            <div
              key={rec.id}
              className="p-4 sm:p-5 rounded-xl border border-slate-200 bg-slate-50/50 hover:bg-white transition-all space-y-2"
            >
              <div className="flex items-center justify-between">
                <span className={`text-[10px] uppercase font-extrabold px-2 py-0.5 rounded ${
                  rec.priority === 'high' ? 'bg-amber-100 text-amber-800' :
                  rec.priority === 'medium' ? 'bg-blue-100 text-blue-800' : 'bg-slate-100 text-slate-700'
                }`}>
                  {rec.priority} Priority
                </span>
                <button
                  onClick={() => onNavigate('plan')}
                  className="text-xs font-bold text-emerald-700 hover:underline flex items-center gap-1"
                >
                  <span>Why am I seeing this?</span>
                  <ArrowUpRight className="w-3.5 h-3.5" />
                </button>
              </div>

              <h3 className="font-bold text-slate-900 text-base">{rec.title}</h3>
              <p className="text-xs text-slate-600 leading-relaxed">{rec.why}</p>

              <div className="pt-2 text-xs text-slate-700 flex items-start gap-1.5 font-medium">
                <ArrowRight className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
                <span><strong>Action:</strong> {rec.suggestedAction}</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Goals Preview & AI Assistant Callout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Goals Progress Snapshot */}
        <div className="lg:col-span-7 bg-white rounded-2xl p-6 shadow-sm border border-slate-200 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-4">
              <div>
                <span className="text-xs font-bold uppercase text-emerald-600">Milestones</span>
                <h3 className="text-lg font-bold text-slate-900">Active Goals ({goals.length})</h3>
              </div>
              <button
                onClick={() => onNavigate('goals')}
                className="text-xs font-bold text-emerald-700 hover:underline"
              >
                Manage Goals →
              </button>
            </div>

            <div className="space-y-4">
              {goals.slice(0, 3).map((g) => {
                const progress = g.targetAmount > 0 ? Math.min(100, Math.round((g.currentAmount / g.targetAmount) * 100)) : 0;
                return (
                  <div key={g.id} className="p-3.5 rounded-xl bg-slate-50 border border-slate-200/80">
                    <div className="flex justify-between items-center text-xs font-bold mb-1">
                      <span className="text-slate-900">{g.name}</span>
                      <span className="text-emerald-700">{progress}%</span>
                    </div>
                    <div className="w-full bg-slate-200 h-2 rounded-full overflow-hidden mb-2">
                      <div className="bg-emerald-500 h-full rounded-full" style={{ width: `${progress}%` }} />
                    </div>
                    <div className="flex justify-between text-[11px] text-slate-500">
                      <span>Saved: {formatCurrency(g.currentAmount, profile.currency)}</span>
                      <span>Target: {formatCurrency(g.targetAmount, profile.currency)} ({g.targetYear})</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          <div className="mt-6 pt-4 border-t border-slate-100 text-right">
            <button
              onClick={() => onNavigate('goals')}
              className="text-xs font-bold text-slate-700 hover:text-emerald-700"
            >
              Add more goals in Goal Planner →
            </button>
          </div>
        </div>

        {/* AI Assistant Quick Callout */}
        <div className="lg:col-span-5 bg-gradient-to-tr from-emerald-700 to-teal-800 text-white rounded-2xl p-6 sm:p-7 shadow-md flex flex-col justify-between">
          <div>
            <div className="w-10 h-10 rounded-xl bg-white/20 flex items-center justify-center mb-4">
              <Sparkles className="w-5 h-5 text-emerald-200" />
            </div>
            <span className="text-xs font-bold uppercase tracking-wider text-emerald-200">Personalized AI Advisor</span>
            <h3 className="text-2xl font-extrabold mt-1">Have questions about your plan?</h3>
            <p className="text-xs sm:text-sm text-emerald-100 mt-2 leading-relaxed">
              Ask SmartVest AI anything! "What is SIP?", "How much should I invest monthly?", or "Explain my asset allocation." The AI knows your numbers and responds in simple, beginner-friendly terms.
            </p>
          </div>

          <div className="mt-6">
            <button
              onClick={() => onNavigate('chat')}
              className="w-full py-3 px-4 bg-white hover:bg-emerald-50 text-emerald-900 font-extrabold rounded-xl shadow-sm transition-all text-sm flex items-center justify-center gap-2 cursor-pointer"
            >
              <MessageSquareCode className="w-4 h-4" />
              <span>Ask SmartVest AI Now</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
