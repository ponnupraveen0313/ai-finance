import React from 'react';
import { 
  TrendingUp, 
  PieChart, 
  Target, 
  BookOpen, 
  Calculator, 
  MessageSquareCode, 
  HeartPulse 
} from 'lucide-react';

interface MobileBottomNavProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

export const MobileBottomNav: React.FC<MobileBottomNavProps> = ({ activeTab, setActiveTab }) => {
  const items = [
    { id: 'dashboard', label: 'Home', icon: TrendingUp },
    { id: 'plan', label: 'Plan', icon: PieChart },
    { id: 'goals', label: 'Goals', icon: Target },
    { id: 'health', label: 'Health', icon: HeartPulse },
    { id: 'calculators', label: 'Calc', icon: Calculator },
    { id: 'learn', label: 'Learn', icon: BookOpen },
    { id: 'chat', label: 'AI Chat', icon: MessageSquareCode, badge: true },
  ];

  return (
    <div className="lg:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md border-t border-slate-200 pb-safe">
      <div className="grid grid-cols-7 h-16 items-center px-1">
        {items.map(item => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`flex flex-col items-center justify-center h-full py-1 text-xs transition-colors relative ${
                isActive ? 'text-emerald-600 font-bold' : 'text-slate-500 hover:text-slate-900 font-medium'
              }`}
            >
              <div className="relative">
                <Icon className={`w-5 h-5 ${isActive ? 'text-emerald-600 scale-110' : 'text-slate-400'}`} />
                {item.badge && (
                  <span className="absolute -top-1 -right-1 w-2 h-2 bg-emerald-500 rounded-full animate-pulse" />
                )}
              </div>
              <span className="text-[10px] mt-0.5 truncate max-w-full">{item.label}</span>
              {isActive && (
                <div className="w-5 h-0.5 bg-emerald-600 rounded-full mt-0.5 absolute bottom-1" />
              )}
            </button>
          );
        })}
      </div>
    </div>
  );
};
