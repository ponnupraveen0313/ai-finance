import React, { useState } from 'react';
import { 
  ArrowRight, 
  ArrowLeft, 
  Check, 
  Sparkles, 
  AlertCircle, 
  HelpCircle, 
  Plus, 
  Trash2, 
  TrendingUp, 
  ShieldAlert, 
  Calendar, 
  DollarSign, 
  Clock, 
  ShieldCheck,
  ChevronRight,
  Info
} from 'lucide-react';
import { 
  UserProfile, 
  FinancialGoal, 
  RiskProfile, 
  GoalCategory, 
  GoalPriority, 
  EmploymentStatus 
} from '../types';
import { 
  formatCurrency, 
  evaluateRiskAnswers, 
  calculateFinancialAnalysis,
  calculateGoalMonthlyRequirement 
} from '../utils/financialCalculations';
import { ExplainBadge } from './ExplainModal';

interface OnboardingFlowProps {
  initialProfile: UserProfile;
  initialGoals: FinancialGoal[];
  initialRiskAnswers: Record<number, number>;
  onComplete: (profile: UserProfile, goals: FinancialGoal[], riskAnswers: Record<number, number>) => void;
  onCancel: () => void;
  onExplain: (term: string) => void;
}

const DEFAULT_GOAL_PRESETS: { category: GoalCategory; name: string; amount: number; years: number }[] = [
  { category: 'emergency', name: 'Emergency Safety Cushion', amount: 150000, years: 1 },
  { category: 'vehicle', name: 'Car / Bike Purchase', amount: 350000, years: 3 },
  { category: 'house', name: 'Home Downpayment', amount: 1200000, years: 5 },
  { category: 'education', name: 'Higher Education / Certifications', amount: 400000, years: 2 },
  { category: 'wealth', name: 'Long-term Wealth Creation', amount: 2000000, years: 8 },
  { category: 'retirement', name: 'Retirement Independence', amount: 5000000, years: 15 },
  { category: 'travel', name: 'Dream Vacation', amount: 120000, years: 2 },
];

export const OnboardingFlow: React.FC<OnboardingFlowProps> = ({
  initialProfile,
  initialGoals,
  initialRiskAnswers,
  onComplete,
  onCancel,
  onExplain,
}) => {
  const [step, setStep] = useState<number>(1);
  const totalSteps = 6;

  // Form states
  const [profile, setProfile] = useState<UserProfile>(initialProfile);
  const [goals, setGoals] = useState<FinancialGoal[]>(
    initialGoals.length > 0 ? initialGoals : [
      {
        id: 'goal-1',
        name: 'Emergency Cushion',
        category: 'emergency',
        targetAmount: Math.max(100000, profile.monthlyExpenses * 4),
        currentAmount: profile.emergencyFund || 20000,
        targetYear: new Date().getFullYear() + 1,
        priority: 'high',
      },
      {
        id: 'goal-2',
        name: 'Long-Term Wealth Creation',
        category: 'wealth',
        targetAmount: 1500000,
        currentAmount: profile.currentInvestments || 10000,
        targetYear: new Date().getFullYear() + 8,
        priority: 'medium',
      }
    ]
  );

  const [riskAnswers, setRiskAnswers] = useState<Record<number, number>>(
    Object.keys(initialRiskAnswers).length > 0 ? initialRiskAnswers : { 1: 3, 2: 3, 3: 3, 4: 3 }
  );

  const [validationError, setValidationError] = useState<string | null>(null);

  // Computed analysis
  const currentAnalysis = calculateFinancialAnalysis(profile, goals);
  const currentRiskProfile = evaluateRiskAnswers(riskAnswers);

  const handleNext = () => {
    setValidationError(null);

    // Step 1 Validation
    if (step === 1) {
      if (profile.age < 16 || profile.age > 100) {
        setValidationError('Please enter a valid age between 16 and 100.');
        return;
      }
      if (profile.monthlyIncome <= 0) {
        setValidationError('Please enter your approximate monthly income. If you are a student or exploring, enter your monthly stipend or pocket allowance.');
        return;
      }
      if (profile.monthlyExpenses < 0) {
        setValidationError('Monthly expenses cannot be negative.');
        return;
      }
    }

    // Step 2 Validation: Income vs Expenses & Debt
    if (step === 2) {
      if (profile.monthlyExpenses + profile.monthlyEmi > profile.monthlyIncome) {
        setValidationError(
          `Your monthly expenses (${formatCurrency(profile.monthlyExpenses, profile.currency)}) plus EMIs (${formatCurrency(profile.monthlyEmi, profile.currency)}) are higher than your income (${formatCurrency(profile.monthlyIncome, profile.currency)}). In real life, spending more than you earn creates debt. Please verify your amounts or adjust them before planning investments.`
        );
        return;
      }
    }

    // Step 3 Validation: Goals
    if (step === 3) {
      if (goals.length === 0) {
        setValidationError('Please add at least one financial goal so we can tailor your investment plan.');
        return;
      }
      for (const g of goals) {
        if (!g.name.trim()) {
          setValidationError('All goals must have a name.');
          return;
        }
        if (g.targetAmount <= 0) {
          setValidationError(`Please enter a valid target amount for ${g.name}.`);
          return;
        }
        if (g.targetYear <= new Date().getFullYear()) {
          setValidationError(`Target year for ${g.name} must be in the future.`);
          return;
        }
      }
    }

    // Step 4 Validation: Risk
    if (step === 4) {
      if (!riskAnswers[1] || !riskAnswers[2] || !riskAnswers[3] || !riskAnswers[4]) {
        setValidationError('Please answer all 4 risk questions to calculate your risk category.');
        return;
      }
    }

    if (step < totalSteps) {
      setStep(prev => prev + 1);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } else {
      // Complete
      onComplete({ ...profile, onboardingComplete: true }, goals, riskAnswers);
    }
  };

  const handleBack = () => {
    setValidationError(null);
    if (step > 1) {
      setStep(prev => prev - 1);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } else {
      onCancel();
    }
  };

  // Goal management helpers
  const handleAddGoal = (preset?: { category: GoalCategory; name: string; amount: number; years: number }) => {
    const currentYear = new Date().getFullYear();
    const newGoal: FinancialGoal = {
      id: `goal-${Date.now()}`,
      name: preset ? preset.name : 'New Financial Goal',
      category: preset ? preset.category : 'wealth',
      targetAmount: preset ? preset.amount : 500000,
      currentAmount: 0,
      targetYear: currentYear + (preset ? preset.years : 4),
      priority: 'medium',
    };
    setGoals([...goals, newGoal]);
  };

  const handleRemoveGoal = (id: string) => {
    setGoals(goals.filter(g => g.id !== id));
  };

  const handleUpdateGoal = (id: string, updates: Partial<FinancialGoal>) => {
    setGoals(goals.map(g => g.id === id ? { ...g, ...updates } : g));
  };

  return (
    <div className="min-h-screen bg-slate-50 py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-3xl mx-auto">
        {/* Progress Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between text-xs sm:text-sm font-bold text-slate-500 mb-2">
            <span>Step {step} of {totalSteps}</span>
            <span className="text-emerald-700 font-semibold">
              {step === 1 && 'Basic Profile'}
              {step === 2 && 'Financial Health & Savings'}
              {step === 3 && 'Financial Goals'}
              {step === 4 && 'Risk Assessment'}
              {step === 5 && 'AI Analysis Review'}
              {step === 6 && 'Plan Ready'}
            </span>
          </div>

          {/* Progress bar */}
          <div className="w-full bg-slate-200 h-2.5 rounded-full overflow-hidden flex">
            <div 
              className="bg-emerald-600 h-full transition-all duration-300 rounded-full"
              style={{ width: `${(step / totalSteps) * 100}%` }}
            />
          </div>

          {/* Step indicators */}
          <div className="hidden sm:flex justify-between mt-3 text-[11px] font-semibold text-slate-400">
            <span className={step >= 1 ? 'text-emerald-700 font-bold' : ''}>1. Profile</span>
            <span className={step >= 2 ? 'text-emerald-700 font-bold' : ''}>2. Finances</span>
            <span className={step >= 3 ? 'text-emerald-700 font-bold' : ''}>3. Goals</span>
            <span className={step >= 4 ? 'text-emerald-700 font-bold' : ''}>4. Risk Quiz</span>
            <span className={step >= 5 ? 'text-emerald-700 font-bold' : ''}>5. Analysis</span>
            <span className={step >= 6 ? 'text-emerald-700 font-bold' : ''}>6. Plan</span>
          </div>
        </div>

        {/* Validation alert banner */}
        {validationError && (
          <div className="mb-6 p-4 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 text-sm flex items-start gap-3 animate-in fade-in">
            <AlertCircle className="w-5 h-5 shrink-0 text-rose-600 mt-0.5" />
            <div>
              <span className="font-bold block">Please check:</span>
              <p className="mt-0.5 leading-relaxed">{validationError}</p>
            </div>
          </div>
        )}

        {/* STEP 1: Basic Profile */}
        {step === 1 && (
          <div className="bg-white rounded-2xl p-6 sm:p-8 shadow-sm border border-slate-200">
            <div className="mb-6">
              <span className="text-xs font-bold uppercase tracking-wider text-emerald-600">Personal Background</span>
              <h2 className="text-2xl font-bold text-slate-900 mt-1">Tell us a bit about yourself</h2>
              <p className="text-sm text-slate-600 mt-1">
                Your age and career stage help determine how many years your money has to grow and what safety net is appropriate.
              </p>
            </div>

            <div className="space-y-6">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1.5">
                    Your Age
                  </label>
                  <input
                    type="number"
                    min="16"
                    max="100"
                    value={profile.age || ''}
                    onChange={(e) => setProfile({ ...profile, age: parseInt(e.target.value) || 0 })}
                    placeholder="e.g. 25"
                    className="w-full px-4 py-2.5 rounded-xl border border-slate-300 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-200 outline-none text-slate-900 font-semibold text-base transition-all"
                  />
                  <span className="text-[11px] text-slate-500 mt-1 block">
                    Younger investors have a longer compounding runway to ride out market cycles.
                  </span>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1.5">
                    Employment Status
                  </label>
                  <select
                    value={profile.employmentStatus}
                    onChange={(e) => setProfile({ ...profile, employmentStatus: e.target.value as EmploymentStatus })}
                    className="w-full px-4 py-2.5 rounded-xl border border-slate-300 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-200 outline-none text-slate-900 font-semibold text-base transition-all bg-white"
                  >
                    <option value="student">Student / Intern</option>
                    <option value="salaried">Salaried Employee</option>
                    <option value="self_employed">Self-Employed / Freelancer</option>
                    <option value="business_owner">Business Owner</option>
                    <option value="other">Other</option>
                  </select>
                  <span className="text-[11px] text-slate-500 mt-1 block">
                    Freelancers typically need a larger emergency buffer than salaried workers.
                  </span>
                </div>
              </div>

              <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold uppercase text-slate-600">Monthly Cash Inflow</span>
                  <ExplainBadge term="liquidity" onExplain={onExplain} />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                    Estimated Monthly Take-Home Income ({profile.currency === 'INR' ? '₹' : '$'})
                  </label>
                  <div className="relative">
                    <span className="absolute left-3 top-2.5 text-slate-400 font-bold">
                      {profile.currency === 'INR' ? '₹' : '$'}
                    </span>
                    <input
                      type="number"
                      min="0"
                      step="1000"
                      value={profile.monthlyIncome || ''}
                      onChange={(e) => setProfile({ ...profile, monthlyIncome: parseFloat(e.target.value) || 0 })}
                      placeholder="e.g. 50000"
                      className="w-full pl-8 pr-4 py-2.5 rounded-xl border border-slate-300 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-200 outline-none text-slate-900 font-semibold text-base"
                    />
                  </div>
                  <span className="text-[11px] text-slate-500 mt-1 block">
                    What arrives in your bank account every month after taxes.
                  </span>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* STEP 2: Financial Situation & Health Math */}
        {step === 2 && (
          <div className="bg-white rounded-2xl p-6 sm:p-8 shadow-sm border border-slate-200">
            <div className="mb-6">
              <span className="text-xs font-bold uppercase tracking-wider text-emerald-600">Financial Situation</span>
              <h2 className="text-2xl font-bold text-slate-900 mt-1">Expenses, Debt & Current Savings</h2>
              <p className="text-sm text-slate-600 mt-1">
                We use this to calculate your real savings rate, emergency coverage, and net worth.
              </p>
            </div>

            <div className="space-y-6">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="text-xs font-bold text-slate-700 uppercase">
                      Monthly Living Expenses
                    </label>
                    <ExplainBadge term="liquidity" onExplain={onExplain} />
                  </div>
                  <div className="relative">
                    <span className="absolute left-3 top-2.5 text-slate-400 font-bold">
                      {profile.currency === 'INR' ? '₹' : '$'}
                    </span>
                    <input
                      type="number"
                      min="0"
                      step="1000"
                      value={profile.monthlyExpenses || ''}
                      onChange={(e) => setProfile({ ...profile, monthlyExpenses: parseFloat(e.target.value) || 0 })}
                      placeholder="e.g. 30000"
                      className="w-full pl-8 pr-4 py-2.5 rounded-xl border border-slate-300 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-200 outline-none text-slate-900 font-semibold text-base"
                    />
                  </div>
                  <span className="text-[11px] text-slate-500 mt-1 block">
                    Rent, groceries, utilities, subscriptions, and daily food.
                  </span>
                </div>

                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="text-xs font-bold text-slate-700 uppercase">
                      Monthly EMI / Loan Payments
                    </label>
                    <ExplainBadge term="emi" onExplain={onExplain} />
                  </div>
                  <div className="relative">
                    <span className="absolute left-3 top-2.5 text-slate-400 font-bold">
                      {profile.currency === 'INR' ? '₹' : '$'}
                    </span>
                    <input
                      type="number"
                      min="0"
                      step="500"
                      value={profile.monthlyEmi || ''}
                      onChange={(e) => setProfile({ ...profile, monthlyEmi: parseFloat(e.target.value) || 0 })}
                      placeholder="e.g. 5000 (or 0 if debt free)"
                      className="w-full pl-8 pr-4 py-2.5 rounded-xl border border-slate-300 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-200 outline-none text-slate-900 font-semibold text-base"
                    />
                  </div>
                  <span className="text-[11px] text-slate-500 mt-1 block">
                    Credit card EMIs, education loans, car or personal loans.
                  </span>
                </div>
              </div>

              {/* Existing balances */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-2">
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="text-xs font-bold text-slate-700 uppercase">
                      Emergency Savings
                    </label>
                    <ExplainBadge term="emergency_fund" onExplain={onExplain} />
                  </div>
                  <input
                    type="number"
                    min="0"
                    value={profile.emergencyFund || ''}
                    onChange={(e) => setProfile({ ...profile, emergencyFund: parseFloat(e.target.value) || 0 })}
                    placeholder="e.g. 90000"
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 focus:border-emerald-500 outline-none text-slate-900 font-semibold text-sm"
                  />
                  <span className="text-[10px] text-slate-500 mt-0.5 block">
                    Cash in savings account or liquid FD.
                  </span>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                    Current Investments
                  </label>
                  <input
                    type="number"
                    min="0"
                    value={profile.currentInvestments || ''}
                    onChange={(e) => setProfile({ ...profile, currentInvestments: parseFloat(e.target.value) || 0 })}
                    placeholder="e.g. 50000"
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 focus:border-emerald-500 outline-none text-slate-900 font-semibold text-sm"
                  />
                  <span className="text-[10px] text-slate-500 mt-0.5 block">
                    Existing mutual funds, stocks, PF.
                  </span>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                    Total Outstanding Debt
                  </label>
                  <input
                    type="number"
                    min="0"
                    value={profile.existingDebt || ''}
                    onChange={(e) => setProfile({ ...profile, existingDebt: parseFloat(e.target.value) || 0 })}
                    placeholder="e.g. 100000 (or 0)"
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 focus:border-emerald-500 outline-none text-slate-900 font-semibold text-sm"
                  />
                  <span className="text-[10px] text-slate-500 mt-0.5 block">
                    Total remaining principal owed.
                  </span>
                </div>
              </div>

              {/* Automatic live calculation card */}
              <div className="p-5 rounded-2xl bg-emerald-50/70 border border-emerald-200 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-extrabold uppercase tracking-wider text-emerald-800 flex items-center gap-1.5">
                    <Sparkles className="w-4 h-4 text-emerald-600" />
                    Automatic Financial Math
                  </span>
                  <span className="text-xs font-medium text-emerald-700">Calculated in real-time</span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-center sm:text-left">
                  <div className="bg-white p-3 rounded-xl border border-emerald-100">
                    <span className="text-[11px] font-bold text-slate-500 uppercase block">Monthly Savings</span>
                    <span className={`text-lg font-extrabold ${currentAnalysis.monthlySavings >= 0 ? 'text-slate-900' : 'text-rose-600'}`}>
                      {formatCurrency(currentAnalysis.monthlySavings, profile.currency)}
                    </span>
                    <span className="text-[10px] text-slate-500 block mt-0.5">
                      Income − Expenses − EMI
                    </span>
                  </div>

                  <div className="bg-white p-3 rounded-xl border border-emerald-100">
                    <span className="text-[11px] font-bold text-slate-500 uppercase block">Savings Rate</span>
                    <span className="text-lg font-extrabold text-emerald-600">
                      {currentAnalysis.savingsRate}%
                    </span>
                    <span className="text-[10px] text-slate-500 block mt-0.5">
                      Target: &gt; 20% of income
                    </span>
                  </div>

                  <div className="bg-white p-3 rounded-xl border border-emerald-100">
                    <div className="flex items-center justify-between">
                      <span className="text-[11px] font-bold text-slate-500 uppercase block">Net Worth</span>
                      <ExplainBadge term="net_worth" onExplain={onExplain} />
                    </div>
                    <span className="text-lg font-extrabold text-indigo-700">
                      {formatCurrency(currentAnalysis.netWorth, profile.currency)}
                    </span>
                    <span className="text-[10px] text-slate-500 block mt-0.5">
                      Assets − Liabilities
                    </span>
                  </div>
                </div>

                <p className="text-xs text-emerald-800 leading-relaxed pt-1">
                  💡 <strong>Why this matters:</strong> Investing is built from your monthly surplus ({formatCurrency(Math.max(0, currentAnalysis.monthlySavings), profile.currency)}). We will never recommend risking money you need for rent, groceries, or loans.
                </p>
              </div>
            </div>
          </div>
        )}

        {/* STEP 3: Financial Goals */}
        {step === 3 && (
          <div className="bg-white rounded-2xl p-6 sm:p-8 shadow-sm border border-slate-200">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between pb-4 border-b border-slate-100 gap-3 mb-6">
              <div>
                <span className="text-xs font-bold uppercase tracking-wider text-emerald-600">Financial Milestones</span>
                <h2 className="text-2xl font-bold text-slate-900 mt-1">What are you investing for?</h2>
                <p className="text-sm text-slate-600">
                  Goals give your money a purpose and determine how long each rupee can stay invested.
                </p>
              </div>
              <button
                type="button"
                onClick={() => handleAddGoal()}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-50 hover:bg-emerald-100 text-emerald-700 border border-emerald-200 text-xs font-bold transition-colors cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>Add Custom Goal</span>
              </button>
            </div>

            {/* Quick preset chips */}
            <div className="mb-6">
              <span className="text-xs font-bold text-slate-500 uppercase block mb-2">Or pick common goals:</span>
              <div className="flex flex-wrap gap-2">
                {DEFAULT_GOAL_PRESETS.map((p, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => handleAddGoal(p)}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-slate-100 hover:bg-emerald-50 hover:text-emerald-700 text-slate-700 border border-slate-200 text-xs font-medium transition-colors cursor-pointer"
                  >
                    <Plus className="w-3 h-3" />
                    <span>{p.name}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Goals list */}
            <div className="space-y-4">
              {goals.map((g) => {
                const currentYear = new Date().getFullYear();
                const yearsLeft = Math.max(0.5, g.targetYear - currentYear);
                const remainingAmount = Math.max(0, g.targetAmount - g.currentAmount);
                const monthlyRequired = calculateGoalMonthlyRequirement(g.targetAmount, g.currentAmount, yearsLeft, 8);
                const progressPct = g.targetAmount > 0 ? Math.min(100, Math.round((g.currentAmount / g.targetAmount) * 100)) : 0;

                return (
                  <div key={g.id} className="p-4 sm:p-5 rounded-xl border border-slate-200 bg-slate-50/50 hover:bg-white transition-all space-y-3 relative">
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex-1">
                        <input
                          type="text"
                          value={g.name}
                          onChange={(e) => handleUpdateGoal(g.id, { name: e.target.value })}
                          className="font-bold text-slate-900 bg-transparent border-b border-dashed border-slate-300 focus:border-emerald-600 outline-none text-base w-full sm:w-auto"
                        />
                      </div>
                      <button
                        type="button"
                        onClick={() => handleRemoveGoal(g.id)}
                        className="p-1.5 text-slate-400 hover:text-rose-600 rounded-lg transition-colors cursor-pointer"
                        title="Remove goal"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-4 gap-3 text-xs">
                      <div>
                        <label className="text-[11px] font-bold text-slate-500 uppercase block mb-1">Target Amount</label>
                        <input
                          type="number"
                          min="1000"
                          step="5000"
                          value={g.targetAmount}
                          onChange={(e) => handleUpdateGoal(g.id, { targetAmount: parseFloat(e.target.value) || 0 })}
                          className="w-full px-2.5 py-1.5 rounded-lg border border-slate-300 font-semibold text-slate-900 bg-white"
                        />
                      </div>

                      <div>
                        <label className="text-[11px] font-bold text-slate-500 uppercase block mb-1">Already Saved</label>
                        <input
                          type="number"
                          min="0"
                          step="1000"
                          value={g.currentAmount}
                          onChange={(e) => handleUpdateGoal(g.id, { currentAmount: parseFloat(e.target.value) || 0 })}
                          className="w-full px-2.5 py-1.5 rounded-lg border border-slate-300 font-semibold text-slate-900 bg-white"
                        />
                      </div>

                      <div>
                        <label className="text-[11px] font-bold text-slate-500 uppercase block mb-1">Target Year</label>
                        <input
                          type="number"
                          min={currentYear + 1}
                          max={currentYear + 40}
                          value={g.targetYear}
                          onChange={(e) => handleUpdateGoal(g.id, { targetYear: parseInt(e.target.value) || (currentYear + 1) })}
                          className="w-full px-2.5 py-1.5 rounded-lg border border-slate-300 font-semibold text-slate-900 bg-white"
                        />
                      </div>

                      <div>
                        <label className="text-[11px] font-bold text-slate-500 uppercase block mb-1">Priority</label>
                        <select
                          value={g.priority}
                          onChange={(e) => handleUpdateGoal(g.id, { priority: e.target.value as GoalPriority })}
                          className="w-full px-2.5 py-1.5 rounded-lg border border-slate-300 font-semibold text-slate-900 bg-white"
                        >
                          <option value="high">High</option>
                          <option value="medium">Medium</option>
                          <option value="low">Low</option>
                        </select>
                      </div>
                    </div>

                    {/* Goal Progress bar and monthly calculation summary */}
                    <div className="pt-2 border-t border-slate-200 flex flex-col sm:flex-row items-start sm:items-center justify-between text-xs text-slate-600 gap-2">
                      <div className="flex items-center gap-2 w-full sm:w-1/2">
                        <div className="flex-1 bg-slate-200 h-2 rounded-full overflow-hidden">
                          <div className="bg-emerald-500 h-full rounded-full" style={{ width: `${progressPct}%` }} />
                        </div>
                        <span className="font-bold text-slate-700 text-[11px]">{progressPct}%</span>
                      </div>

                      <div className="text-[11px]">
                        Needed: <strong className="text-emerald-700 font-bold">{formatCurrency(monthlyRequired, profile.currency)}/mo</strong> (~{yearsLeft.toFixed(1)} yrs left)
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* STEP 4: Risk Assessment */}
        {step === 4 && (
          <div className="bg-white rounded-2xl p-6 sm:p-8 shadow-sm border border-slate-200">
            <div className="mb-6">
              <span className="text-xs font-bold uppercase tracking-wider text-emerald-600">Behavioral Assessment</span>
              <h2 className="text-2xl font-bold text-slate-900 mt-1">Discover your Risk Profile</h2>
              <p className="text-sm text-slate-600 mt-1">
                Investing isn't about guessing the future; it's about knowing how you emotionally and financially handle market movements.
              </p>
            </div>

            <div className="space-y-6">
              {/* Question 1 */}
              <div className="p-4 rounded-xl border border-slate-200 bg-slate-50/50">
                <span className="text-xs font-bold text-emerald-700 uppercase">Question 1 of 4</span>
                <h3 className="font-bold text-slate-900 text-sm sm:text-base mt-1 mb-3">
                  If your investment temporarily loses 20% in value due to a market downturn, what would you most likely do?
                </h3>
                <div className="space-y-2">
                  {[
                    { val: 1, label: 'Sell immediately to prevent any further loss of money' },
                    { val: 2, label: 'Wait and see, but feel stressed and monitor prices daily' },
                    { val: 3, label: 'Continue my regular monthly investments without panic' },
                    { val: 4, label: 'Invest more because quality investments are at a temporary discount' },
                  ].map((opt) => (
                    <label
                      key={opt.val}
                      onClick={() => setRiskAnswers({ ...riskAnswers, 1: opt.val })}
                      className={`flex items-center gap-3 p-3 rounded-xl border cursor-pointer transition-all ${
                        riskAnswers[1] === opt.val
                          ? 'border-emerald-500 bg-emerald-50/80 text-emerald-950 font-semibold'
                          : 'border-slate-200 bg-white hover:bg-slate-50 text-slate-700'
                      }`}
                    >
                      <input
                        type="radio"
                        name="q1"
                        checked={riskAnswers[1] === opt.val}
                        onChange={() => setRiskAnswers({ ...riskAnswers, 1: opt.val })}
                        className="text-emerald-600 focus:ring-emerald-500"
                      />
                      <span className="text-sm">{opt.label}</span>
                    </label>
                  ))}
                </div>
              </div>

              {/* Question 2 */}
              <div className="p-4 rounded-xl border border-slate-200 bg-slate-50/50">
                <span className="text-xs font-bold text-emerald-700 uppercase">Question 2 of 4</span>
                <h3 className="font-bold text-slate-900 text-sm sm:text-base mt-1 mb-3">
                  How long can you leave your invested money untouched without needing to withdraw it?
                </h3>
                <div className="space-y-2">
                  {[
                    { val: 1, label: 'Less than 1 year (I might need it on short notice)' },
                    { val: 2, label: '1 to 3 years' },
                    { val: 3, label: '3 to 7 years' },
                    { val: 4, label: 'More than 7 years (long-term wealth building)' },
                  ].map((opt) => (
                    <label
                      key={opt.val}
                      onClick={() => setRiskAnswers({ ...riskAnswers, 2: opt.val })}
                      className={`flex items-center gap-3 p-3 rounded-xl border cursor-pointer transition-all ${
                        riskAnswers[2] === opt.val
                          ? 'border-emerald-500 bg-emerald-50/80 text-emerald-950 font-semibold'
                          : 'border-slate-200 bg-white hover:bg-slate-50 text-slate-700'
                      }`}
                    >
                      <input
                        type="radio"
                        name="q2"
                        checked={riskAnswers[2] === opt.val}
                        onChange={() => setRiskAnswers({ ...riskAnswers, 2: opt.val })}
                        className="text-emerald-600 focus:ring-emerald-500"
                      />
                      <span className="text-sm">{opt.label}</span>
                    </label>
                  ))}
                </div>
              </div>

              {/* Question 3 */}
              <div className="p-4 rounded-xl border border-slate-200 bg-slate-50/50">
                <span className="text-xs font-bold text-emerald-700 uppercase">Question 3 of 4</span>
                <h3 className="font-bold text-slate-900 text-sm sm:text-base mt-1 mb-3">
                  What is your primary investment objective?
                </h3>
                <div className="space-y-2">
                  {[
                    { val: 1, label: 'Protect my money: I cannot tolerate losing any principal' },
                    { val: 2, label: 'Stable growth: Moderate safety with modest returns' },
                    { val: 3, label: 'Balanced growth: A good mix of company shares and safe bonds' },
                    { val: 4, label: 'Maximum long-term compounding: High growth over many years' },
                  ].map((opt) => (
                    <label
                      key={opt.val}
                      onClick={() => setRiskAnswers({ ...riskAnswers, 3: opt.val })}
                      className={`flex items-center gap-3 p-3 rounded-xl border cursor-pointer transition-all ${
                        riskAnswers[3] === opt.val
                          ? 'border-emerald-500 bg-emerald-50/80 text-emerald-950 font-semibold'
                          : 'border-slate-200 bg-white hover:bg-slate-50 text-slate-700'
                      }`}
                    >
                      <input
                        type="radio"
                        name="q3"
                        checked={riskAnswers[3] === opt.val}
                        onChange={() => setRiskAnswers({ ...riskAnswers, 3: opt.val })}
                        className="text-emerald-600 focus:ring-emerald-500"
                      />
                      <span className="text-sm">{opt.label}</span>
                    </label>
                  ))}
                </div>
              </div>

              {/* Question 4 */}
              <div className="p-4 rounded-xl border border-slate-200 bg-slate-50/50">
                <span className="text-xs font-bold text-emerald-700 uppercase">Question 4 of 4</span>
                <h3 className="font-bold text-slate-900 text-sm sm:text-base mt-1 mb-3">
                  How comfortable are you seeing your account balance fluctuate week to week?
                </h3>
                <div className="space-y-2">
                  {[
                    { val: 1, label: 'Very uncomfortable: I prefer guaranteed fixed numbers' },
                    { val: 2, label: 'Slightly uncomfortable: Small ups and downs are okay' },
                    { val: 3, label: 'Comfortable: I understand fluctuations are normal in investing' },
                    { val: 4, label: 'Very comfortable: Short-term swings don’t bother me at all' },
                  ].map((opt) => (
                    <label
                      key={opt.val}
                      onClick={() => setRiskAnswers({ ...riskAnswers, 4: opt.val })}
                      className={`flex items-center gap-3 p-3 rounded-xl border cursor-pointer transition-all ${
                        riskAnswers[4] === opt.val
                          ? 'border-emerald-500 bg-emerald-50/80 text-emerald-950 font-semibold'
                          : 'border-slate-200 bg-white hover:bg-slate-50 text-slate-700'
                      }`}
                    >
                      <input
                        type="radio"
                        name="q4"
                        checked={riskAnswers[4] === opt.val}
                        onChange={() => setRiskAnswers({ ...riskAnswers, 4: opt.val })}
                        className="text-emerald-600 focus:ring-emerald-500"
                      />
                      <span className="text-sm">{opt.label}</span>
                    </label>
                  ))}
                </div>
              </div>

              {/* Dynamic live risk scoring result */}
              <div className="p-5 rounded-2xl bg-indigo-50 border border-indigo-200 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold uppercase tracking-wider text-indigo-900">
                    Transparent Risk Scoring Result
                  </span>
                  <span className="text-xs font-bold px-2 py-0.5 rounded bg-indigo-200 text-indigo-900">
                    Score: {currentRiskProfile.score} / {currentRiskProfile.maxScore}
                  </span>
                </div>

                <div className="flex items-baseline gap-2">
                  <span className="text-xl font-extrabold text-indigo-950">
                    Risk Category: {currentRiskProfile.category}
                  </span>
                  <span className="text-xs text-indigo-700 font-semibold">({currentRiskProfile.tagline})</span>
                </div>

                <p className="text-sm text-indigo-900 leading-relaxed">
                  "{currentRiskProfile.description}"
                </p>

                <div className="pt-2 border-t border-indigo-200/80">
                  <span className="text-xs font-bold text-indigo-800 uppercase block mb-1">
                    Factors that influenced this score:
                  </span>
                  <ul className="text-xs text-indigo-800 space-y-1 list-disc pl-4">
                    {currentRiskProfile.influencingFactors.map((f, i) => (
                      <li key={i}>{f}</li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* STEP 5: Background Financial Analysis Review */}
        {step === 5 && (
          <div className="bg-white rounded-2xl p-6 sm:p-8 shadow-sm border border-slate-200">
            <div className="mb-6">
              <span className="text-xs font-bold uppercase tracking-wider text-emerald-600">Financial Diagnostic</span>
              <h2 className="text-2xl font-bold text-slate-900 mt-1">Review Your Financial Health</h2>
              <p className="text-sm text-slate-600 mt-1">
                Before generating your personalized investment allocation, let's review your core pillars.
              </p>
            </div>

            <div className="space-y-6">
              {/* Financial Health Score preview */}
              <div className="p-5 rounded-2xl bg-gradient-to-r from-emerald-600 to-teal-700 text-white flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                <div>
                  <span className="text-xs font-bold uppercase tracking-wider text-emerald-200">
                    SmartVest Financial Health Score
                  </span>
                  <div className="flex items-baseline gap-2 mt-1">
                    <span className="text-4xl font-extrabold">{currentAnalysis.healthScore}</span>
                    <span className="text-emerald-200 font-bold text-lg">/ 100</span>
                    <span className="ml-2 text-xs font-bold px-2 py-0.5 rounded-full bg-white/20">
                      {currentAnalysis.healthScore >= 75 ? 'Good Standing' : currentAnalysis.healthScore >= 50 ? 'Fair' : 'Needs Focus'}
                    </span>
                  </div>
                  <p className="text-xs text-emerald-100 mt-1">
                    Educational diagnostic combining your savings rate, emergency reserve, debt load, and goal progress.
                  </p>
                </div>
                <div className="text-right sm:text-right w-full sm:w-auto">
                  <span className="text-xs text-emerald-200 block uppercase font-bold">Investable Capacity</span>
                  <span className="text-2xl font-extrabold text-white">
                    {formatCurrency(currentAnalysis.investableCapacity, profile.currency)}
                    <span className="text-xs font-normal text-emerald-100">/mo</span>
                  </span>
                </div>
              </div>

              {/* 4 Health Breakdown Cards */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {/* Emergency fund */}
                <div className="p-4 rounded-xl border border-slate-200 bg-slate-50">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs font-bold text-slate-500 uppercase">Emergency Reserve</span>
                    <span className={`text-xs font-bold px-2 py-0.5 rounded ${
                      currentAnalysis.emergencyStatus === 'good' ? 'bg-emerald-100 text-emerald-800' :
                      currentAnalysis.emergencyStatus === 'attention' ? 'bg-amber-100 text-amber-800' : 'bg-rose-100 text-rose-800'
                    }`}>
                      {currentAnalysis.emergencyFundMonths} Months
                    </span>
                  </div>
                  <p className="text-xs text-slate-600">
                    {currentAnalysis.emergencyFundMonths < 3 
                      ? '⚠️ Below recommended 3-6 months. We will allocate extra buffer to emergency cash before recommending volatile investments.'
                      : '✅ Healthy reserve! You are insulated against unexpected bills.'}
                  </p>
                </div>

                {/* Savings Rate */}
                <div className="p-4 rounded-xl border border-slate-200 bg-slate-50">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs font-bold text-slate-500 uppercase">Savings Rate</span>
                    <span className={`text-xs font-bold px-2 py-0.5 rounded ${
                      currentAnalysis.savingsStatus === 'good' ? 'bg-emerald-100 text-emerald-800' :
                      currentAnalysis.savingsStatus === 'attention' ? 'bg-amber-100 text-amber-800' : 'bg-rose-100 text-rose-800'
                    }`}>
                      {currentAnalysis.savingsRate}% of Income
                    </span>
                  </div>
                  <p className="text-xs text-slate-600">
                    {currentAnalysis.savingsRate >= 20
                      ? '✅ Excellent! Saving 20%+ of your income gives strong compounding power.'
                      : '💡 Aim to gradually increase savings towards 20% by cutting unused subscriptions.'}
                  </p>
                </div>

                {/* Debt load */}
                <div className="p-4 rounded-xl border border-slate-200 bg-slate-50">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs font-bold text-slate-500 uppercase">Debt Burden (EMI)</span>
                    <span className={`text-xs font-bold px-2 py-0.5 rounded ${
                      currentAnalysis.debtStatus === 'good' ? 'bg-emerald-100 text-emerald-800' :
                      currentAnalysis.debtStatus === 'attention' ? 'bg-amber-100 text-amber-800' : 'bg-rose-100 text-rose-800'
                    }`}>
                      {currentAnalysis.debtToIncomeRatio}% of Income
                    </span>
                  </div>
                  <p className="text-xs text-slate-600">
                    {currentAnalysis.debtToIncomeRatio <= 25
                      ? '✅ Very manageable debt load leaving sufficient breathing room.'
                      : '⚠️ EMIs are high. Reducing loan balances will free up investable surplus.'}
                  </p>
                </div>

                {/* Risk Alignment */}
                <div className="p-4 rounded-xl border border-slate-200 bg-slate-50">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs font-bold text-slate-500 uppercase">Risk Strategy</span>
                    <span className="text-xs font-bold px-2 py-0.5 rounded bg-indigo-100 text-indigo-800">
                      {currentRiskProfile.category}
                    </span>
                  </div>
                  <p className="text-xs text-slate-600">
                    Suggested horizon: {currentRiskProfile.suggestedHorizon}. We balance growth assets with fixed income anchors.
                  </p>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* STEP 6: Plan Ready Celebration */}
        {step === 6 && (
          <div className="bg-white rounded-2xl p-6 sm:p-10 shadow-sm border border-slate-200 text-center space-y-6">
            <div className="w-16 h-16 rounded-2xl bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto shadow-inner">
              <ShieldCheck className="w-10 h-10" />
            </div>

            <div className="max-w-md mx-auto">
              <span className="text-xs font-bold uppercase tracking-wider text-emerald-600">All Set</span>
              <h2 className="text-3xl font-extrabold text-slate-900 mt-1">
                Your Investment Plan is Ready!
              </h2>
              <p className="text-sm text-slate-600 mt-2 leading-relaxed">
                SmartVest AI has tailored an asset allocation, prioritized recommendations, and calculated goal progress based on your profile.
              </p>
            </div>

            <div className="p-5 rounded-2xl bg-slate-50 border border-slate-200 text-left max-w-lg mx-auto space-y-3">
              <div className="flex justify-between text-xs py-1 border-b border-slate-200">
                <span className="text-slate-500 font-bold uppercase">Risk Profile</span>
                <span className="font-extrabold text-slate-900">{currentRiskProfile.category}</span>
              </div>
              <div className="flex justify-between text-xs py-1 border-b border-slate-200">
                <span className="text-slate-500 font-bold uppercase">Monthly Investable</span>
                <span className="font-extrabold text-emerald-700">{formatCurrency(currentAnalysis.investableCapacity, profile.currency)} / month</span>
              </div>
              <div className="flex justify-between text-xs py-1 border-b border-slate-200">
                <span className="text-slate-500 font-bold uppercase">Active Goals</span>
                <span className="font-extrabold text-slate-900">{goals.length} Goals Registered</span>
              </div>
              <div className="flex justify-between text-xs py-1">
                <span className="text-slate-500 font-bold uppercase">Health Score</span>
                <span className="font-extrabold text-indigo-700">{currentAnalysis.healthScore} / 100</span>
              </div>
            </div>

            <div className="pt-4 max-w-sm mx-auto">
              <button
                type="button"
                onClick={handleNext}
                className="w-full flex items-center justify-center gap-2 py-4 px-6 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-base shadow-lg shadow-emerald-600/25 transition-all cursor-pointer"
              >
                <span>Open My Dashboard</span>
                <ArrowRight className="w-5 h-5" />
              </button>
            </div>
          </div>
        )}

        {/* Navigation buttons: Back / Next */}
        {step < 6 && (
          <div className="mt-8 flex items-center justify-between">
            <button
              type="button"
              onClick={handleBack}
              className="flex items-center gap-2 px-5 py-2.5 rounded-xl border border-slate-300 text-slate-700 hover:bg-slate-100 font-bold text-sm transition-colors cursor-pointer"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>{step === 1 ? 'Cancel' : 'Back'}</span>
            </button>

            <button
              type="button"
              onClick={handleNext}
              className="flex items-center gap-2 px-6 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-sm shadow-md transition-all cursor-pointer"
            >
              <span>{step === totalSteps - 1 ? 'Generate Plan' : 'Save & Continue'}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
