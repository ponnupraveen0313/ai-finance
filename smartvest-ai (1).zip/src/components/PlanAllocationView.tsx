import React, { useState } from 'react';
import { 
  PieChart as PieIcon, 
  HelpCircle, 
  ShieldCheck, 
  AlertTriangle, 
  ArrowUpRight, 
  Sparkles, 
  CheckCircle2, 
  Info, 
  Layers, 
  TrendingUp,
  Calendar,
  Lock,
  ChevronDown,
  ChevronUp
} from 'lucide-react';
import { 
  UserProfile, 
  RiskProfile, 
  FinancialAnalysis, 
  AssetAllocationItem, 
  Recommendation 
} from '../types';
import { formatCurrency } from '../utils/financialCalculations';
import { ExplainBadge } from './ExplainModal';

interface PlanAllocationViewProps {
  profile: UserProfile;
  riskProfile: RiskProfile;
  analysis: FinancialAnalysis;
  allocationItems: AssetAllocationItem[];
  recommendations: Recommendation[];
  onExplain: (term: string) => void;
  onOpenChat: () => void;
}

export const PlanAllocationView: React.FC<PlanAllocationViewProps> = ({
  profile,
  riskProfile,
  analysis,
  allocationItems,
  recommendations,
  onExplain,
  onOpenChat,
}) => {
  const [selectedAssetId, setSelectedAssetId] = useState<string>(allocationItems[0]?.id || 'equity');
  const [expandedRecId, setExpandedRecId] = useState<string | null>(null);

  const selectedAsset = allocationItems.find(a => a.id === selectedAssetId) || allocationItems[0];

  return (
    <div className="space-y-8 pb-12">
      {/* Top Banner with Risk Summary */}
      <div className="bg-white rounded-2xl p-6 sm:p-8 shadow-sm border border-slate-200">
        <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold uppercase tracking-wider text-emerald-600">
                Personalized Investment Plan
              </span>
              <span className="text-xs font-bold px-2 py-0.5 rounded-full bg-indigo-100 text-indigo-800">
                Risk Profile: {riskProfile.category}
              </span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 mt-1">
              Your Dynamic Asset Allocation
            </h1>
            <p className="text-sm text-slate-600 mt-2 max-w-2xl leading-relaxed">
              {profile.beginnerMode ? (
                <span>
                  We recommend dividing your monthly investable money ({formatCurrency(analysis.investableCapacity, profile.currency)}) into 4 buckets to balance safety, steady returns, and long-term company growth.
                </span>
              ) : (
                <span>
                  Target asset mix tailored to your {riskProfile.category} profile, {analysis.emergencyFundMonths.toFixed(1)}-month liquidity buffer, and debt obligations.
                </span>
              )}
            </p>
          </div>

          <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 text-right w-full lg:w-auto">
            <span className="text-xs font-bold text-slate-500 uppercase block">Monthly Investable Surplus</span>
            <span className="text-3xl font-extrabold text-emerald-600">
              {formatCurrency(analysis.investableCapacity, profile.currency)}
            </span>
            <span className="text-[11px] text-slate-500 block mt-0.5">Calculated safely after living costs</span>
          </div>
        </div>

        {/* Guaranteed Returns Warning Pill */}
        <div className="mt-6 p-3.5 rounded-xl bg-amber-50/80 border border-amber-200 text-xs text-amber-900 flex items-start gap-2.5">
          <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
          <p className="leading-relaxed">
            <strong>Educational Note:</strong> Historically, diversified investments provide solid growth over multi-year horizons, but <strong>returns are never guaranteed</strong>. Investment values fluctuate with market conditions.
          </p>
        </div>
      </div>

      {/* Main Allocation Section: Visual Chart + Asset Selector */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left Column: Interactive Allocation Bar / Breakdown */}
        <div className="lg:col-span-5 bg-white rounded-2xl p-6 shadow-sm border border-slate-200 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-bold text-slate-900">Allocation Breakdown</h2>
              <ExplainBadge term="asset_allocation" onExplain={onExplain} />
            </div>

            {/* Segmented visual progress bar */}
            <div className="h-6 w-full rounded-xl overflow-hidden flex shadow-inner mb-6">
              {allocationItems.map((item) => (
                <div
                  key={item.id}
                  style={{ width: `${item.percentage}%`, backgroundColor: item.color }}
                  className="h-full transition-all hover:opacity-90 cursor-pointer relative group"
                  onClick={() => setSelectedAssetId(item.id)}
                  title={`${item.name}: ${item.percentage}%`}
                />
              ))}
            </div>

            {/* Asset Items List */}
            <div className="space-y-3">
              {allocationItems.map((item) => {
                const isSelected = item.id === selectedAssetId;
                return (
                  <div
                    key={item.id}
                    onClick={() => setSelectedAssetId(item.id)}
                    className={`p-4 rounded-xl border transition-all cursor-pointer ${
                      isSelected
                        ? 'border-emerald-500 bg-emerald-50/40 shadow-sm'
                        : 'border-slate-200 bg-white hover:bg-slate-50'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div
                          className="w-4 h-4 rounded-full shrink-0"
                          style={{ backgroundColor: item.color }}
                        />
                        <div>
                          <div className="font-bold text-slate-900 text-sm">{item.name}</div>
                          <div className="text-[11px] text-slate-500">{item.categoryName}</div>
                        </div>
                      </div>

                      <div className="text-right">
                        <span className="font-extrabold text-slate-900 text-base">{item.percentage}%</span>
                        <div className="text-xs text-slate-500 font-semibold">
                          ~{formatCurrency(item.amount, profile.currency)}/mo
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          <div className="mt-6 pt-4 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
            <span>Total: 100% Diversified</span>
            <button
              onClick={() => onExplain('diversification')}
              className="text-emerald-700 hover:text-emerald-800 font-bold flex items-center gap-1"
            >
              <Info className="w-3.5 h-3.5" />
              <span>Why diversify?</span>
            </button>
          </div>
        </div>

        {/* Right Column: Deep-Dive Card into the Selected Asset */}
        <div className="lg:col-span-7 bg-white rounded-2xl p-6 sm:p-8 shadow-sm border border-slate-200">
          <div className="flex items-center justify-between pb-4 border-b border-slate-100">
            <div className="flex items-center gap-3">
              <div 
                className="w-10 h-10 rounded-xl flex items-center justify-center text-white font-bold"
                style={{ backgroundColor: selectedAsset.color }}
              >
                <Layers className="w-5 h-5" />
              </div>
              <div>
                <span className="text-xs font-bold uppercase tracking-wider text-slate-500">
                  Asset Details
                </span>
                <h3 className="text-xl font-bold text-slate-900">{selectedAsset.name}</h3>
              </div>
            </div>

            <div className="text-right">
              <span className="text-2xl font-extrabold text-slate-900">{selectedAsset.percentage}%</span>
              <div className="text-xs text-slate-500 font-semibold">
                {formatCurrency(selectedAsset.amount, profile.currency)} per month
              </div>
            </div>
          </div>

          <div className="mt-6 space-y-5">
            {/* Plain English explanation */}
            <div>
              <span className="text-xs font-bold text-slate-500 uppercase block mb-1">
                {profile.beginnerMode ? 'What Does This Mean In Simple Words?' : 'Asset Description'}
              </span>
              <p className="text-sm text-slate-700 leading-relaxed font-medium bg-slate-50 p-3.5 rounded-xl border border-slate-200">
                {profile.beginnerMode ? selectedAsset.simpleDescription : selectedAsset.technicalDescription}
              </p>
            </div>

            {/* Why For You */}
            <div className="p-3.5 rounded-xl bg-emerald-50/70 border border-emerald-200">
              <div className="flex items-start gap-2.5">
                <Sparkles className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                <div>
                  <span className="text-xs font-bold text-emerald-900 uppercase">Why is this in your plan?</span>
                  <p className="text-xs text-emerald-800 mt-0.5 leading-relaxed font-medium">
                    {selectedAsset.whyForYou}
                  </p>
                </div>
              </div>
            </div>

            {/* Benefits & Risks side-by-side */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="p-3.5 rounded-xl bg-emerald-50/40 border border-emerald-100">
                <span className="text-xs font-bold text-emerald-800 uppercase flex items-center gap-1.5 mb-2">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                  Key Benefits
                </span>
                <ul className="text-xs text-slate-700 space-y-1.5 list-disc pl-4">
                  {selectedAsset.benefits.map((b, i) => (
                    <li key={i}>{b}</li>
                  ))}
                </ul>
              </div>

              <div className="p-3.5 rounded-xl bg-rose-50/40 border border-rose-100">
                <span className="text-xs font-bold text-rose-800 uppercase flex items-center gap-1.5 mb-2">
                  <AlertTriangle className="w-3.5 h-3.5 text-rose-600" />
                  Main Risks to Know
                </span>
                <ul className="text-xs text-slate-700 space-y-1.5 list-disc pl-4">
                  {selectedAsset.risks.map((r, i) => (
                    <li key={i}>{r}</li>
                  ))}
                </ul>
              </div>
            </div>

            {/* Horizon & Examples */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
              <div className="flex items-center gap-3 p-3 rounded-xl bg-slate-50 border border-slate-200">
                <Calendar className="w-5 h-5 text-indigo-600 shrink-0" />
                <div>
                  <span className="text-[10px] font-bold text-slate-500 uppercase block">Suggested Time Horizon</span>
                  <span className="text-xs font-bold text-slate-900">{selectedAsset.timeHorizon}</span>
                </div>
              </div>

              <div className="flex items-start gap-3 p-3 rounded-xl bg-slate-50 border border-slate-200">
                <Layers className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
                <div>
                  <span className="text-[10px] font-bold text-slate-500 uppercase block">Typical Fund Examples</span>
                  <span className="text-xs font-semibold text-slate-800">
                    {selectedAsset.examples.join(', ')}
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Recommendations Engine Section */}
      <div className="bg-white rounded-2xl p-6 sm:p-8 shadow-sm border border-slate-200">
        <div className="mb-6">
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold uppercase tracking-wider text-emerald-600">Smart Recommendation Engine</span>
            <span className="text-xs font-bold px-2 py-0.5 rounded bg-slate-100 text-slate-700">
              {recommendations.length} Actionable Steps
            </span>
          </div>
          <h2 className="text-2xl font-bold text-slate-900 mt-1">
            Prioritized Financial Recommendations
          </h2>
          <p className="text-sm text-slate-600 mt-1">
            SmartVest AI explains the exact reasoning behind every recommendation so you stay in total control.
          </p>
        </div>

        <div className="space-y-4">
          {recommendations.map((rec) => {
            const isExpanded = expandedRecId === rec.id;
            return (
              <div 
                key={rec.id} 
                className={`p-5 rounded-xl border transition-all ${
                  rec.priority === 'high' ? 'border-amber-300 bg-amber-50/20' : 'border-slate-200 bg-white'
                }`}
              >
                <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                  <div className="flex items-center gap-2.5">
                    <span className={`text-[10px] uppercase font-extrabold px-2 py-0.5 rounded ${
                      rec.priority === 'high' ? 'bg-amber-100 text-amber-800' :
                      rec.priority === 'medium' ? 'bg-blue-100 text-blue-800' : 'bg-slate-100 text-slate-700'
                    }`}>
                      {rec.priority} Priority
                    </span>
                    <h3 className="font-bold text-slate-900 text-base">{rec.title}</h3>
                  </div>

                  <button
                    onClick={() => setExpandedRecId(isExpanded ? null : rec.id)}
                    className="flex items-center gap-1 text-xs font-bold text-emerald-700 hover:text-emerald-800 bg-emerald-50 px-2.5 py-1 rounded-lg transition-colors cursor-pointer"
                  >
                    <span>{isExpanded ? 'Hide Details' : 'Why am I seeing this?'}</span>
                    {isExpanded ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
                  </button>
                </div>

                <div className="mt-3 text-sm text-slate-700 leading-relaxed">
                  <strong className="text-slate-900 font-semibold">Why? </strong>
                  {rec.why}
                </div>

                <div className="mt-3 p-3 rounded-lg bg-slate-50 border border-slate-200/80 flex items-start gap-2 text-xs">
                  <ArrowUpRight className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                  <div>
                    <strong className="text-slate-900">Suggested Action: </strong>
                    <span className="text-slate-700">{rec.suggestedAction}</span>
                  </div>
                </div>

                {/* Transparency accordion: Data influence factors */}
                {isExpanded && (
                  <div className="mt-4 pt-3 border-t border-slate-200/80 text-xs bg-slate-50/70 p-3 rounded-lg animate-in fade-in">
                    <span className="font-bold text-slate-700 uppercase block mb-1.5 flex items-center gap-1.5">
                      <Sparkles className="w-3.5 h-3.5 text-indigo-600" />
                      Factors From Your Profile That Influenced This:
                    </span>
                    <ul className="space-y-1 list-disc pl-4 text-slate-600">
                      {rec.dataInfluences.map((factor, idx) => (
                        <li key={idx}>{factor}</li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
