import React, { useState } from 'react';
import { 
  BookOpen, 
  Search, 
  Sparkles, 
  Lightbulb, 
  CheckCircle2, 
  AlertTriangle, 
  ArrowRight,
  TrendingUp,
  ShieldCheck,
  Calendar,
  Layers,
  PiggyBank,
  PieChart,
  Flame,
  Zap,
  LifeBuoy,
  Compass,
  X
} from 'lucide-react';
import { EDUCATION_ARTICLES, GlossaryTerm, GLOSSARY_TERMS } from '../data/educationData';
import { EducationArticle } from '../types';

interface EducationViewProps {
  onExplain: (term: string) => void;
  beginnerMode: boolean;
}

export const EducationView: React.FC<EducationViewProps> = ({ onExplain, beginnerMode }) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedArticle, setSelectedArticle] = useState<EducationArticle | null>(null);

  const categories = ['all', 'Foundations', 'Asset Classes', 'Strategy', 'Safety', 'Mindset'];

  const filteredArticles = EDUCATION_ARTICLES.filter(art => {
    const matchesCategory = selectedCategory === 'all' || art.category.toLowerCase() === selectedCategory.toLowerCase();
    const matchesSearch = art.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      art.simpleDefinition.toLowerCase().includes(searchQuery.toLowerCase()) ||
      art.keyTakeaway.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <div className="space-y-8 pb-12">
      {/* Top Banner */}
      <div className="bg-white rounded-2xl p-6 sm:p-8 shadow-sm border border-slate-200">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold uppercase tracking-wider text-emerald-600">SmartVest Academy</span>
              <span className="text-xs font-bold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800">
                12 Essential Masterclasses
              </span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 mt-1">
              Beginner Investment Education Center
            </h1>
            <p className="text-sm text-slate-600 mt-1 max-w-2xl">
              No complex jargon or sales pitches. Every core financial concept explained with everyday real-life analogies, pros, cons, and practical examples.
            </p>
          </div>

          <div className="flex items-center gap-2 w-full sm:w-auto">
            <div className="relative w-full sm:w-64">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search concepts, SIP, ETF..."
                className="w-full pl-9 pr-4 py-2 rounded-xl border border-slate-300 text-xs font-semibold focus:border-emerald-500 outline-none"
              />
            </div>
          </div>
        </div>

        {/* Category Pills */}
        <div className="flex flex-wrap gap-2 mt-6 pt-6 border-t border-slate-100">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold capitalize transition-all ${
                selectedCategory === cat
                  ? 'bg-emerald-600 text-white shadow-sm'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              {cat === 'all' ? 'All Lessons (12)' : cat}
            </button>
          ))}
        </div>
      </div>

      {/* Grid of Articles */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredArticles.map((art) => (
          <div
            key={art.id}
            onClick={() => setSelectedArticle(art)}
            className="bg-white rounded-2xl p-6 shadow-sm border border-slate-200 hover:border-emerald-300 hover:shadow-md transition-all cursor-pointer flex flex-col justify-between group"
          >
            <div>
              <div className="flex items-center justify-between text-xs text-slate-500 font-semibold mb-3">
                <span className="px-2 py-0.5 rounded bg-slate-100 text-slate-700 font-bold uppercase text-[10px]">
                  {art.category}
                </span>
                <span>{art.readTime} read</span>
              </div>

              <h3 className="text-lg font-bold text-slate-900 group-hover:text-emerald-700 transition-colors">
                {art.title}
              </h3>

              <p className="text-xs text-slate-600 mt-2 line-clamp-3 leading-relaxed">
                {art.simpleDefinition}
              </p>
            </div>

            <div className="mt-5 pt-4 border-t border-slate-100 flex items-center justify-between">
              <span className="text-xs font-bold text-emerald-700 flex items-center gap-1 group-hover:translate-x-0.5 transition-transform">
                Read Masterclass
                <ArrowRight className="w-3.5 h-3.5" />
              </span>
              <span className="text-[10px] text-slate-400 font-medium">Click to open</span>
            </div>
          </div>
        ))}
      </div>

      {/* Deep-Dive Article Modal */}
      {selectedArticle && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in">
          <div className="bg-white rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto p-6 sm:p-8 shadow-2xl border border-slate-200 relative">
            <button
              onClick={() => setSelectedArticle(null)}
              className="absolute top-4 right-4 p-2 text-slate-400 hover:text-slate-600 rounded-full hover:bg-slate-100 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-2 text-xs font-bold text-emerald-700 uppercase mb-2">
              <span>{selectedArticle.category}</span>
              <span>•</span>
              <span>{selectedArticle.readTime} Read</span>
            </div>

            <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 mb-4">
              {selectedArticle.title}
            </h2>

            <div className="space-y-5">
              {/* Definition */}
              <div className="p-4 rounded-xl bg-slate-50 border border-slate-200">
                <span className="text-xs font-bold text-slate-500 uppercase block mb-1">Simple Definition</span>
                <p className="text-slate-800 text-sm font-medium leading-relaxed">
                  {selectedArticle.simpleDefinition}
                </p>
              </div>

              {/* Analogy */}
              <div className="p-4 rounded-xl bg-amber-50/70 border border-amber-200">
                <div className="flex items-start gap-2.5">
                  <Lightbulb className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
                  <div>
                    <span className="text-xs font-bold text-amber-900 uppercase">Real-Life Everyday Analogy</span>
                    <p className="text-slate-800 text-sm mt-1 leading-relaxed">
                      {selectedArticle.realLifeExample}
                    </p>
                  </div>
                </div>
              </div>

              {/* Benefits & Risks */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="p-4 rounded-xl bg-emerald-50/50 border border-emerald-100">
                  <span className="text-xs font-bold text-emerald-800 uppercase flex items-center gap-1.5 mb-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                    Key Benefits
                  </span>
                  <ul className="text-xs text-slate-700 space-y-1.5 list-disc pl-4">
                    {selectedArticle.benefits.map((b, i) => (
                      <li key={i}>{b}</li>
                    ))}
                  </ul>
                </div>

                <div className="p-4 rounded-xl bg-rose-50/50 border border-rose-100">
                  <span className="text-xs font-bold text-rose-800 uppercase flex items-center gap-1.5 mb-2">
                    <AlertTriangle className="w-4 h-4 text-rose-600" />
                    Risks to Keep in Mind
                  </span>
                  <ul className="text-xs text-slate-700 space-y-1.5 list-disc pl-4">
                    {selectedArticle.risks.map((r, i) => (
                      <li key={i}>{r}</li>
                    ))}
                  </ul>
                </div>
              </div>

              {/* When Useful */}
              <div className="p-4 rounded-xl bg-indigo-50/50 border border-indigo-100 text-xs">
                <span className="font-bold text-indigo-900 uppercase block mb-1">When Is This Most Useful?</span>
                <p className="text-slate-700 leading-relaxed font-medium">
                  {selectedArticle.whenUseful}
                </p>
              </div>

              {/* Key Takeaway */}
              <div className="p-4 rounded-xl bg-slate-900 text-white text-xs">
                <span className="font-extrabold text-emerald-400 uppercase tracking-wider block mb-1">
                  Core Golden Rule
                </span>
                <p className="text-sm font-semibold text-slate-100">
                  "{selectedArticle.keyTakeaway}"
                </p>
              </div>
            </div>

            <div className="mt-6 flex justify-end">
              <button
                onClick={() => setSelectedArticle(null)}
                className="px-5 py-2.5 bg-slate-900 text-white rounded-xl font-bold text-xs hover:bg-slate-800 transition-colors"
              >
                Close Lesson
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
