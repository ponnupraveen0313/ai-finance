import React from 'react';
import { 
  ShieldCheck, 
  TrendingUp, 
  PieChart, 
  Target, 
  BookOpen, 
  Calculator, 
  MessageSquareCode, 
  User, 
  Sparkles, 
  HeartPulse,
  HelpCircle,
  RotateCcw,
  Download
} from 'lucide-react';
import { UserProfile } from '../types';

interface NavbarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  profile: UserProfile;
  setProfile: React.Dispatch<React.SetStateAction<UserProfile>>;
  onLoadDemo: () => void;
  onReset: () => void;
  onExplain: (term: string) => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  profile,
  setProfile,
  onLoadDemo,
  onReset,
  onExplain
}) => {
  const toggleBeginnerMode = () => {
    setProfile(prev => ({ ...prev, beginnerMode: !prev.beginnerMode }));
  };

  const toggleCurrency = () => {
    setProfile(prev => ({ ...prev, currency: prev.currency === 'INR' ? 'USD' : 'INR' }));
  };

  const navItems = [
    { id: 'dashboard', label: 'Dashboard', icon: TrendingUp },
    { id: 'plan', label: 'Investment Plan', icon: PieChart },
    { id: 'goals', label: 'Goals', icon: Target },
    { id: 'health', label: 'Health Check', icon: HeartPulse },
    { id: 'calculators', label: 'Calculators', icon: Calculator },
    { id: 'learn', label: 'Learn', icon: BookOpen },
    { id: 'chat', label: 'Ask AI', icon: MessageSquareCode, badge: 'AI' },
    { id: 'profile', label: 'Profile', icon: User },
  ];

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <div className="flex items-center gap-3 cursor-pointer" onClick={() => setActiveTab('dashboard')}>
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-emerald-600 to-teal-500 flex items-center justify-center text-white shadow-md shadow-emerald-600/20">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-extrabold text-xl tracking-tight text-slate-900 font-display">
                  SmartVest<span className="text-emerald-600">AI</span>
                </span>
                <span className="text-[10px] font-bold px-1.5 py-0.5 bg-emerald-100 text-emerald-800 rounded">
                  DEMO ADVISOR
                </span>
              </div>
              <p className="text-[11px] text-slate-500 hidden sm:block font-medium">
                Understand your money. Plan your future. Invest smarter.
              </p>
            </div>
          </div>

          {/* Desktop Nav Items */}
          <nav className="hidden lg:flex items-center gap-1">
            {navItems.map(item => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => setActiveTab(item.id)}
                  className={`flex items-center gap-1.5 px-3 py-2 rounded-lg text-sm font-semibold transition-all relative ${
                    isActive
                      ? 'text-emerald-700 bg-emerald-50'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                  }`}
                >
                  <Icon className={`w-4 h-4 ${isActive ? 'text-emerald-600' : 'text-slate-400'}`} />
                  <span>{item.label}</span>
                  {item.badge && (
                    <span className="text-[10px] px-1 py-0.2 bg-emerald-600 text-white font-extrabold rounded-full">
                      {item.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </nav>

          {/* Controls: Beginner Mode toggle, Currency, Demo button */}
          <div className="flex items-center gap-2 sm:gap-3">
            {/* Beginner Mode toggle */}
            <button
              onClick={toggleBeginnerMode}
              type="button"
              className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-full text-xs font-semibold border transition-all ${
                profile.beginnerMode
                  ? 'bg-amber-50 text-amber-900 border-amber-300 shadow-sm'
                  : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100'
              }`}
              title="Toggle Beginner Mode: Simplifies complex financial terms with plain English explanations"
            >
              <Sparkles className={`w-3.5 h-3.5 ${profile.beginnerMode ? 'text-amber-600' : 'text-slate-400'}`} />
              <span className="hidden sm:inline">Beginner Mode:</span>
              <span className={`font-bold ${profile.beginnerMode ? 'text-amber-700' : 'text-slate-500'}`}>
                {profile.beginnerMode ? 'ON' : 'OFF'}
              </span>
            </button>

            {/* Currency selector */}
            <button
              onClick={toggleCurrency}
              className="px-2 py-1 rounded-lg text-xs font-bold bg-slate-100 hover:bg-slate-200 text-slate-700 transition-colors"
              title="Switch currency display between ₹ (INR) and $ (USD)"
            >
              {profile.currency === 'INR' ? '₹ INR' : '$ USD'}
            </button>

            {/* Quick Demo button */}
            <button
              onClick={onLoadDemo}
              className="hidden sm:flex items-center gap-1 text-xs font-bold text-emerald-700 hover:text-emerald-800 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 px-3 py-1.5 rounded-lg transition-colors cursor-pointer"
              title="Load instant pre-filled sample user profile"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>Try Demo</span>
            </button>

            {/* Download Project ZIP */}
            <a
              href="/api/download-zip"
              download="smartvest-ai.zip"
              className="flex items-center gap-1.5 text-xs font-bold text-slate-700 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 border border-slate-200 px-2.5 py-1.5 rounded-lg transition-colors cursor-pointer"
              title="Download complete project source code as a ZIP file"
            >
              <Download className="w-3.5 h-3.5 text-slate-600" />
              <span className="hidden sm:inline">ZIP</span>
            </a>
          </div>
        </div>
      </div>
    </header>
  );
};
