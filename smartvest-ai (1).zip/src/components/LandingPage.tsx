import React from 'react';
import { 
  ShieldCheck, 
  ArrowRight, 
  Sparkles, 
  CheckCircle2, 
  PieChart, 
  TrendingUp, 
  HelpCircle, 
  Bot, 
  Calculator, 
  HeartHandshake, 
  AlertTriangle,
  Lightbulb,
  Compass,
  Zap,
  DollarSign
} from 'lucide-react';
import { ExplainBadge } from './ExplainModal';

interface LandingPageProps {
  onStartOnboarding: () => void;
  onExploreDemo: () => void;
  onExplain: (term: string) => void;
  beginnerMode: boolean;
}

export const LandingPage: React.FC<LandingPageProps> = ({
  onStartOnboarding,
  onExploreDemo,
  onExplain,
  beginnerMode
}) => {
  return (
    <div className="min-h-screen bg-slate-50 text-slate-900">
      {/* Hero Section */}
      <section className="relative overflow-hidden pt-12 pb-20 sm:pt-20 sm:pb-28">
        <div className="absolute inset-0 bg-gradient-to-b from-emerald-50/70 via-slate-50 to-slate-50 pointer-events-none" />
        
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          {/* Trust badge */}
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-emerald-100/80 border border-emerald-200 text-emerald-800 text-xs sm:text-sm font-semibold mb-6">
            <Sparkles className="w-4 h-4 text-emerald-600" />
            <span>AI-Powered Personal Financial Planning For Everyone</span>
          </div>

          <h1 className="text-4xl sm:text-6xl lg:text-7xl font-extrabold text-slate-950 tracking-tight max-w-4xl mx-auto leading-[1.1]">
            Understand your money.{' '}
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-600 to-teal-600">
              Plan your future.
            </span>{' '}
            Invest smarter.
          </h1>

          <p className="mt-6 text-lg sm:text-xl text-slate-600 max-w-2xl mx-auto leading-relaxed">
            SmartVest AI turns complex financial jargon into crystal-clear steps. Get a personalized investment plan, dynamic asset allocation, and step-by-step guidance tailored to your real life—even if you've never invested before.
          </p>

          {/* Action buttons */}
          <div className="mt-10 flex flex-col sm:flex-row items-center justify-center gap-4 max-w-md mx-auto">
            <button
              onClick={onStartOnboarding}
              className="w-full sm:w-auto flex items-center justify-center gap-2 px-8 py-4 bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 text-white font-bold rounded-xl shadow-lg shadow-emerald-600/25 transition-all text-base group cursor-pointer"
            >
              <span>Create My Investment Plan</span>
              <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
            </button>
            <button
              onClick={onExploreDemo}
              className="w-full sm:w-auto flex items-center justify-center gap-2 px-6 py-4 bg-white hover:bg-slate-100 active:bg-slate-200 text-slate-800 font-bold rounded-xl border border-slate-200 shadow-sm transition-all text-base cursor-pointer"
            >
              <Sparkles className="w-4 h-4 text-amber-500" />
              <span>Explore Demo Profile</span>
            </button>
          </div>

          {/* Mini guarantee/trust highlights */}
          <div className="mt-8 flex flex-wrap items-center justify-center gap-6 text-xs sm:text-sm text-slate-500 font-medium">
            <div className="flex items-center gap-1.5">
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
              <span>100% Free Educational Guidance</span>
            </div>
            <div className="flex items-center gap-1.5">
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
              <span>No Jargon / Plain English</span>
            </div>
            <div className="flex items-center gap-1.5">
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
              <span>No Real Banking Passwords Required</span>
            </div>
          </div>

          {/* Interactive preview card */}
          <div className="mt-14 max-w-4xl mx-auto bg-white rounded-2xl p-6 sm:p-8 shadow-xl border border-slate-200 text-left">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between pb-6 border-b border-slate-100 gap-4">
              <div>
                <span className="text-xs uppercase font-bold tracking-wider text-emerald-600">Sample SmartVest Dashboard Preview</span>
                <h3 className="text-xl sm:text-2xl font-bold text-slate-900 mt-1">
                  How SmartVest AI Translates Your Money
                </h3>
              </div>
              <div className="flex items-center gap-2 bg-emerald-50 px-3 py-1.5 rounded-lg border border-emerald-200 text-emerald-800 text-xs font-bold">
                <ShieldCheck className="w-4 h-4" />
                <span>Financial Health: 74/100 (Solid)</span>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pt-6">
              {/* Card 1 */}
              <div className="p-4 rounded-xl bg-slate-50 border border-slate-200">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-bold text-slate-500 uppercase">Emergency Cushion</span>
                  <ExplainBadge term="emergency_fund" onExplain={onExplain} />
                </div>
                <div className="text-2xl font-extrabold text-slate-900">3.0 Months</div>
                <p className="text-xs text-slate-600 mt-2">
                  Protects your long-term investments from sudden hospital bills or job transitions.
                </p>
              </div>

              {/* Card 2 */}
              <div className="p-4 rounded-xl bg-slate-50 border border-slate-200">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-bold text-slate-500 uppercase">Risk Classification</span>
                  <ExplainBadge term="risk_tolerance" onExplain={onExplain} />
                </div>
                <div className="text-2xl font-extrabold text-indigo-600">Moderate Growth</div>
                <p className="text-xs text-slate-600 mt-2">
                  Balanced approach: rides long-term company growth with steady fixed income anchors.
                </p>
              </div>

              {/* Card 3 */}
              <div className="p-4 rounded-xl bg-slate-50 border border-slate-200">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-bold text-slate-500 uppercase">Dynamic Allocation</span>
                  <ExplainBadge term="asset_allocation" onExplain={onExplain} />
                </div>
                <div className="text-2xl font-extrabold text-emerald-600">50% Equity / 30% Debt</div>
                <p className="text-xs text-slate-600 mt-2">
                  Tailored percentages based on your debt, monthly surplus, and horizon.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Section 1: What SmartVest AI Does */}
      <section className="py-16 sm:py-24 bg-white border-y border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <span className="text-xs font-bold uppercase tracking-wider text-emerald-600">Built For Real Beginners</span>
            <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 mt-2">
              What SmartVest AI Does For You
            </h2>
            <p className="mt-4 text-base sm:text-lg text-slate-600">
              Most financial advice is either packed with intimidating Wall Street jargon or tries to sell you high-commission products. SmartVest AI is strictly focused on your educational empowerment.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <div className="p-6 rounded-2xl bg-slate-50 border border-slate-200 hover:border-emerald-300 transition-all">
              <div className="w-12 h-12 rounded-xl bg-emerald-100 text-emerald-700 flex items-center justify-center font-bold mb-4">
                <HeartHandshake className="w-6 h-6" />
              </div>
              <h3 className="text-lg font-bold text-slate-900 mb-2">Personalized Financial Diagnosis</h3>
              <p className="text-sm text-slate-600 leading-relaxed">
                Calculates your genuine savings rate, debt-to-income ratio, emergency cushion in months, and safe investable capacity without risking bill money.
              </p>
            </div>

            <div className="p-6 rounded-2xl bg-slate-50 border border-slate-200 hover:border-emerald-300 transition-all">
              <div className="w-12 h-12 rounded-xl bg-indigo-100 text-indigo-700 flex items-center justify-center font-bold mb-4">
                <Compass className="w-6 h-6" />
              </div>
              <h3 className="text-lg font-bold text-slate-900 mb-2">Transparent Risk Assessment</h3>
              <p className="text-sm text-slate-600 leading-relaxed">
                A 4-question behavioral questionnaire that explains why you fit into Conservative, Moderate, or Aggressive categories—and shows the factors behind it.
              </p>
            </div>

            <div className="p-6 rounded-2xl bg-slate-50 border border-slate-200 hover:border-emerald-300 transition-all">
              <div className="w-12 h-12 rounded-xl bg-teal-100 text-teal-700 flex items-center justify-center font-bold mb-4">
                <PieChart className="w-6 h-6" />
              </div>
              <h3 className="text-lg font-bold text-slate-900 mb-2">Dynamic Asset Allocation</h3>
              <p className="text-sm text-slate-600 leading-relaxed">
                Generates a customized portfolio split (Equity, Debt, Liquid Cash, Gold) with clear explanations of what each asset does and why it was chosen.
              </p>
            </div>

            <div className="p-6 rounded-2xl bg-slate-50 border border-slate-200 hover:border-emerald-300 transition-all">
              <div className="w-12 h-12 rounded-xl bg-amber-100 text-amber-700 flex items-center justify-center font-bold mb-4">
                <Lightbulb className="w-6 h-6" />
              </div>
              <h3 className="text-lg font-bold text-slate-900 mb-2">Explainable Recommendations</h3>
              <p className="text-sm text-slate-600 leading-relaxed">
                Every suggestion comes with a "Why am I seeing this?" button, linking back to your exact savings, emergency buffer, or debt situation.
              </p>
            </div>

            <div className="p-6 rounded-2xl bg-slate-50 border border-slate-200 hover:border-emerald-300 transition-all">
              <div className="w-12 h-12 rounded-xl bg-purple-100 text-purple-700 flex items-center justify-center font-bold mb-4">
                <Bot className="w-6 h-6" />
              </div>
              <h3 className="text-lg font-bold text-slate-900 mb-2">AI Assistant "Ask SmartVest"</h3>
              <p className="text-sm text-slate-600 leading-relaxed">
                Ask any question about SIPs, ETFs, or compounding. The AI understands your current profile numbers so its answers are specifically relevant to you.
              </p>
            </div>

            <div className="p-6 rounded-2xl bg-slate-50 border border-slate-200 hover:border-emerald-300 transition-all">
              <div className="w-12 h-12 rounded-xl bg-blue-100 text-blue-700 flex items-center justify-center font-bold mb-4">
                <Calculator className="w-6 h-6" />
              </div>
              <h3 className="text-lg font-bold text-slate-900 mb-2">Interactive Calculators</h3>
              <p className="text-sm text-slate-600 leading-relaxed">
                Test different monthly SIP amounts, compare compound growth curves, and calculate the exact monthly investment required to reach your goals.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Section 2: How It Works */}
      <section className="py-16 sm:py-24 bg-slate-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <span className="text-xs font-bold uppercase tracking-wider text-emerald-600">Simple 4-Step Process</span>
            <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 mt-2">
              How SmartVest AI Works
            </h2>
            <p className="mt-4 text-base sm:text-lg text-slate-600">
              No endless forms or complex mathematics. We break financial planning down into 4 painless steps.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm relative">
              <div className="w-10 h-10 rounded-xl bg-emerald-600 text-white font-extrabold flex items-center justify-center mb-4">
                1
              </div>
              <h3 className="text-lg font-bold text-slate-900 mb-2">Share Your Basics</h3>
              <p className="text-sm text-slate-600">
                Enter your monthly income, living expenses, existing debt, and emergency savings. We explain why each number matters.
              </p>
            </div>

            <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm relative">
              <div className="w-10 h-10 rounded-xl bg-indigo-600 text-white font-extrabold flex items-center justify-center mb-4">
                2
              </div>
              <h3 className="text-lg font-bold text-slate-900 mb-2">Pick Your Goals</h3>
              <p className="text-sm text-slate-600">
                Select targets like Emergency Fund, Electric Car, House Downpayment, or Long-Term Wealth with realistic target dates.
              </p>
            </div>

            <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm relative">
              <div className="w-10 h-10 rounded-xl bg-teal-600 text-white font-extrabold flex items-center justify-center mb-4">
                3
              </div>
              <h3 className="text-lg font-bold text-slate-900 mb-2">Take Risk Quiz</h3>
              <p className="text-sm text-slate-600">
                Answer 4 simple behavioral questions about how you react to market drops and your investment timeline.
              </p>
            </div>

            <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm relative">
              <div className="w-10 h-10 rounded-xl bg-amber-600 text-white font-extrabold flex items-center justify-center mb-4">
                4
              </div>
              <h3 className="text-lg font-bold text-slate-900 mb-2">Get Custom Plan</h3>
              <p className="text-sm text-slate-600">
                Instantly receive a clear asset allocation, prioritized actions, and an AI assistant ready to answer every doubt.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Beginner Mode Feature Spotlight */}
      <section className="py-16 sm:py-20 bg-emerald-900 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-800 border border-emerald-700 text-emerald-200 text-xs font-bold mb-4">
                <Sparkles className="w-3.5 h-3.5" />
                <span>Beginner Mode Included</span>
              </div>
              <h2 className="text-3xl sm:text-4xl font-extrabold tracking-tight">
                No Financial Jargon Allowed.
              </h2>
              <p className="mt-4 text-emerald-100 text-base sm:text-lg leading-relaxed">
                When you activate Beginner Mode, SmartVest AI strips away intimidating Wall Street vocabulary. Instead of talking about "high beta equities and duration risk," we speak in plain everyday language with relatable real-life analogies.
              </p>
              <div className="mt-6 space-y-3">
                <div className="flex items-center gap-3">
                  <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
                  <span className="text-sm sm:text-base text-emerald-50">Every technical term has an instant "What does this mean?" button.</span>
                </div>
                <div className="flex items-center gap-3">
                  <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
                  <span className="text-sm sm:text-base text-emerald-50">Concrete analogies for SIP, ETFs, compounding, and inflation.</span>
                </div>
                <div className="flex items-center gap-3">
                  <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
                  <span className="text-sm sm:text-base text-emerald-50">Realistic numbers: no wild claims or get-rich-quick schemes.</span>
                </div>
              </div>
            </div>

            {/* Side-by-side comparison box */}
            <div className="bg-slate-900/90 rounded-2xl p-6 border border-emerald-700/50 shadow-2xl space-y-4">
              <div className="p-4 rounded-xl bg-rose-950/40 border border-rose-800/40 text-slate-300 text-xs">
                <span className="text-rose-400 font-bold uppercase tracking-wider block mb-1">Traditional Wall Street App</span>
                <p className="italic">"We recommend an alpha-generating tilt into high-duration corporate credit combined with non-cyclical large-cap equities to mitigate beta drawdown."</p>
              </div>

              <div className="p-4 rounded-xl bg-emerald-950/60 border border-emerald-500/40 text-white text-xs">
                <span className="text-emerald-400 font-bold uppercase tracking-wider block mb-1">SmartVest AI Beginner Mode</span>
                <p className="font-medium">"Invest half your money in 50 top companies so you grow with the economy, and keep 30% in safe government bonds so a market drop won't stress you out."</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Mandatory Disclaimer */}
      <section className="py-12 bg-slate-100 border-t border-slate-200">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="inline-flex items-center gap-2 text-amber-700 text-xs font-bold uppercase tracking-wider mb-2">
            <AlertTriangle className="w-4 h-4" />
            <span>Important Financial Disclaimer</span>
          </div>
          <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
            This application provides educational and informational financial guidance for demonstration purposes. Investment values can rise or fall, and past performance does not guarantee future results. The recommendations shown are not guaranteed returns or a substitute for advice from a qualified financial professional. Users should independently verify information and consider their personal circumstances before making financial decisions.
          </p>
        </div>
      </section>

      {/* CTA Footer */}
      <footer className="py-12 bg-white border-t border-slate-200 text-center">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h3 className="text-2xl font-bold text-slate-900">Ready to take control of your financial journey?</h3>
          <p className="mt-2 text-slate-600 text-sm max-w-md mx-auto">
            Build your personalized investment plan in under 3 minutes.
          </p>
          <div className="mt-6 flex flex-col sm:flex-row items-center justify-center gap-4">
            <button
              onClick={onStartOnboarding}
              className="px-6 py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl shadow-md transition-all text-sm cursor-pointer"
            >
              Create My Investment Plan
            </button>
            <button
              onClick={onExploreDemo}
              className="px-6 py-3 bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold rounded-xl transition-all text-sm cursor-pointer"
            >
              Explore Demo
            </button>
          </div>
          <div className="mt-8 text-xs text-slate-400">
            © 2026 SmartVest AI. Built with precision for intelligent personal investing.
          </div>
        </div>
      </footer>
    </div>
  );
};
