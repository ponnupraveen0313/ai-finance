import React, { useState } from 'react';
import { 
  User, 
  RotateCcw, 
  Sparkles, 
  ShieldAlert, 
  HelpCircle, 
  Check, 
  Compass, 
  AlertTriangle,
  Info,
  DollarSign,
  Download
} from 'lucide-react';
import { UserProfile, EmploymentStatus } from '../types';
import { formatCurrency } from '../utils/financialCalculations';
import { ExplainBadge } from './ExplainModal';

interface ProfileViewProps {
  profile: UserProfile;
  setProfile: React.Dispatch<React.SetStateAction<UserProfile>>;
  onRetakeRisk: () => void;
  onResetData: () => void;
  onLoadDemo: () => void;
  onExplain: (term: string) => void;
}

export const ProfileView: React.FC<ProfileViewProps> = ({
  profile,
  setProfile,
  onRetakeRisk,
  onResetData,
  onLoadDemo,
  onExplain
}) => {
  const [saveSuccess, setSaveSuccess] = useState(false);

  // Form local state
  const [age, setAge] = useState(profile.age);
  const [status, setStatus] = useState<EmploymentStatus>(profile.employmentStatus);
  const [income, setIncome] = useState(profile.monthlyIncome);
  const [expenses, setExpenses] = useState(profile.monthlyExpenses);
  const [emi, setEmi] = useState(profile.monthlyEmi);
  const [emergency, setEmergency] = useState(profile.emergencyFund);
  const [investments, setInvestments] = useState(profile.currentInvestments);
  const [debt, setDebt] = useState(profile.existingDebt);

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    setProfile(prev => ({
      ...prev,
      age: Number(age) || 25,
      employmentStatus: status,
      monthlyIncome: Number(income) || 0,
      monthlyExpenses: Number(expenses) || 0,
      monthlyEmi: Number(emi) || 0,
      emergencyFund: Number(emergency) || 0,
      currentInvestments: Number(investments) || 0,
      existingDebt: Number(debt) || 0,
    }));
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 2500);
  };

  return (
    <div className="space-y-8 pb-12 max-w-4xl mx-auto">
      {/* Profile Header */}
      <div className="bg-white rounded-2xl p-6 sm:p-8 shadow-sm border border-slate-200">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-slate-900 text-white flex items-center justify-center font-bold text-lg">
              <User className="w-6 h-6" />
            </div>
            <div>
              <span className="text-xs font-bold uppercase tracking-wider text-emerald-600">User Profile & Settings</span>
              <h1 className="text-2xl font-extrabold text-slate-900 mt-0.5">
                Financial Profile
              </h1>
              <p className="text-xs text-slate-500 font-medium">
                Update your numbers anytime. All calculations, scores, and allocations will recalculate immediately.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={onLoadDemo}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-50 hover:bg-emerald-100 text-emerald-700 text-xs font-bold border border-emerald-200 transition-colors cursor-pointer"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>Load Demo Data</span>
            </button>
            <button
              onClick={onResetData}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-slate-200 text-rose-600 hover:bg-rose-50 text-xs font-bold transition-colors cursor-pointer"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Reset All</span>
            </button>
          </div>
        </div>
      </div>

      {/* Edit Form */}
      <div className="bg-white rounded-2xl p-6 sm:p-8 shadow-sm border border-slate-200">
        <div className="flex items-center justify-between pb-4 border-b border-slate-100 mb-6">
          <h2 className="text-lg font-bold text-slate-900">Edit Financial Information</h2>
          {saveSuccess && (
            <span className="text-xs font-bold text-emerald-700 flex items-center gap-1 bg-emerald-50 px-2.5 py-1 rounded-lg border border-emerald-200">
              <Check className="w-4 h-4 text-emerald-600" />
              Saved & Recalculated!
            </span>
          )}
        </div>

        <form onSubmit={handleSave} className="space-y-6">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1.5">Your Age</label>
              <input
                type="number"
                min="16"
                max="100"
                value={age}
                onChange={(e) => setAge(Number(e.target.value))}
                className="w-full px-4 py-2.5 rounded-xl border border-slate-300 font-semibold text-slate-900 text-sm focus:border-emerald-500 outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1.5">Employment Status</label>
              <select
                value={status}
                onChange={(e) => setStatus(e.target.value as EmploymentStatus)}
                className="w-full px-4 py-2.5 rounded-xl border border-slate-300 font-semibold text-slate-900 text-sm focus:border-emerald-500 outline-none bg-white"
              >
                <option value="student">Student / Intern</option>
                <option value="salaried">Salaried Employee</option>
                <option value="self_employed">Self-Employed / Freelancer</option>
                <option value="business_owner">Business Owner</option>
                <option value="other">Other</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 pt-2">
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1.5">
                Monthly Income ({profile.currency === 'INR' ? '₹' : '$'})
              </label>
              <input
                type="number"
                min="0"
                step="1000"
                value={income}
                onChange={(e) => setIncome(Number(e.target.value))}
                className="w-full px-4 py-2.5 rounded-xl border border-slate-300 font-semibold text-slate-900 text-sm focus:border-emerald-500 outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1.5">
                Monthly Living Expenses
              </label>
              <input
                type="number"
                min="0"
                step="1000"
                value={expenses}
                onChange={(e) => setExpenses(Number(e.target.value))}
                className="w-full px-4 py-2.5 rounded-xl border border-slate-300 font-semibold text-slate-900 text-sm focus:border-emerald-500 outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1.5">
                Monthly Loan EMI
              </label>
              <input
                type="number"
                min="0"
                step="500"
                value={emi}
                onChange={(e) => setEmi(Number(e.target.value))}
                className="w-full px-4 py-2.5 rounded-xl border border-slate-300 font-semibold text-slate-900 text-sm focus:border-emerald-500 outline-none"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 pt-2">
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1.5">
                Emergency Savings
              </label>
              <input
                type="number"
                min="0"
                step="5000"
                value={emergency}
                onChange={(e) => setEmergency(Number(e.target.value))}
                className="w-full px-4 py-2.5 rounded-xl border border-slate-300 font-semibold text-slate-900 text-sm focus:border-emerald-500 outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1.5">
                Existing Investments
              </label>
              <input
                type="number"
                min="0"
                step="5000"
                value={investments}
                onChange={(e) => setInvestments(Number(e.target.value))}
                className="w-full px-4 py-2.5 rounded-xl border border-slate-300 font-semibold text-slate-900 text-sm focus:border-emerald-500 outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1.5">
                Total Outstanding Debt
              </label>
              <input
                type="number"
                min="0"
                step="5000"
                value={debt}
                onChange={(e) => setDebt(Number(e.target.value))}
                className="w-full px-4 py-2.5 rounded-xl border border-slate-300 font-semibold text-slate-900 text-sm focus:border-emerald-500 outline-none"
              />
            </div>
          </div>

          <div className="pt-4 flex justify-end">
            <button
              type="submit"
              className="px-6 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-sm shadow-md transition-colors cursor-pointer"
            >
              Save & Recalculate Plan
            </button>
          </div>
        </form>
      </div>

      {/* Download Source Code ZIP Card */}
      <div className="bg-white rounded-2xl p-6 sm:p-8 shadow-sm border border-slate-200 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <span className="text-xs font-bold uppercase tracking-wider text-emerald-600">Export Application</span>
          <h3 className="text-xl font-bold text-slate-900 mt-0.5">Download Project ZIP</h3>
          <p className="text-xs text-slate-600 mt-1">
            Download the complete, standalone source code archive (`smartvest-ai.zip`) including all React components, calculators, Express server, and styles.
          </p>
        </div>

        <a
          href="/api/download-zip"
          download="smartvest-ai.zip"
          className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-md transition-colors cursor-pointer shrink-0"
        >
          <Download className="w-4 h-4" />
          <span>Download smartvest-ai.zip</span>
        </a>
      </div>

      {/* Retake Risk Assessment card */}
      <div className="bg-white rounded-2xl p-6 sm:p-8 shadow-sm border border-slate-200 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <span className="text-xs font-bold uppercase tracking-wider text-indigo-600">Behavioral Calibration</span>
          <h3 className="text-xl font-bold text-slate-900 mt-0.5">Retake Risk Assessment</h3>
          <p className="text-xs text-slate-600 mt-1">
            If your comfort with market swings or time horizon has changed, retake the 4-question risk assessment.
          </p>
        </div>

        <button
          onClick={onRetakeRisk}
          className="px-5 py-2.5 rounded-xl bg-indigo-50 hover:bg-indigo-100 text-indigo-700 font-bold text-xs border border-indigo-200 transition-colors cursor-pointer shrink-0"
        >
          Retake Assessment
        </button>
      </div>

      {/* Disclaimer */}
      <div className="p-6 rounded-2xl bg-slate-100 border border-slate-200 text-xs text-slate-600 space-y-2">
        <div className="flex items-center gap-2 text-slate-800 font-bold uppercase tracking-wider">
          <ShieldAlert className="w-4 h-4 text-amber-600" />
          <span>Educational Guidance Disclaimer</span>
        </div>
        <p className="leading-relaxed">
          This application provides educational and informational financial guidance for demonstration purposes. Investment values can rise or fall, and past performance does not guarantee future results. The recommendations shown are not guaranteed returns or a substitute for advice from a qualified financial professional. Users should independently verify information and consider their personal circumstances before making financial decisions.
        </p>
      </div>
    </div>
  );
};
