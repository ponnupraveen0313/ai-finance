import React, { useState } from 'react';
import { 
  Calculator, 
  TrendingUp, 
  Target, 
  Zap, 
  HelpCircle, 
  AlertTriangle, 
  Sparkles,
  ArrowRight,
  PieChart as PieIcon
} from 'lucide-react';
import { UserProfile } from '../types';
import { 
  formatCurrency, 
  calculateSipMath, 
  calculateGoalMonthlyRequirement 
} from '../utils/financialCalculations';
import { ExplainBadge } from './ExplainModal';

interface CalculatorsViewProps {
  profile: UserProfile;
  onExplain: (term: string) => void;
}

export const CalculatorsView: React.FC<CalculatorsViewProps> = ({ profile, onExplain }) => {
  const [activeTab, setActiveTab] = useState<'sip' | 'goal' | 'compound'>('sip');

  // SIP Calculator State
  const [sipMonthly, setSipMonthly] = useState<number>(5000);
  const [sipRate, setSipRate] = useState<number>(12); // Realistic 12% equity average
  const [sipYears, setSipYears] = useState<number>(10);

  // Goal Calculator State
  const [goalTarget, setGoalTarget] = useState<number>(1000000);
  const [goalCurrent, setGoalCurrent] = useState<number>(100000);
  const [goalYears, setGoalYears] = useState<number>(5);
  const [goalRate, setGoalRate] = useState<number>(10);

  // Compound Growth State
  const [compoundInitial, setCompoundInitial] = useState<number>(50000);
  const [compoundMonthly, setCompoundMonthly] = useState<number>(3000);
  const [compoundRate, setCompoundRate] = useState<number>(11);
  const [compoundYears, setCompoundYears] = useState<number>(15);

  // Calculations
  const sipResult = calculateSipMath(sipMonthly, sipRate, sipYears);
  const goalMonthlyReq = calculateGoalMonthlyRequirement(goalTarget, goalCurrent, goalYears, goalRate);

  // Compound growth calculation
  const compoundResult = calculateSipMath(compoundMonthly, compoundRate, compoundYears);
  const i = (compoundRate / 100) / 12;
  const n = compoundYears * 12;
  const initialFv = compoundInitial * Math.pow(1 + i, n);
  const totalCompounded = Math.round(initialFv + compoundResult.estimatedFinalValue);
  const totalInvestedCompounded = compoundInitial + (compoundMonthly * n);
  const compoundGains = Math.max(0, totalCompounded - totalInvestedCompounded);

  return (
    <div className="space-y-8 pb-12">
      {/* Top Banner */}
      <div className="bg-white rounded-2xl p-6 sm:p-8 shadow-sm border border-slate-200">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold uppercase tracking-wider text-emerald-600">Smart Calculators</span>
              <span className="text-xs font-bold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800">
                Interactive Planning
              </span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 mt-1">
              Financial Estimators
            </h1>
            <p className="text-sm text-slate-600 mt-1">
              Simulate disciplined monthly investing, test compounding timelines, and calculate required goal contributions.
            </p>
          </div>

          {/* Calculator Tab Switcher */}
          <div className="flex p-1 bg-slate-100 rounded-xl border border-slate-200 w-full sm:w-auto">
            <button
              onClick={() => setActiveTab('sip')}
              className={`flex-1 sm:flex-initial px-4 py-2 rounded-lg text-xs font-bold transition-all ${
                activeTab === 'sip' ? 'bg-white text-emerald-700 shadow-sm' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              SIP Calculator
            </button>
            <button
              onClick={() => setActiveTab('goal')}
              className={`flex-1 sm:flex-initial px-4 py-2 rounded-lg text-xs font-bold transition-all ${
                activeTab === 'goal' ? 'bg-white text-emerald-700 shadow-sm' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Goal Calculator
            </button>
            <button
              onClick={() => setActiveTab('compound')}
              className={`flex-1 sm:flex-initial px-4 py-2 rounded-lg text-xs font-bold transition-all ${
                activeTab === 'compound' ? 'bg-white text-emerald-700 shadow-sm' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Compound Growth
            </button>
          </div>
        </div>

        {/* Disclaimer Bar */}
        <div className="mt-6 p-3 rounded-xl bg-amber-50 border border-amber-200 text-xs text-amber-900 flex items-start gap-2">
          <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
          <span>
            <strong>Educational Planning Only:</strong> Projections use standard mathematical compounding formulas. Real financial markets fluctuate, and historical averages do not guarantee future returns.
          </span>
        </div>
      </div>

      {/* TAB 1: SIP CALCULATOR */}
      {activeTab === 'sip' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          {/* Controls */}
          <div className="lg:col-span-6 bg-white rounded-2xl p-6 sm:p-8 shadow-sm border border-slate-200 space-y-6">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <h2 className="font-bold text-slate-900 text-lg">SIP Inputs</h2>
              <ExplainBadge term="sip" onExplain={onExplain} />
            </div>

            {/* Monthly Investment Slider */}
            <div>
              <div className="flex justify-between items-center text-xs mb-2">
                <label className="font-bold text-slate-700 uppercase">Monthly Investment Amount</label>
                <span className="text-base font-extrabold text-emerald-700">
                  {formatCurrency(sipMonthly, profile.currency)}
                </span>
              </div>
              <input
                type="range"
                min="500"
                max="100000"
                step="500"
                value={sipMonthly}
                onChange={(e) => setSipMonthly(Number(e.target.value))}
                className="w-full h-2 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-emerald-600"
              />
              <div className="flex justify-between text-[11px] text-slate-400 mt-1 font-semibold">
                <span>{formatCurrency(500, profile.currency)}</span>
                <span>{formatCurrency(50000, profile.currency)}</span>
                <span>{formatCurrency(100000, profile.currency)}</span>
              </div>
            </div>

            {/* Expected Return Rate Slider */}
            <div>
              <div className="flex justify-between items-center text-xs mb-2">
                <label className="font-bold text-slate-700 uppercase">Expected Annual Return Rate (p.a.)</label>
                <span className="text-base font-extrabold text-indigo-700">{sipRate}%</span>
              </div>
              <input
                type="range"
                min="4"
                max="20"
                step="0.5"
                value={sipRate}
                onChange={(e) => setSipRate(Number(e.target.value))}
                className="w-full h-2 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-indigo-600"
              />
              <div className="flex justify-between text-[11px] text-slate-400 mt-1 font-semibold">
                <span>4% (Debt/FD)</span>
                <span>12% (Broad Equity Average)</span>
                <span>20% (High Growth)</span>
              </div>
            </div>

            {/* Duration Slider */}
            <div>
              <div className="flex justify-between items-center text-xs mb-2">
                <label className="font-bold text-slate-700 uppercase">Time Horizon (Years)</label>
                <span className="text-base font-extrabold text-slate-900">{sipYears} Years</span>
              </div>
              <input
                type="range"
                min="1"
                max="35"
                step="1"
                value={sipYears}
                onChange={(e) => setSipYears(Number(e.target.value))}
                className="w-full h-2 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-slate-800"
              />
              <div className="flex justify-between text-[11px] text-slate-400 mt-1 font-semibold">
                <span>1 Year</span>
                <span>15 Years</span>
                <span>35 Years</span>
              </div>
            </div>

            <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-600 leading-relaxed">
              💡 <strong>Rupee-Cost Averaging:</strong> By investing {formatCurrency(sipMonthly, profile.currency)} automatically every month, you buy more units when markets are down and fewer when markets are high.
            </div>
          </div>

          {/* Results Summary & Visual Chart */}
          <div className="lg:col-span-6 bg-white rounded-2xl p-6 sm:p-8 shadow-sm border border-slate-200 flex flex-col justify-between">
            <div>
              <span className="text-xs font-bold uppercase tracking-wider text-emerald-600 block mb-1">
                Estimated Maturity Value
              </span>
              <div className="text-3xl sm:text-4xl font-black text-slate-900">
                {formatCurrency(sipResult.estimatedFinalValue, profile.currency)}
              </div>

              {/* 2 stat pills */}
              <div className="grid grid-cols-2 gap-4 mt-6">
                <div className="p-4 rounded-xl bg-slate-50 border border-slate-200">
                  <span className="text-xs font-bold text-slate-500 uppercase block">Total Principal Invested</span>
                  <span className="text-xl font-extrabold text-slate-800 mt-1 block">
                    {formatCurrency(sipResult.totalInvested, profile.currency)}
                  </span>
                </div>

                <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-200">
                  <span className="text-xs font-bold text-emerald-800 uppercase block">Estimated Wealth Gain</span>
                  <span className="text-xl font-extrabold text-emerald-700 mt-1 block">
                    +{formatCurrency(sipResult.estimatedGrowth, profile.currency)}
                  </span>
                </div>
              </div>

              {/* Visual Breakdown bar */}
              <div className="mt-6 space-y-1.5">
                <div className="flex justify-between text-xs font-bold">
                  <span className="text-slate-600">
                    Invested: {Math.round((sipResult.totalInvested / sipResult.estimatedFinalValue) * 100)}%
                  </span>
                  <span className="text-emerald-700">
                    Growth: {Math.round((sipResult.estimatedGrowth / sipResult.estimatedFinalValue) * 100)}%
                  </span>
                </div>
                <div className="h-4 w-full bg-slate-200 rounded-full overflow-hidden flex shadow-inner">
                  <div
                    style={{ width: `${(sipResult.totalInvested / sipResult.estimatedFinalValue) * 100}%` }}
                    className="bg-slate-700 h-full"
                    title="Invested Amount"
                  />
                  <div
                    style={{ width: `${(sipResult.estimatedGrowth / sipResult.estimatedFinalValue) * 100}%` }}
                    className="bg-emerald-500 h-full"
                    title="Estimated Growth"
                  />
                </div>
              </div>
            </div>

            {/* Yearly milestones preview */}
            <div className="mt-6 pt-4 border-t border-slate-100">
              <span className="text-xs font-bold text-slate-500 uppercase block mb-2">Milestone Projections</span>
              <div className="grid grid-cols-3 gap-2 text-center text-xs">
                {sipResult.yearlyBreakdown
                  .filter((_, idx) => idx === 2 || idx === Math.floor(sipYears / 2) || idx === sipYears - 1)
                  .map((m, idx) => (
                    <div key={idx} className="p-2 rounded-lg bg-slate-50 border border-slate-200">
                      <span className="text-[10px] text-slate-500 font-bold block">Year {m.year}</span>
                      <span className="font-extrabold text-slate-900 block mt-0.5">
                        {formatCurrency(m.totalValue, profile.currency, true)}
                      </span>
                    </div>
                  ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: GOAL CALCULATOR */}
      {activeTab === 'goal' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          <div className="lg:col-span-6 bg-white rounded-2xl p-6 sm:p-8 shadow-sm border border-slate-200 space-y-6">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <h2 className="font-bold text-slate-900 text-lg">Goal Target Inputs</h2>
              <ExplainBadge term="cagr" onExplain={onExplain} />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                Target Amount ({profile.currency === 'INR' ? '₹' : '$'})
              </label>
              <input
                type="number"
                min="10000"
                step="50000"
                value={goalTarget}
                onChange={(e) => setGoalTarget(Number(e.target.value))}
                className="w-full px-4 py-2.5 rounded-xl border border-slate-300 font-bold text-slate-900 text-base"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                Amount Already Saved
              </label>
              <input
                type="number"
                min="0"
                step="10000"
                value={goalCurrent}
                onChange={(e) => setGoalCurrent(Number(e.target.value))}
                className="w-full px-4 py-2.5 rounded-xl border border-slate-300 font-bold text-slate-900 text-base"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                  Years Available
                </label>
                <input
                  type="number"
                  min="1"
                  max="35"
                  value={goalYears}
                  onChange={(e) => setGoalYears(Number(e.target.value))}
                  className="w-full px-4 py-2.5 rounded-xl border border-slate-300 font-bold text-slate-900 text-base"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                  Expected Return (% p.a.)
                </label>
                <input
                  type="number"
                  min="3"
                  max="18"
                  value={goalRate}
                  onChange={(e) => setGoalRate(Number(e.target.value))}
                  className="w-full px-4 py-2.5 rounded-xl border border-slate-300 font-bold text-slate-900 text-base"
                />
              </div>
            </div>
          </div>

          {/* Goal Output Result */}
          <div className="lg:col-span-6 bg-white rounded-2xl p-6 sm:p-8 shadow-sm border border-slate-200 flex flex-col justify-between">
            <div>
              <span className="text-xs font-bold uppercase tracking-wider text-emerald-600 block mb-1">
                Required Monthly Investment
              </span>
              <div className="text-3xl sm:text-4xl font-black text-emerald-600">
                {formatCurrency(goalMonthlyReq, profile.currency)}
                <span className="text-base font-normal text-slate-500"> / month</span>
              </div>
              <p className="text-xs text-slate-600 mt-2">
                By investing this amount every month at {goalRate}% p.a. for {goalYears} years, you can bridge the {formatCurrency(Math.max(0, goalTarget - goalCurrent), profile.currency)} gap.
              </p>

              <div className="space-y-3 mt-6 p-4 rounded-xl bg-slate-50 border border-slate-200 text-xs">
                <div className="flex justify-between">
                  <span className="text-slate-500 font-medium">Target Amount:</span>
                  <span className="font-extrabold text-slate-900">{formatCurrency(goalTarget, profile.currency)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500 font-medium">Existing Savings:</span>
                  <span className="font-extrabold text-slate-900">{formatCurrency(goalCurrent, profile.currency)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500 font-medium">Total Months:</span>
                  <span className="font-extrabold text-slate-900">{goalYears * 12} Months</span>
                </div>
              </div>
            </div>

            <div className="mt-6 p-3.5 rounded-xl bg-emerald-50 border border-emerald-200 text-xs text-emerald-900">
              💡 <strong>Tip:</strong> If this monthly amount exceeds your current investable capacity ({formatCurrency(profile.monthlyIncome - profile.monthlyExpenses - profile.monthlyEmi, profile.currency)}), consider extending your timeline by 1–2 years or increasing your current savings rate.
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: COMPOUND GROWTH */}
      {activeTab === 'compound' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          <div className="lg:col-span-6 bg-white rounded-2xl p-6 sm:p-8 shadow-sm border border-slate-200 space-y-5">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <h2 className="font-bold text-slate-900 text-lg">Compound Growth Inputs</h2>
              <ExplainBadge term="cagr" onExplain={onExplain} />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                Initial Lump Sum Investment ({profile.currency === 'INR' ? '₹' : '$'})
              </label>
              <input
                type="number"
                min="0"
                step="5000"
                value={compoundInitial}
                onChange={(e) => setCompoundInitial(Number(e.target.value))}
                className="w-full px-4 py-2.5 rounded-xl border border-slate-300 font-bold text-slate-900 text-base"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                Monthly Ongoing Addition
              </label>
              <input
                type="number"
                min="500"
                step="500"
                value={compoundMonthly}
                onChange={(e) => setCompoundMonthly(Number(e.target.value))}
                className="w-full px-4 py-2.5 rounded-xl border border-slate-300 font-bold text-slate-900 text-base"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                  Duration (Years)
                </label>
                <input
                  type="number"
                  min="1"
                  max="40"
                  value={compoundYears}
                  onChange={(e) => setCompoundYears(Number(e.target.value))}
                  className="w-full px-4 py-2.5 rounded-xl border border-slate-300 font-bold text-slate-900 text-base"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                  Annual Return Rate (%)
                </label>
                <input
                  type="number"
                  min="3"
                  max="20"
                  value={compoundRate}
                  onChange={(e) => setCompoundRate(Number(e.target.value))}
                  className="w-full px-4 py-2.5 rounded-xl border border-slate-300 font-bold text-slate-900 text-base"
                />
              </div>
            </div>
          </div>

          <div className="lg:col-span-6 bg-white rounded-2xl p-6 sm:p-8 shadow-sm border border-slate-200 flex flex-col justify-between">
            <div>
              <span className="text-xs font-bold uppercase tracking-wider text-indigo-600 block mb-1">
                Total Compounded Value
              </span>
              <div className="text-3xl sm:text-4xl font-black text-slate-900">
                {formatCurrency(totalCompounded, profile.currency)}
              </div>

              <div className="grid grid-cols-2 gap-4 mt-6">
                <div className="p-4 rounded-xl bg-slate-50 border border-slate-200">
                  <span className="text-xs font-bold text-slate-500 uppercase block">Total Money Invested</span>
                  <span className="text-xl font-extrabold text-slate-800 mt-1 block">
                    {formatCurrency(totalInvestedCompounded, profile.currency)}
                  </span>
                </div>

                <div className="p-4 rounded-xl bg-indigo-50 border border-indigo-200">
                  <span className="text-xs font-bold text-indigo-900 uppercase block">Compound Growth (Interest on Interest)</span>
                  <span className="text-xl font-extrabold text-indigo-700 mt-1 block">
                    +{formatCurrency(compoundGains, profile.currency)}
                  </span>
                </div>
              </div>
            </div>

            <div className="mt-6 p-4 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-600 leading-relaxed">
              🚀 <strong>The Snowball Effect:</strong> Notice that in {compoundYears} years, your returns (+{formatCurrency(compoundGains, profile.currency)}) account for {Math.round((compoundGains / totalCompounded) * 100)}% of your final wealth. Time in the market is your greatest financial superpower!
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
