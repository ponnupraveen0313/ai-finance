import React, { useState, useRef, useEffect } from 'react';
import { 
  Bot, 
  Send, 
  Sparkles, 
  User, 
  AlertTriangle, 
  RotateCcw, 
  HelpCircle,
  ShieldCheck,
  CheckCircle2,
  CornerDownLeft,
  Loader2
} from 'lucide-react';
import { UserProfile, FinancialAnalysis, RiskProfile, FinancialGoal, ChatMessage } from '../types';
import { formatCurrency } from '../utils/financialCalculations';

interface AiChatViewProps {
  profile: UserProfile;
  analysis: FinancialAnalysis;
  riskProfile: RiskProfile;
  goals: FinancialGoal[];
  onExplain: (term: string) => void;
}

const STARTER_PROMPTS = [
  'How much can I safely invest each month?',
  'What is SIP and how does it work?',
  'Explain my Moderate risk profile',
  'What is the difference between an ETF and a Mutual Fund?',
  'Why do I need an emergency fund before investing in stocks?',
  'What is compound interest and why does starting early matter?'
];

export const AiChatView: React.FC<AiChatViewProps> = ({
  profile,
  analysis,
  riskProfile,
  goals,
  onExplain
}) => {
  const [messages, setMessages] = useState<ChatMessage[]>(() => {
    const saved = localStorage.getItem('smartvest_chat_history');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        console.error('Failed to parse saved chat', e);
      }
    }
    return [
      {
        id: 'msg-welcome',
        role: 'assistant',
        content: `👋 Hello! I am **SmartVest AI**, your personal financial guidance assistant.\n\nI am aware of your profile:\n• **Risk Profile**: ${riskProfile.category}\n• **Monthly Surplus**: ~${formatCurrency(analysis.investableCapacity, profile.currency)}/month\n• **Emergency Coverage**: ${analysis.emergencyFundMonths.toFixed(1)} months\n\nFeel free to ask me anything about your numbers, SIPs, asset allocation, or basic financial concepts!`,
        timestamp: Date.now(),
        source: 'smartvest'
      }
    ];
  });

  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    localStorage.setItem('smartvest_chat_history', JSON.stringify(messages));
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSendMessage = async (textToSend?: string) => {
    const query = (textToSend || input).trim();
    if (!query || isLoading) return;

    const userMsg: ChatMessage = {
      id: `msg-${Date.now()}`,
      role: 'user',
      content: query,
      timestamp: Date.now()
    };

    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setIsLoading(true);

    try {
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: query,
          profileContext: {
            age: profile.age,
            employmentStatus: profile.employmentStatus,
            monthlyIncome: profile.monthlyIncome,
            monthlyExpenses: profile.monthlyExpenses,
            monthlySavings: analysis.monthlySavings,
            investableCapacity: analysis.investableCapacity,
            emergencyFundMonths: analysis.emergencyFundMonths,
            riskCategory: riskProfile.category,
            riskScore: riskProfile.score,
            beginnerMode: profile.beginnerMode,
            goals: goals.map(g => ({ name: g.name, target: g.targetAmount, year: g.targetYear }))
          },
          history: messages.slice(-5)
        })
      });

      if (!response.ok) {
        throw new Error(`Server returned status ${response.status}`);
      }

      const data = await response.json();
      const assistantMsg: ChatMessage = {
        id: `msg-${Date.now() + 1}`,
        role: 'assistant',
        content: data.text || 'I apologize, but I could not generate a response right now. Please try again.',
        timestamp: Date.now(),
        source: data.source || 'gemini'
      };

      setMessages(prev => [...prev, assistantMsg]);
    } catch (err: any) {
      console.warn('Chat request fallback error:', err);
      // Graceful local fallback message
      const fallbackMsg: ChatMessage = {
        id: `msg-${Date.now() + 1}`,
        role: 'assistant',
        content: `I am currently operating in offline mode.\n\nBased on your financial profile, your safe investable capacity is **${formatCurrency(analysis.investableCapacity, profile.currency)}/month** with an emergency reserve of **${analysis.emergencyFundMonths.toFixed(1)} months**.\n\nIf you have any questions regarding SIP, ETFs, or risk alignment, check our Education Center or test your timeline in the Calculators tab!`,
        timestamp: Date.now(),
        source: 'local-fallback'
      };
      setMessages(prev => [...prev, fallbackMsg]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleClearHistory = () => {
    const welcome: ChatMessage = {
      id: `msg-${Date.now()}`,
      role: 'assistant',
      content: `Chat history cleared! How can I help you with your investments today?`,
      timestamp: Date.now(),
      source: 'smartvest'
    };
    setMessages([welcome]);
  };

  return (
    <div className="space-y-6 pb-12 max-w-4xl mx-auto">
      {/* Top Header Card */}
      <div className="bg-white rounded-2xl p-6 shadow-sm border border-slate-200">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-emerald-600 text-white flex items-center justify-center shadow-md shadow-emerald-600/20">
              <Bot className="w-7 h-7" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-xl sm:text-2xl font-extrabold text-slate-900">
                  Ask SmartVest AI
                </h1>
                <span className="text-[10px] font-extrabold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800">
                  AI ASSISTANT
                </span>
              </div>
              <p className="text-xs text-slate-500 mt-0.5 font-medium">
                Context-aware guidance based on your ₹{Number(profile.monthlyIncome).toLocaleString('en-IN')} income and {riskProfile.category} profile.
              </p>
            </div>
          </div>

          <button
            onClick={handleClearHistory}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-slate-200 text-slate-600 hover:text-slate-900 hover:bg-slate-50 text-xs font-semibold transition-colors cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Clear Chat</span>
          </button>
        </div>

        {/* Safety Disclaimer */}
        <div className="mt-4 p-2.5 rounded-xl bg-amber-50 border border-amber-200 text-[11px] text-amber-900 flex items-center gap-2">
          <AlertTriangle className="w-3.5 h-3.5 text-amber-600 shrink-0" />
          <span>
            SmartVest AI provides educational information. It never guarantees returns, recommends specific stock tickers, or acts as a licensed broker.
          </span>
        </div>
      </div>

      {/* Chat Messages Box */}
      <div className="bg-white rounded-2xl shadow-sm border border-slate-200 flex flex-col h-[520px]">
        {/* Messages scroll area */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4">
          {messages.map((msg) => {
            const isUser = msg.role === 'user';
            return (
              <div
                key={msg.id}
                className={`flex gap-3 ${isUser ? 'justify-end' : 'justify-start'}`}
              >
                {!isUser && (
                  <div className="w-8 h-8 rounded-xl bg-emerald-100 text-emerald-700 flex items-center justify-center shrink-0 mt-1">
                    <Bot className="w-5 h-5" />
                  </div>
                )}

                <div
                  className={`max-w-[85%] sm:max-w-[75%] rounded-2xl px-4 py-3 text-sm leading-relaxed ${
                    isUser
                      ? 'bg-emerald-600 text-white rounded-tr-none'
                      : 'bg-slate-50 text-slate-800 border border-slate-200 rounded-tl-none font-normal'
                  }`}
                >
                  <div className="whitespace-pre-wrap">
                    {msg.content}
                  </div>
                  <div
                    className={`text-[10px] mt-1 text-right ${
                      isUser ? 'text-emerald-100' : 'text-slate-400'
                    }`}
                  >
                    {new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </div>
                </div>

                {isUser && (
                  <div className="w-8 h-8 rounded-xl bg-slate-800 text-white flex items-center justify-center shrink-0 mt-1">
                    <User className="w-4 h-4" />
                  </div>
                )}
              </div>
            );
          })}

          {isLoading && (
            <div className="flex gap-3 justify-start items-center text-slate-500 text-xs py-2">
              <div className="w-8 h-8 rounded-xl bg-emerald-100 text-emerald-700 flex items-center justify-center shrink-0">
                <Bot className="w-5 h-5" />
              </div>
              <div className="flex items-center gap-2 p-3 bg-slate-50 rounded-xl border border-slate-200">
                <Loader2 className="w-4 h-4 text-emerald-600 animate-spin" />
                <span className="font-semibold text-slate-600">SmartVest AI is analyzing your query...</span>
              </div>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Quick starter prompts */}
        <div className="px-4 py-2 border-t border-slate-100 bg-slate-50/70 overflow-x-auto">
          <span className="text-[10px] font-bold text-slate-500 uppercase block mb-1.5">Suggested Questions:</span>
          <div className="flex gap-2">
            {STARTER_PROMPTS.map((prompt, idx) => (
              <button
                key={idx}
                onClick={() => handleSendMessage(prompt)}
                className="whitespace-nowrap px-3 py-1 bg-white hover:bg-emerald-50 hover:text-emerald-700 border border-slate-200 text-slate-700 text-xs font-semibold rounded-lg transition-colors cursor-pointer shrink-0"
              >
                {prompt}
              </button>
            ))}
          </div>
        </div>

        {/* Input Bar */}
        <div className="p-3 sm:p-4 border-t border-slate-200 bg-white rounded-b-2xl">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSendMessage();
            }}
            className="flex items-center gap-2"
          >
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Ask anything: 'What is SIP?', 'Can I invest in equity?', 'Explain my plan'..."
              className="flex-1 px-4 py-3 rounded-xl border border-slate-300 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-200 outline-none text-slate-900 text-sm font-medium transition-all"
              disabled={isLoading}
            />
            <button
              type="submit"
              disabled={!input.trim() || isLoading}
              className="px-5 py-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white font-bold text-sm shadow-md transition-all flex items-center gap-1.5 cursor-pointer shrink-0"
            >
              <span>Send</span>
              <Send className="w-4 h-4" />
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};
