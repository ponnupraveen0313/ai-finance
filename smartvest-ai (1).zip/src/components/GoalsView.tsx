import React, { useState } from 'react';
import { 
  Target, 
  Plus, 
  Trash2, 
  Edit3, 
  CheckCircle2, 
  AlertTriangle, 
  Calendar, 
  DollarSign, 
  Sparkles,
  ArrowRight,
  TrendingUp,
  X
} from 'lucide-react';
import { FinancialGoal, UserProfile, FinancialAnalysis, GoalCategory, GoalPriority } from '../types';
import { formatCurrency, calculateGoalMonthlyRequirement } from '../utils/financialCalculations';
import { ExplainBadge } from './ExplainModal';

interface GoalsViewProps {
  goals: FinancialGoal[];
  setGoals: React.Dispatch<React.SetStateAction<FinancialGoal[]>>;
  profile: UserProfile;
  analysis: FinancialAnalysis;
  onExplain: (term: string) => void;
}

export const GoalsView: React.FC<GoalsViewProps> = ({
  goals,
  setGoals,
  profile,
  analysis,
  onExplain
}) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingGoalId, setEditingGoalId] = useState<string | null>(null);

  // Form state
  const currentYear = new Date().getFullYear();
  const [formName, setFormName] = useState('');
  const [formCategory, setFormCategory] = useState<GoalCategory>('wealth');
  const [formTarget, setFormTarget] = useState<number>(500000);
  const [formCurrent, setFormCurrent] = useState<number>(50000);
  const [formYear, setFormYear] = useState<number>(currentYear + 5);
  const [formPriority, setFormPriority] = useState<GoalPriority>('medium');
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const openCreateModal = () => {
    setEditingGoalId(null);
    setFormName('');
    setFormCategory('wealth');
    setFormTarget(500000);
    setFormCurrent(0);
    setFormYear(currentYear + 4);
    setFormPriority('medium');
    setErrorMsg(null);
    setIsModalOpen(true);
  };

  const openEditModal = (goal: FinancialGoal) => {
    setEditingGoalId(goal.id);
    setFormName(goal.name);
    setFormCategory(goal.category);
    setFormTarget(goal.targetAmount);
    setFormCurrent(goal.currentAmount);
    setFormYear(goal.targetYear);
    setFormPriority(goal.priority);
    setErrorMsg(null);
    setIsModalOpen(true);
  };

  const handleSaveGoal = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formName.trim()) {
      setErrorMsg('Goal name is required.');
      return;
    }
    if (formTarget <= 0) {
      setErrorMsg('Target amount must be greater than zero.');
      return;
    }
    if (formYear <= currentYear) {
      setErrorMsg('Target year must be in the future.');
      return;
    }

    if (editingGoalId) {
      setGoals(prev => prev.map(g => g.id === editingGoalId ? {
        ...g,
        name: formName.trim(),
        category: formCategory,
        targetAmount: formTarget,
        currentAmount: formCurrent,
        targetYear: formYear,
        priority: formPriority
      } : g));
    } else {
      const newGoal: FinancialGoal = {
        id: `goal-${Date.now()}`,
        name: formName.trim(),
        category: formCategory,
        targetAmount: formTarget,
        currentAmount: formCurrent,
        targetYear: formYear,
        priority: formPriority
      };
      setGoals(prev => [...prev, newGoal]);
    }

    setIsModalOpen(false);
  };

  const handleDeleteGoal = (id: string) => {
    setGoals(prev => prev.filter(g => g.id !== id));
  };

  // Overall statistics
  let totalTarget = 0;
  let totalSaved = 0;
  let totalMonthlyNeeded = 0;

  goals.forEach(g => {
    totalTarget += g.targetAmount;
    totalSaved += g.currentAmount;
    const yearsLeft = Math.max(0.5, g.targetYear - currentYear);
    totalMonthlyNeeded += calculateGoalMonthlyRequirement(g.targetAmount, g.currentAmount, yearsLeft, 8);
  });

  const totalProgress = totalTarget > 0 ? Math.min(100, Math.round((totalSaved / totalTarget) * 100)) : 0;
  const affordabilityRatio = analysis.monthlySavings > 0 ? (totalMonthlyNeeded / analysis.monthlySavings) * 100 : 999;

  return (
    <div className="space-y-8 pb-12">
      {/* Header and Add Goal */}
      <div className="bg-white rounded-2xl p-6 sm:p-8 shadow-sm border border-slate-200">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold uppercase tracking-wider text-emerald-600">Goal Planner</span>
              <span className="text-xs font-bold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800">
                {goals.length} Active Targets
              </span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 mt-1">
              Your Financial Milestones
            </h1>
            <p className="text-sm text-slate-600 mt-1">
              Tracking your goals visually ensures every rupee invested is connected to a real milestone.
            </p>
          </div>

          <button
            onClick={openCreateModal}
            className="flex items-center gap-2 px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl shadow-md transition-all text-sm cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Add New Goal</span>
          </button>
        </div>

        {/* Aggregated Goals Summary Stats */}
        <div className="grid grid-cols-1 sm:grid-cols-4 gap-4 mt-6 pt-6 border-t border-slate-100">
          <div className="p-4 rounded-xl bg-slate-50 border border-slate-200">
            <span className="text-xs font-bold text-slate-500 uppercase block">Total Target</span>
            <span className="text-xl font-extrabold text-slate-900">
              {formatCurrency(totalTarget, profile.currency)}
            </span>
          </div>

          <div className="p-4 rounded-xl bg-slate-50 border border-slate-200">
            <span className="text-xs font-bold text-slate-500 uppercase block">Total Saved</span>
            <span className="text-xl font-extrabold text-emerald-600">
              {formatCurrency(totalSaved, profile.currency)}
            </span>
            <span className="text-[11px] text-slate-500 font-semibold block mt-0.5">
              {totalProgress}% overall progress
            </span>
          </div>

          <div className="p-4 rounded-xl bg-slate-50 border border-slate-200">
            <span className="text-xs font-bold text-slate-500 uppercase block">Total Monthly Required</span>
            <span className="text-xl font-extrabold text-indigo-700">
              {formatCurrency(totalMonthlyNeeded, profile.currency)}/mo
            </span>
            <span className="text-[11px] text-slate-500 block mt-0.5">Assuming 8% annual return</span>
          </div>

          <div className="p-4 rounded-xl bg-slate-50 border border-slate-200">
            <span className="text-xs font-bold text-slate-500 uppercase block">Plan Feasibility</span>
            <div className="flex items-center gap-1.5 mt-0.5">
              {affordabilityRatio <= 100 ? (
                <span className="text-sm font-bold text-emerald-700 flex items-center gap-1">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  Achievable ({Math.round(affordabilityRatio)}% of savings)
                </span>
              ) : (
                <span className="text-sm font-bold text-amber-700 flex items-center gap-1">
                  <AlertTriangle className="w-4 h-4 text-amber-600" />
                  Stretched (exceeds surplus)
                </span>
              )}
            </div>
            <span className="text-[10px] text-slate-500 block mt-0.5">
              Monthly savings: {formatCurrency(analysis.monthlySavings, profile.currency)}
            </span>
          </div>
        </div>
      </div>

      {/* Goal Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {goals.map((goal) => {
          const yearsRemaining = Math.max(0.5, goal.targetYear - currentYear);
          const remainingAmount = Math.max(0, goal.targetAmount - goal.currentAmount);
          const monthlyRequired = calculateGoalMonthlyRequirement(goal.targetAmount, goal.currentAmount, yearsRemaining, 8);
          const progressPct = goal.targetAmount > 0 ? Math.min(100, Math.round((goal.currentAmount / goal.targetAmount) * 100)) : 0;
          const isAchievable = monthlyRequired <= analysis.investableCapacity;

          return (
            <div
              key={goal.id}
              className="bg-white rounded-2xl p-6 shadow-sm border border-slate-200 hover:border-slate-300 transition-all flex flex-col justify-between"
            >
              <div>
                <div className="flex items-start justify-between gap-2 mb-3">
                  <div>
                    <span className={`text-[10px] uppercase font-extrabold px-2 py-0.5 rounded ${
                      goal.priority === 'high' ? 'bg-amber-100 text-amber-800' :
                      goal.priority === 'medium' ? 'bg-blue-100 text-blue-800' : 'bg-slate-100 text-slate-700'
                    }`}>
                      {goal.priority} Priority
                    </span>
                    <h3 className="font-extrabold text-slate-900 text-lg mt-1">{goal.name}</h3>
                  </div>

                  <div className="flex items-center gap-1">
                    <button
                      onClick={() => openEditModal(goal)}
                      className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-100 transition-colors"
                      title="Edit Goal"
                    >
                      <Edit3 className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => handleDeleteGoal(goal.id)}
                      className="p-1.5 text-slate-400 hover:text-rose-600 rounded-lg hover:bg-rose-50 transition-colors"
                      title="Delete Goal"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                {/* Progress bar */}
                <div className="space-y-1.5 my-4">
                  <div className="flex justify-between text-xs font-semibold">
                    <span className="text-slate-500">Progress</span>
                    <span className="text-emerald-700 font-bold">{progressPct}%</span>
                  </div>
                  <div className="w-full bg-slate-100 h-2.5 rounded-full overflow-hidden">
                    <div 
                      className="bg-emerald-500 h-full rounded-full transition-all duration-500"
                      style={{ width: `${progressPct}%` }}
                    />
                  </div>
                </div>

                {/* Details Breakdown */}
                <div className="space-y-2 text-xs py-2 border-y border-slate-100">
                  <div className="flex justify-between">
                    <span className="text-slate-500">Target Amount:</span>
                    <span className="font-bold text-slate-900">{formatCurrency(goal.targetAmount, profile.currency)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Current Saved:</span>
                    <span className="font-bold text-emerald-700">{formatCurrency(goal.currentAmount, profile.currency)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Remaining Gap:</span>
                    <span className="font-bold text-slate-700">{formatCurrency(remainingAmount, profile.currency)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Target Timeline:</span>
                    <span className="font-semibold text-slate-900">
                      {goal.targetYear} (~{yearsRemaining.toFixed(1)} yrs left)
                    </span>
                  </div>
                </div>
              </div>

              {/* Bottom Card Footer: Required Contribution & Feasibility */}
              <div className="mt-4 pt-3 bg-slate-50 p-3.5 rounded-xl border border-slate-200/80">
                <div className="flex items-center justify-between">
                  <span className="text-[11px] font-bold text-slate-500 uppercase">Monthly Needed</span>
                  <span className="text-base font-extrabold text-indigo-700">
                    {formatCurrency(monthlyRequired, profile.currency)}
                    <span className="text-xs font-normal text-slate-500">/mo</span>
                  </span>
                </div>
                <div className="mt-2 flex items-center justify-between text-[11px]">
                  <span className="text-slate-500">Feasibility:</span>
                  {isAchievable ? (
                    <span className="font-bold text-emerald-700 flex items-center gap-1">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                      On Track
                    </span>
                  ) : (
                    <span className="font-bold text-amber-700 flex items-center gap-1" title="Requires more monthly surplus than currently available investable capacity">
                      <AlertTriangle className="w-3.5 h-3.5 text-amber-600" />
                      Stretch Target
                    </span>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Goal Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-slate-200 relative">
            <button
              onClick={() => setIsModalOpen(false)}
              className="absolute top-4 right-4 p-1.5 text-slate-400 hover:text-slate-600 rounded-full hover:bg-slate-100"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-2 mb-4">
              <div className="w-8 h-8 rounded-lg bg-emerald-100 text-emerald-700 flex items-center justify-center">
                <Target className="w-5 h-5" />
              </div>
              <h3 className="text-lg font-bold text-slate-900">
                {editingGoalId ? 'Edit Financial Goal' : 'Add New Financial Goal'}
              </h3>
            </div>

            {errorMsg && (
              <div className="p-3 mb-4 rounded-xl bg-rose-50 border border-rose-200 text-xs text-rose-800">
                {errorMsg}
              </div>
            )}

            <form onSubmit={handleSaveGoal} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                  Goal Name
                </label>
                <input
                  type="text"
                  value={formName}
                  onChange={(e) => setFormName(e.target.value)}
                  placeholder="e.g. Electric Car Downpayment"
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 font-semibold text-slate-900 text-sm focus:border-emerald-500 outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                    Target Amount ({profile.currency === 'INR' ? '₹' : '$'})
                  </label>
                  <input
                    type="number"
                    min="1000"
                    step="5000"
                    value={formTarget}
                    onChange={(e) => setFormTarget(parseFloat(e.target.value) || 0)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 font-semibold text-slate-900 text-sm focus:border-emerald-500 outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                    Current Savings
                  </label>
                  <input
                    type="number"
                    min="0"
                    step="1000"
                    value={formCurrent}
                    onChange={(e) => setFormCurrent(parseFloat(e.target.value) || 0)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 font-semibold text-slate-900 text-sm focus:border-emerald-500 outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                    Target Year
                  </label>
                  <input
                    type="number"
                    min={currentYear + 1}
                    max={currentYear + 40}
                    value={formYear}
                    onChange={(e) => setFormYear(parseInt(e.target.value) || (currentYear + 1))}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 font-semibold text-slate-900 text-sm focus:border-emerald-500 outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                    Priority
                  </label>
                  <select
                    value={formPriority}
                    onChange={(e) => setFormPriority(e.target.value as GoalPriority)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 font-semibold text-slate-900 text-sm focus:border-emerald-500 outline-none bg-white"
                  >
                    <option value="high">High</option>
                    <option value="medium">Medium</option>
                    <option value="low">Low</option>
                  </select>
                </div>
              </div>

              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 rounded-xl border border-slate-300 text-slate-700 font-bold text-xs hover:bg-slate-50 transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-md transition-colors"
                >
                  {editingGoalId ? 'Save Changes' : 'Create Goal'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
