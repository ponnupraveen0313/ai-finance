export type EmploymentStatus = 'student' | 'salaried' | 'self_employed' | 'business_owner' | 'other';

export type GoalCategory = 
  | 'emergency' 
  | 'education' 
  | 'vehicle' 
  | 'house' 
  | 'business' 
  | 'retirement' 
  | 'wealth' 
  | 'travel' 
  | 'family' 
  | 'other';

export type GoalPriority = 'high' | 'medium' | 'low';

export interface FinancialGoal {
  id: string;
  name: string;
  category: GoalCategory;
  targetAmount: number;
  currentAmount: number;
  targetYear: number;
  priority: GoalPriority;
  targetMonths?: number;
}

export interface UserProfile {
  age: number;
  employmentStatus: EmploymentStatus;
  monthlyIncome: number;
  monthlyExpenses: number;
  existingSavings: number;
  emergencyFund: number;
  currentInvestments: number;
  existingDebt: number;
  monthlyEmi: number;
  currency: 'INR' | 'USD';
  onboardingComplete: boolean;
  beginnerMode: boolean;
}

export type RiskCategory = 
  | 'Conservative' 
  | 'Moderately Conservative' 
  | 'Moderate' 
  | 'Moderately Aggressive' 
  | 'Aggressive';

export interface RiskProfile {
  score: number;
  maxScore: number;
  category: RiskCategory;
  tagline: string;
  description: string;
  influencingFactors: string[];
  suggestedHorizon: string;
  answers: Record<number, number>;
}

export interface HealthBreakdown {
  savings: number;
  emergency: number;
  debt: number;
  goals: number;
  readiness: number;
}

export interface FinancialAnalysis {
  monthlySavings: number;
  savingsRate: number;
  emergencyFundMonths: number;
  debtToIncomeRatio: number;
  netWorth: number;
  investableCapacity: number;
  healthScore: number;
  healthBreakdown: HealthBreakdown;
  emergencyStatus: 'good' | 'attention' | 'critical';
  debtStatus: 'good' | 'attention' | 'critical';
  savingsStatus: 'good' | 'attention' | 'critical';
  goalReadinessStatus: 'good' | 'attention' | 'critical';
}

export interface AssetAllocationItem {
  id: string;
  name: string;
  categoryName: string;
  percentage: number;
  amount: number;
  color: string;
  simpleDescription: string;
  technicalDescription: string;
  benefits: string[];
  risks: string[];
  timeHorizon: string;
  whyForYou: string;
  examples: string[];
}

export interface Recommendation {
  id: string;
  title: string;
  why: string;
  priority: 'high' | 'medium' | 'low';
  suggestedAction: string;
  category: 'emergency' | 'debt' | 'investing' | 'goals';
  dataInfluences: string[];
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: number;
  source?: string;
}

export interface EducationArticle {
  id: string;
  title: string;
  category: string;
  readTime: string;
  icon: string;
  simpleDefinition: string;
  realLifeExample: string;
  benefits: string[];
  risks: string[];
  whenUseful: string;
  keyTakeaway: string;
}
